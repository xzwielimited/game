/**
 * 3-Layer Sensor Suite & 5-State Track Confidence FSM
 * Clean-Room implementation for NavalCommand.io
 */

import { Vector2D, vec2, vec2Add, vec2Scale, vec2Distance, knotsToMs } from '../math/vector2.js';
import { SubmarineDepthState } from '../models/types.js';
import { IslandEntity } from '../models/terrain.js';
import { ShipDef } from '../models/ships.js';
import { SonarBuoyEntity } from '../models/weapons.js';
import {
  checkVisualLoS,
  evaluateRadarDetection,
  checkLineOfSight,
  VISUAL_MAX_RANGE_DEFAULT,
  RADAR_BASE_RANGE_DEFAULT,
} from './raycasting.js';
import {
  AcousticEmitter,
  evaluatePassiveAcousticDetection,
  evaluateActiveSonarPing,
  ActiveSonarPingResult,
  ACTIVE_SONAR_DEFAULT_RANGE_METERS,
} from './acoustic_model.js';

export enum TrackConfidence {
  UNKNOWN = 0,
  BEARING_ONLY = 1,
  APPROXIMATE = 2,
  TRACKED = 3,
  IDENTIFIED = 4,
}

export type SensorDetectionSource =
  | 'VISUAL'
  | 'RADAR'
  | 'PASSIVE_ACOUSTIC'
  | 'ACTIVE_SONAR'
  | 'ACTIVE_SONAR_COUNTER'
  | 'SONOBUOY'
  | 'FLEET_LINK';

export interface TrackedContact {
  contactId: string;
  targetId: string;
  confidence: TrackConfidence;
  estimatedPosition: Vector2D;
  estimatedVelocity: Vector2D;
  bearingRad?: number;
  estimatedDistance?: number;
  uncertaintyRadiusMeters: number;
  shipClassId?: string;
  shipName?: string;
  hullHpPct?: number;
  depthState?: SubmarineDepthState;
  detectedBy: SensorDetectionSource[];
  timeSinceLastUpdateSec: number;
  timeInTrackSec: number;
}

export interface SensorSuiteConfig {
  visualRangeMeters: number;               // Optical range in meters (default 1000m)
  radarRangeMeters: number;                // Radar base range (default 2000m)
  activeSonarRangeMeters: number;          // Active sonar range (default 1500m)
  activePingCooldownSec: number;           // Cooldown between active pings (default 15s)
  trackDecayIdentifiedToTrackedSec: number;// IDENTIFIED -> TRACKED (default 4.0s)
  trackDecayTrackedToApproxSec: number;    // TRACKED -> APPROXIMATE (default 6.0s)
  trackDecayApproxToBearingSec: number;    // APPROXIMATE -> BEARING_ONLY (default 8.0s)
  trackTimeoutSec: number;                 // BEARING_ONLY -> UNKNOWN / purge (default 15.0s)
}

export const DEFAULT_SENSOR_SUITE_CONFIG: SensorSuiteConfig = {
  visualRangeMeters: VISUAL_MAX_RANGE_DEFAULT,
  radarRangeMeters: RADAR_BASE_RANGE_DEFAULT,
  activeSonarRangeMeters: 1500.0,
  activePingCooldownSec: 15.0,
  trackDecayIdentifiedToTrackedSec: 4.0,
  trackDecayTrackedToApproxSec: 6.0,
  trackDecayApproxToBearingSec: 8.0,
  trackTimeoutSec: 15.0,
};

export interface SensorWorldCandidate {
  id: string;
  name: string;
  shipClassId: string;
  position: Vector2D;
  velocity: Vector2D;
  heading: number;
  speedKnots: number;
  shipDef: ShipDef;
  depthState: SubmarineDepthState;
  ecmActive: boolean;
  stealthActive: boolean;
  isActiveSonarPinging?: boolean;
  hullHp: number;
  maxHp: number;
}

export interface SensorWorldContext {
  observer: SensorWorldCandidate;
  candidates: SensorWorldCandidate[];
  islands: IslandEntity[];
  friendlySonobuoys?: SonarBuoyEntity[];
}

/**
 * 3-Layer Sensor Suite managing multi-spectral detection,
 * sensor fusion, dead-reckoning extrapolation, and the 5-state track confidence FSM.
 */
export class SensorSuite {
  public readonly ownerId: string;
  public config: SensorSuiteConfig;
  private tracks: Map<string, TrackedContact> = new Map();
  private pingCooldownTimer: number = 0;

  constructor(ownerId: string, config?: Partial<SensorSuiteConfig>) {
    this.ownerId = ownerId;
    this.config = { ...DEFAULT_SENSOR_SUITE_CONFIG, ...config };
  }

  /**
   * Returns current active sonar ping cooldown remaining in seconds.
   */
  public getActivePingCooldown(): number {
    return this.pingCooldownTimer;
  }

  /**
   * Triggers an omni-directional active sonar ping.
   * Illuminates underwater and surface contacts out to activeSonarRangeMeters.
   * Simultaneously alerts all listening vessels out to 2x activeSonarRangeMeters.
   */
  public triggerActiveSonarPing(
    observer: SensorWorldCandidate,
    candidates: SensorWorldCandidate[],
    islands: IslandEntity[]
  ): ActiveSonarPingResult | null {
    if (this.pingCooldownTimer > 0) {
      return null;
    }

    this.pingCooldownTimer = this.config.activePingCooldownSec;

    const pingerEmitter: AcousticEmitter = {
      id: observer.id,
      position: observer.position,
      velocity: observer.velocity,
      speedKnots: observer.speedKnots,
      depthState: observer.depthState,
      cavitationThresholdSpeedMs: observer.shipDef.cavitationThresholdSpeed,
      stealthModeActive: observer.stealthActive,
      isActiveSonarPinging: true,
    };

    const candidateEmitters: AcousticEmitter[] = candidates.map(c => ({
      id: c.id,
      position: c.position,
      velocity: c.velocity,
      speedKnots: c.speedKnots,
      depthState: c.depthState,
      cavitationThresholdSpeedMs: c.shipDef.cavitationThresholdSpeed,
      stealthModeActive: c.stealthActive,
      isActiveSonarPinging: !!c.isActiveSonarPinging,
    }));

    const pingResult = evaluateActiveSonarPing(
      pingerEmitter,
      candidateEmitters,
      islands,
      this.config.activeSonarRangeMeters
    );

    // Fuse direct return echoes into own tracks
    for (const echo of pingResult.echoes) {
      const existing = this.tracks.get(echo.targetId);
      const sources: SensorDetectionSource[] = ['ACTIVE_SONAR'];
      if (existing) {
        for (const s of existing.detectedBy) {
          if (!sources.includes(s)) sources.push(s);
        }
      }

      const candidate = candidates.find(c => c.id === echo.targetId);

      const track: TrackedContact = {
        contactId: `trk_${echo.targetId}`,
        targetId: echo.targetId,
        confidence: Math.max(existing?.confidence ?? 0, TrackConfidence.TRACKED),
        estimatedPosition: { ...echo.position },
        estimatedVelocity: candidate ? { ...candidate.velocity } : (existing?.estimatedVelocity ?? vec2(0, 0)),
        bearingRad: echo.bearingRad,
        estimatedDistance: echo.distance,
        uncertaintyRadiusMeters: 25.0,
        shipClassId: candidate?.shipClassId ?? existing?.shipClassId,
        shipName: candidate?.name ?? existing?.shipName,
        hullHpPct: candidate ? Math.round((candidate.hullHp / candidate.maxHp) * 100) : existing?.hullHpPct,
        depthState: candidate?.depthState ?? existing?.depthState,
        detectedBy: sources,
        timeSinceLastUpdateSec: 0,
        timeInTrackSec: (existing?.timeInTrackSec ?? 0),
      };

      this.tracks.set(echo.targetId, track);
    }

    return pingResult;
  }

  /**
   * Main simulation tick update: runs concurrent multi-spectral sensor passes,
   * fuses detected contacts, applies dead-reckoning extrapolation, expands uncertainty,
   * and steps through the 5-state track decay FSM.
   */
  public update(dt: number, context: SensorWorldContext): TrackedContact[] {
    const { observer, candidates, islands, friendlySonobuoys } = context;

    if (this.pingCooldownTimer > 0) {
      this.pingCooldownTimer = Math.max(0, this.pingCooldownTimer - dt);
    }

    const freshlyDetectedTargets = new Set<string>();

    for (const candidate of candidates) {
      if (candidate.id === observer.id) continue;

      const detectedSources: SensorDetectionSource[] = [];
      let maxConfidence = TrackConfidence.UNKNOWN;
      let reportedPos = { ...candidate.position };
      let reportedVel = { ...candidate.velocity };
      let uncertainty = 0;
      let bearingRad: number | undefined;
      let estimatedDistance: number | undefined;

      // 1. Visual Line-of-Sight Pass
      const visualLoS = checkVisualLoS(
        observer.position,
        candidate.position,
        candidate.depthState,
        islands,
        this.config.visualRangeMeters
      );

      if (visualLoS.hasLoS) {
        detectedSources.push('VISUAL');
        maxConfidence = TrackConfidence.IDENTIFIED;
        uncertainty = 0;
        reportedPos = { ...candidate.position };
        reportedVel = { ...candidate.velocity };
      }

      // 2. Radar Pass
      const radarResult = evaluateRadarDetection(
        observer.position,
        candidate.position,
        candidate.shipDef.radarCrossSection,
        candidate.depthState,
        candidate.ecmActive,
        islands,
        this.config.radarRangeMeters
      );

      if (radarResult.detected) {
        detectedSources.push('RADAR');
        if (radarResult.isBlurred) {
          // ECM Jamming blurs radar contact into APPROXIMATE
          if (maxConfidence < TrackConfidence.APPROXIMATE) {
            maxConfidence = TrackConfidence.APPROXIMATE;
            uncertainty = radarResult.uncertaintyRadius;
            reportedPos = { ...radarResult.reportedPosition };
          }
        } else {
          // Clear radar contact yields TRACKED
          if (maxConfidence < TrackConfidence.TRACKED) {
            maxConfidence = TrackConfidence.TRACKED;
            uncertainty = 15.0;
            reportedPos = { ...candidate.position };
          }
        }
      }

      // 3. Passive Acoustic Pass
      const candidateEmitter: AcousticEmitter = {
        id: candidate.id,
        position: candidate.position,
        velocity: candidate.velocity,
        speedKnots: candidate.speedKnots,
        depthState: candidate.depthState,
        cavitationThresholdSpeedMs: candidate.shipDef.cavitationThresholdSpeed,
        stealthModeActive: candidate.stealthActive,
        isActiveSonarPinging: !!candidate.isActiveSonarPinging,
      };

      const passiveResult = evaluatePassiveAcousticDetection(
        observer.position,
        candidateEmitter
      );

      if (passiveResult.detected) {
        detectedSources.push('PASSIVE_ACOUSTIC');
        if (maxConfidence < TrackConfidence.BEARING_ONLY) {
          maxConfidence = TrackConfidence.BEARING_ONLY;
          bearingRad = passiveResult.bearingRad;
          estimatedDistance = passiveResult.estimatedDistance;
          uncertainty = 300.0;
        }
      }

      // 4. Friendly Sonobuoy Pass
      if (friendlySonobuoys && friendlySonobuoys.length > 0) {
        for (const buoy of friendlySonobuoys) {
          if (buoy.isExpired) continue;
          const distToBuoy = vec2Distance(buoy.position, candidate.position);
          if (distToBuoy <= buoy.radius) {
            // Sonobuoys detect surface and submerged vessels acoustically within their circle
            if (checkLineOfSight(buoy.position, candidate.position, islands)) {
              detectedSources.push('SONOBUOY');
              if (maxConfidence < TrackConfidence.APPROXIMATE) {
                maxConfidence = TrackConfidence.APPROXIMATE;
                uncertainty = 60.0;
                reportedPos = { ...candidate.position };
              }
              break;
            }
          }
        }
      }

      // If detected by at least one sensor this tick
      if (detectedSources.length > 0) {
        freshlyDetectedTargets.add(candidate.id);
        const existing = this.tracks.get(candidate.id);

        const newSources = [...detectedSources];
        if (existing) {
          for (const s of existing.detectedBy) {
            if (!newSources.includes(s)) newSources.push(s);
          }
        }

        // Retain IDENTIFIED if visual wasn't broken by timeout yet, unless superseded
        const targetConfidence = Math.max(
          maxConfidence,
          existing?.confidence ?? TrackConfidence.UNKNOWN
        );

        const track: TrackedContact = {
          contactId: existing?.contactId ?? `trk_${candidate.id}`,
          targetId: candidate.id,
          confidence: targetConfidence,
          estimatedPosition: reportedPos,
          estimatedVelocity: reportedVel,
          bearingRad,
          estimatedDistance,
          uncertaintyRadiusMeters: uncertainty,
          shipClassId: maxConfidence >= TrackConfidence.IDENTIFIED
            ? candidate.shipClassId
            : (existing?.shipClassId ?? (maxConfidence >= TrackConfidence.TRACKED ? candidate.shipClassId : undefined)),
          shipName: maxConfidence >= TrackConfidence.IDENTIFIED
            ? candidate.name
            : existing?.shipName,
          hullHpPct: maxConfidence >= TrackConfidence.IDENTIFIED
            ? Math.round((candidate.hullHp / candidate.maxHp) * 100)
            : existing?.hullHpPct,
          depthState: candidate.depthState,
          detectedBy: newSources,
          timeSinceLastUpdateSec: 0,
          timeInTrackSec: (existing?.timeInTrackSec ?? 0) + dt,
        };

        this.tracks.set(candidate.id, track);
      }
    }

    // Process tracks without fresh detection this tick (Dead Reckoning & Decay FSM)
    const deadTrackIds: string[] = [];

    for (const [targetId, track] of this.tracks.entries()) {
      if (!freshlyDetectedTargets.has(targetId)) {
        track.timeSinceLastUpdateSec += dt;
        track.timeInTrackSec += dt;

        // Dead reckoning extrapolation
        track.estimatedPosition = vec2Add(
          track.estimatedPosition,
          vec2Scale(track.estimatedVelocity, dt)
        );

        // Uncertainty radius expands as contact ages without sensor updates
        track.uncertaintyRadiusMeters += dt * 10.0;

        // 5-State Track Decay FSM:
        // IDENTIFIED -> TRACKED -> APPROXIMATE -> BEARING_ONLY -> UNKNOWN (Purged)
        if (track.confidence === TrackConfidence.IDENTIFIED) {
          if (track.timeSinceLastUpdateSec >= this.config.trackDecayIdentifiedToTrackedSec) {
            track.confidence = TrackConfidence.TRACKED;
          }
        } else if (track.confidence === TrackConfidence.TRACKED) {
          if (track.timeSinceLastUpdateSec >= this.config.trackDecayTrackedToApproxSec) {
            track.confidence = TrackConfidence.APPROXIMATE;
          }
        } else if (track.confidence === TrackConfidence.APPROXIMATE) {
          if (track.timeSinceLastUpdateSec >= this.config.trackDecayApproxToBearingSec) {
            track.confidence = TrackConfidence.BEARING_ONLY;
          }
        } else if (track.confidence === TrackConfidence.BEARING_ONLY) {
          if (track.timeSinceLastUpdateSec >= this.config.trackTimeoutSec) {
            track.confidence = TrackConfidence.UNKNOWN;
            deadTrackIds.push(targetId);
          }
        }
      }
    }

    // Purge expired tracks
    for (const deadId of deadTrackIds) {
      this.tracks.delete(deadId);
    }

    return Array.from(this.tracks.values());
  }

  /**
   * Fuses an external track contact (e.g. from Fleet Sensor Link or carrier relay).
   */
  public fuseExternalContact(external: TrackedContact): void {
    const existing = this.tracks.get(external.targetId);

    const sources: SensorDetectionSource[] = [...external.detectedBy];
    if (!sources.includes('FLEET_LINK')) sources.push('FLEET_LINK');

    if (!existing) {
      this.tracks.set(external.targetId, {
        ...external,
        detectedBy: sources,
      });
      return;
    }

    // Merge existing with external: higher confidence takes precedence
    if (external.confidence > existing.confidence) {
      this.tracks.set(external.targetId, {
        ...external,
        contactId: existing.contactId,
        detectedBy: sources,
        timeSinceLastUpdateSec: Math.min(existing.timeSinceLastUpdateSec, external.timeSinceLastUpdateSec),
        timeInTrackSec: Math.max(existing.timeInTrackSec, external.timeInTrackSec),
      });
    } else {
      // Retain existing confidence, incorporate fleet link tag
      for (const s of sources) {
        if (!existing.detectedBy.includes(s)) existing.detectedBy.push(s);
      }
      existing.uncertaintyRadiusMeters = Math.min(
        existing.uncertaintyRadiusMeters,
        external.uncertaintyRadiusMeters
      );
      existing.timeSinceLastUpdateSec = Math.min(
        existing.timeSinceLastUpdateSec,
        external.timeSinceLastUpdateSec
      );
    }
  }

  /**
   * Returns all current active tracks.
   */
  public getContacts(): TrackedContact[] {
    return Array.from(this.tracks.values());
  }

  /**
   * Retrieves a specific tracked contact by target ID.
   */
  public getContact(targetId: string): TrackedContact | undefined {
    return this.tracks.get(targetId);
  }

  /**
   * Returns current track confidence for a target ID.
   */
  public getTrackConfidence(targetId: string): TrackConfidence {
    const track = this.tracks.get(targetId);
    return track ? track.confidence : TrackConfidence.UNKNOWN;
  }

  /**
   * Clears all tracked contacts.
   */
  public clear(): void {
    this.tracks.clear();
    this.pingCooldownTimer = 0;
  }
}
