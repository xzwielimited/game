/**
 * Tactical Menus: Tech Tree, Loadout Customizer & Camouflage Selector
 * Clean-Room implementation for NavalCommand.io
 */

import { getAllShipDefs, ShipDef } from '../../../common/models/ships.js';
import { CamoType } from '../rendering/vector_hulls.js';

export class MenusManager {
  public readonly overlayContainer: HTMLElement;
  private techTreeModal: HTMLElement | null = null;
  private loadoutModal: HTMLElement | null = null;
  private camoModal: HTMLElement | null = null;

  public credits: number = 1500;
  public matchXP: number = 350;
  public unlockedHulls: Set<string> = new Set(['pt_boat_109', 'fairmile_d', 'vosper_mtb']);
  public selectedCamo: CamoType = 'HAZE_GREY';
  public selectedHullId: string = 'pt_boat_109';

  private onSelectHullCb: ((hullId: string) => void) | null = null;
  private onSelectCamoCb: ((camo: CamoType) => void) | null = null;

  constructor() {
    this.overlayContainer = document.createElement('div');
    this.overlayContainer.className = 'tactical-menus-overlay';
    this.overlayContainer.style.cssText = `
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      z-index: 200;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    `;
  }

  public setCallbacks(cbs: {
    onSelectHull?: (hullId: string) => void;
    onSelectCamo?: (camo: CamoType) => void;
  }): void {
    if (cbs.onSelectHull) this.onSelectHullCb = cbs.onSelectHull;
    if (cbs.onSelectCamo) this.onSelectCamoCb = cbs.onSelectCamo;
  }

  public showTechTree(): void {
    this.closeAll();

    const modal = document.createElement('div');
    modal.style.cssText = this.getModalStyle();
    modal.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(0, 230, 118, 0.4); padding-bottom: 10px; margin-bottom: 15px;">
        <h2 style="margin: 0; color: #00e676; font-size: 20px;">NAVAL TECH TREE (TIERS 1 - 10)</h2>
        <div style="display: flex; gap: 15px; font-size: 14px; font-weight: 600;">
          <span style="color: #64ffda;">Match XP: ${this.matchXP}</span>
          <span style="color: #ffd54f;">Naval Credits: ${this.credits}</span>
          <button class="close-btn" style="background: none; border: none; color: #fff; font-size: 18px; cursor: pointer;">✕</button>
        </div>
      </div>
      <div class="tech-tree-grid" style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; max-height: 480px; overflow-y: auto; padding-right: 8px;">
      </div>
    `;

    const grid = modal.querySelector('.tech-tree-grid') as HTMLElement;
    const ships = getAllShipDefs().slice(0, 28);

    for (const ship of ships) {
      const card = document.createElement('div');
      const isUnlocked = this.unlockedHulls.has(ship.id);
      const isSelected = this.selectedHullId === ship.id;

      card.style.cssText = `
        background: ${isSelected ? 'rgba(0, 230, 118, 0.15)' : 'rgba(15, 28, 48, 0.85)'};
        border: 1px solid ${isSelected ? '#00e676' : isUnlocked ? 'rgba(0, 229, 255, 0.4)' : 'rgba(255, 255, 255, 0.15)'};
        border-radius: 4px;
        padding: 10px;
        color: #fff;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        gap: 6px;
      `;

      card.innerHTML = `
        <div>
          <div style="display: flex; justify-content: space-between; font-size: 11px; opacity: 0.8;">
            <span>Tier ${ship.tier}</span>
            <span style="color: #64ffda;">${ship.shipClass}</span>
          </div>
          <div style="font-weight: 700; font-size: 13px; margin: 4px 0;">${ship.name}</div>
          <div style="font-size: 10px; opacity: 0.7;">${ship.inspiration}</div>
        </div>
        <div style="font-size: 11px; opacity: 0.9;">
          <div>HP: ${ship.maxHp} | Armor: ${ship.armor}</div>
          <div>Speed: ${Math.round(ship.maxForwardSpeed * 1.94)} kt</div>
        </div>
        <button class="action-btn" style="
          background: ${isSelected ? '#00e676' : isUnlocked ? '#0288d1' : '#ff8f00'};
          border: none;
          border-radius: 3px;
          color: #fff;
          padding: 6px;
          font-size: 11px;
          font-weight: 700;
          cursor: pointer;
        ">
          ${isSelected ? 'ACTIVE' : isUnlocked ? 'SELECT' : `UNLOCK (${ship.tier * 300} C)`}
        </button>
      `;

      const btn = card.querySelector('.action-btn') as HTMLButtonElement;
      btn.addEventListener('click', () => {
        if (isUnlocked) {
          this.selectedHullId = ship.id;
          if (this.onSelectHullCb) this.onSelectHullCb(ship.id);
          this.showTechTree(); // Refresh
        } else {
          const cost = ship.tier * 300;
          if (this.credits >= cost) {
            this.credits -= cost;
            this.unlockedHulls.add(ship.id);
            this.selectedHullId = ship.id;
            if (this.onSelectHullCb) this.onSelectHullCb(ship.id);
            this.showTechTree();
          } else {
            alert('Insufficient Naval Credits!');
          }
        }
      });

      grid.appendChild(card);
    }

    modal.querySelector('.close-btn')?.addEventListener('click', () => this.closeAll());

    this.overlayContainer.style.pointerEvents = 'auto';
    this.overlayContainer.appendChild(modal);
    this.techTreeModal = modal;
  }

  public showLoadoutCustomizer(): void {
    this.closeAll();

    const modal = document.createElement('div');
    modal.style.cssText = this.getModalStyle();
    modal.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(0, 230, 118, 0.4); padding-bottom: 10px; margin-bottom: 15px;">
        <h2 style="margin: 0; color: #00e676; font-size: 20px;">MODULAR LOADOUT CUSTOMIZATION</h2>
        <button class="close-btn" style="background: none; border: none; color: #fff; font-size: 18px; cursor: pointer;">✕</button>
      </div>
      <div style="display: flex; gap: 20px;">
        <div style="flex: 1; background: rgba(12, 24, 40, 0.8); border: 1px solid rgba(255,255,255,0.1); border-radius: 4px; padding: 15px;">
          <h3 style="margin-top: 0; color: #64ffda; font-size: 15px;">ACTIVE HARDPOINTS</h3>
          <div style="display: flex; flex-direction: column; gap: 10px; font-size: 12px;">
            <div style="display: flex; justify-content: space-between; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 5px;">
              <span>Slot 1 (Fore Main Artillery):</span>
              <span style="color: #00e676; font-weight: 600;">127mm Mark 45 Naval Gun</span>
            </div>
            <div style="display: flex; justify-content: space-between; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 5px;">
              <span>Slot 2 (Midship Torpedo Bank):</span>
              <span style="color: #00e5ff; font-weight: 600;">Mark 48 Heavy Acoustic Torpedo</span>
            </div>
            <div style="display: flex; justify-content: space-between; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 5px;">
              <span>Slot 3 (VLS Air Defense):</span>
              <span style="color: #ffd54f; font-weight: 600;">RIM-162 ESSM Surface-to-Air</span>
            </div>
            <div style="display: flex; justify-content: space-between; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 5px;">
              <span>Slot 4 (Tactical Module):</span>
              <span style="color: #e040fb; font-weight: 600;">AN/SLQ-32 ECM Electronic Jammer</span>
            </div>
          </div>
        </div>
        <div style="flex: 1; background: rgba(12, 24, 40, 0.8); border: 1px solid rgba(255,255,255,0.1); border-radius: 4px; padding: 15px;">
          <h3 style="margin-top: 0; color: #64ffda; font-size: 15px;">AVAILABLE UPGRADES</h3>
          <div style="display: flex; flex-direction: column; gap: 8px;">
            <button style="text-align: left; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.2); color: #fff; padding: 8px; border-radius: 3px; cursor: pointer;">
              <div style="font-weight: 600; color: #00e5ff;">Towed Active Sonar Array</div>
              <div style="font-size: 10px; opacity: 0.7;">+60% Deep acoustic detection range</div>
            </button>
            <button style="text-align: left; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.2); color: #fff; padding: 8px; border-radius: 3px; cursor: pointer;">
              <div style="font-weight: 600; color: #ff5252;">RBU-6000 ASW Rocket Mortars</div>
              <div style="font-size: 10px; opacity: 0.7;">Multi-round pattern anti-submarine burst</div>
            </button>
          </div>
        </div>
      </div>
    `;

    modal.querySelector('.close-btn')?.addEventListener('click', () => this.closeAll());

    this.overlayContainer.style.pointerEvents = 'auto';
    this.overlayContainer.appendChild(modal);
    this.loadoutModal = modal;
  }

  public showCamoSelector(): void {
    this.closeAll();

    const modal = document.createElement('div');
    modal.style.cssText = this.getModalStyle();
    modal.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid rgba(0, 230, 118, 0.4); padding-bottom: 10px; margin-bottom: 15px;">
        <h2 style="margin: 0; color: #00e676; font-size: 20px;">NAVAL CAMOUFLAGE SKINS</h2>
        <button class="close-btn" style="background: none; border: none; color: #fff; font-size: 18px; cursor: pointer;">✕</button>
      </div>
      <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px;">
        ${this.getCamoCardHtml('HAZE_GREY', 'Modern Haze Grey', 'Standard naval issue non-reflective tactical grey.', '#546274')}
        ${this.getCamoCardHtml('DAZZLE', 'WWI Dazzle Camo', 'High contrast geometric disruptive camouflage.', '#1a2436')}
        ${this.getCamoCardHtml('ARCTIC_SPLINTER', 'Arctic Splinter', 'Sharp cyan & white polygonal shards.', '#00bcd4')}
        ${this.getCamoCardHtml('STEALTH_CARBON', 'Stealth Carbon', 'Radar-absorbent matte charcoal coating.', '#212121')}
      </div>
    `;

    const btns = modal.querySelectorAll('.camo-select-btn');
    btns.forEach((b) => {
      b.addEventListener('click', (e) => {
        const camo = (e.currentTarget as HTMLElement).getAttribute('data-camo') as CamoType;
        if (camo) {
          this.selectedCamo = camo;
          if (this.onSelectCamoCb) this.onSelectCamoCb(camo);
          this.showCamoSelector();
        }
      });
    });

    modal.querySelector('.close-btn')?.addEventListener('click', () => this.closeAll());

    this.overlayContainer.style.pointerEvents = 'auto';
    this.overlayContainer.appendChild(modal);
    this.camoModal = modal;
  }

  private getCamoCardHtml(camo: CamoType, title: string, desc: string, previewColor: string): string {
    const isSelected = this.selectedCamo === camo;
    return `
      <div style="
        background: rgba(14, 26, 44, 0.9);
        border: 2px solid ${isSelected ? '#00e676' : 'rgba(255,255,255,0.15)'};
        border-radius: 4px;
        padding: 12px;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        gap: 10px;
      ">
        <div style="height: 60px; background: ${previewColor}; border-radius: 3px; display: flex; align-items: center; justify-content: center; font-weight: 700; color: #fff;">
          ${title}
        </div>
        <div style="font-size: 11px; color: #bbb;">${desc}</div>
        <button class="camo-select-btn" data-camo="${camo}" style="
          background: ${isSelected ? '#00e676' : '#0288d1'};
          border: none;
          border-radius: 3px;
          color: #fff;
          padding: 8px;
          font-weight: 700;
          font-size: 11px;
          cursor: pointer;
        ">
          ${isSelected ? 'EQUIPPED' : 'EQUIP'}
        </button>
      </div>
    `;
  }

  private getModalStyle(): string {
    return `
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 780px;
      max-width: 90vw;
      background: rgba(8, 16, 28, 0.96);
      border: 1px solid #00e676;
      border-radius: 6px;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.7);
      padding: 20px;
      color: #fff;
      user-select: none;
    `;
  }

  public closeAll(): void {
    if (this.techTreeModal) {
      this.techTreeModal.remove();
      this.techTreeModal = null;
    }
    if (this.loadoutModal) {
      this.loadoutModal.remove();
      this.loadoutModal = null;
    }
    if (this.camoModal) {
      this.camoModal.remove();
      this.camoModal = null;
    }
    this.overlayContainer.style.pointerEvents = 'none';
  }

  public isAnyOpen(): boolean {
    return !!(this.techTreeModal || this.loadoutModal || this.camoModal);
  }
}
