/**
 * Anti-Betrayal Fleet, Karma, Non-Aggression Pact (NAP) & Mercy Hospital Models
 * Clean-Room implementation for NavalCommand.io
 */

// ============================================================================
// CONSTANTS
// ============================================================================

/** Maximum number of active/visible fleets allowed in a match simultaneously */
export const MAX_VISIBLE_FLEETS = 5;

/** Maximum allowed members per fleet */
export const MAX_FLEET_MEMBERS = 8;

/** Duration of the mandatory Non-Aggression Pact upon leaving or being kicked (seconds) */
export const NAP_DURATION_SECONDS = 15.0;

/** Duration of the post-NAP vulnerability window during which attacking former fleetmates is a betrayal (seconds) */
export const BETRAYAL_WINDOW_SECONDS = 30.0;

/** Karma penalty subtracted upon attacking former fleetmates during the betrayal window */
export const BETRAYAL_KARMA_PENALTY = 25;

/** Mercy-class Hospital Ship repair aura cooldown in seconds */
export const REPAIR_AURA_COOLDOWN = 30.0;

/** Mercy-class Hospital Ship repair aura radius in meters */
export const REPAIR_AURA_RADIUS = 150.0;

/** Percentage of target maximum HP restored by the Mercy repair aura (50%) */
export const REPAIR_AURA_HP_PCT = 0.50;

// ============================================================================
// KARMA TYPES & FSM
// ============================================================================

export type KarmaStatus = 'LOYAL' | 'SUSPECT' | 'TRAITOR';

export const KARMA_STATUS_THRESHOLDS = {
  LOYAL_MIN: 80,
  SUSPECT_MIN: 40,
} as const;

export const KARMA_COLORS = {
  LOYAL: '#00FF88',   // Green / honorable
  SUSPECT: '#FFCC00', // Yellow / untrusted
  TRAITOR: '#FF3333', // Red / rogue traitor
} as const;

export interface KarmaProfile {
  playerId: number;
  karmaScore: number; // Strictly clamped to 0..100
  status: KarmaStatus;
  color: string;
}

/**
 * Clamps karma to the valid integer range [0, 100].
 */
export function clampKarma(score: number): number {
  if (Number.isNaN(score)) return 0;
  return Math.max(0, Math.min(100, Math.round(score)));
}

/**
 * Determines KarmaStatus from a numeric karma score according to the FSM:
 * - >= 80: LOYAL
 * - 40..79: SUSPECT
 * - < 40: TRAITOR
 */
export function getKarmaStatus(score: number): KarmaStatus {
  const clamped = clampKarma(score);
  if (clamped >= KARMA_STATUS_THRESHOLDS.LOYAL_MIN) {
    return 'LOYAL';
  }
  if (clamped >= KARMA_STATUS_THRESHOLDS.SUSPECT_MIN) {
    return 'SUSPECT';
  }
  return 'TRAITOR';
}

/**
 * Resolves the visual name hex color based on karma status or score.
 */
export function getKarmaColor(scoreOrStatus: number | KarmaStatus): string {
  const status = typeof scoreOrStatus === 'number' ? getKarmaStatus(scoreOrStatus) : scoreOrStatus;
  switch (status) {
    case 'LOYAL':
      return KARMA_COLORS.LOYAL;
    case 'SUSPECT':
      return KARMA_COLORS.SUSPECT;
    case 'TRAITOR':
      return KARMA_COLORS.TRAITOR;
    default:
      return KARMA_COLORS.LOYAL;
  }
}

/**
 * Creates a default KarmaProfile for a player with initial score (defaults to 100).
 */
export function createKarmaProfile(playerId: number, initialScore = 100): KarmaProfile {
  const score = clampKarma(initialScore);
  const status = getKarmaStatus(score);
  return {
    playerId,
    karmaScore: score,
    status,
    color: getKarmaColor(status),
  };
}

/**
 * Applies betrayal penalty (-25) to a karma score, clamped to [0, 100].
 */
export function applyBetrayalPenalty(currentKarma: number): {
  newKarma: number;
  penalty: number;
  oldStatus: KarmaStatus;
  newStatus: KarmaStatus;
  statusChanged: boolean;
} {
  const oldScore = clampKarma(currentKarma);
  const oldStatus = getKarmaStatus(oldScore);
  const newScore = clampKarma(oldScore - BETRAYAL_KARMA_PENALTY);
  const newStatus = getKarmaStatus(newScore);

  return {
    newKarma: newScore,
    penalty: BETRAYAL_KARMA_PENALTY,
    oldStatus,
    newStatus,
    statusChanged: oldStatus !== newStatus,
  };
}

// ============================================================================
// FLEET & NAP DATA STRUCTURES
// ============================================================================

export interface FleetState {
  fleetId: number;
  name: string;
  leaderId: number;
  memberIds: Set<number>;
  maxMembers: number;
  score: number;
  kills: number;
  createdAt: number;
}

export interface FleetInvite {
  fleetId: number;
  inviterId: number;
  targetId: number;
  createdAt: number;
  expiresAt?: number;
}

export interface NonAggressionPact {
  playerA: number;
  playerB: number;
  remainingSeconds: number;     // While > 0: mutual 0 damage
  expiredSeconds: number;       // Elapsed seconds since remainingSeconds reached 0 (for 30s betrayal window)
  betrayalPenalized: boolean;   // Debounce flag: has betrayal penalty been levied during this window
}

// ============================================================================
// MERCY HOSPITAL SHIP REPAIR AURA
// ============================================================================

export interface HospitalShipTarget {
  id: number;
  fleetId?: number;
  hullHp: number;
  maxHp: number;
  isDestroyed?: boolean;
  position: { x: number; y: number };
}

export interface MercyRepairResult {
  cooldownTriggered: boolean;
  repairedTargets: Array<{
    targetId: number;
    healAmount: number;
    newHp: number;
  }>;
}

/**
 * Computes Mercy Hospital Ship 50% HP repair aura pulse.
 * If cooldown is <= 0 and any eligible damaged allies (or self) are within range,
 * heals them for 50% of maxHp (up to maxHp) and triggers cooldown.
 */
export function calculateMercyRepairAura(
  hospitalShip: {
    id: number;
    fleetId?: number;
    repairCooldown: number;
    position: { x: number; y: number };
  },
  targets: HospitalShipTarget[],
  options?: {
    radius?: number;
    healPct?: number;
    cooldown?: number;
  }
): MercyRepairResult {
  if (hospitalShip.repairCooldown > 0) {
    return { cooldownTriggered: false, repairedTargets: [] };
  }

  const radius = options?.radius ?? REPAIR_AURA_RADIUS;
  const healPct = options?.healPct ?? REPAIR_AURA_HP_PCT;
  const radiusSq = radius * radius;

  const eligibleDamaged: HospitalShipTarget[] = [];

  for (const target of targets) {
    if (target.isDestroyed) continue;
    if (target.hullHp >= target.maxHp) continue;

    // Check ally eligibility:
    // 1. Self is always an ally
    // 2. If hospital ship belongs to a fleet, target must belong to the same fleet
    // 3. If hospital ship has no fleet, it only heals itself or neutral allies without fleet conflict
    const isSelf = target.id === hospitalShip.id;
    const isFleetAlly =
      hospitalShip.fleetId !== undefined &&
      hospitalShip.fleetId > 0 &&
      target.fleetId === hospitalShip.fleetId;

    if (!isSelf && !isFleetAlly) {
      continue;
    }

    const dx = target.position.x - hospitalShip.position.x;
    const dy = target.position.y - hospitalShip.position.y;
    const distSq = dx * dx + dy * dy;

    if (distSq <= radiusSq) {
      eligibleDamaged.push(target);
    }
  }

  if (eligibleDamaged.length === 0) {
    return { cooldownTriggered: false, repairedTargets: [] };
  }

  const repairedTargets = eligibleDamaged.map((target) => {
    const missingHp = target.maxHp - target.hullHp;
    const baseHeal = Math.round(target.maxHp * healPct);
    const healAmount = Math.min(missingHp, baseHeal);
    const newHp = target.hullHp + healAmount;
    return {
      targetId: target.id,
      healAmount,
      newHp,
    };
  });

  return {
    cooldownTriggered: true,
    repairedTargets,
  };
}

// ============================================================================
// FLEET MANAGER CLASS
// ============================================================================

export class FleetManager {
  private fleets: Map<number, FleetState> = new Map();
  private playerToFleet: Map<number, number> = new Map();
  private pendingInvites: Map<string, FleetInvite> = new Map();
  private naps: Map<string, NonAggressionPact> = new Map();
  private karmaProfiles: Map<number, KarmaProfile> = new Map();
  private nextFleetId = 1;

  /**
   * Helper to produce symmetric NAP keys regardless of argument order.
   */
  private makeNapKey(idA: number, idB: number): string {
    const [min, max] = idA < idB ? [idA, idB] : [idB, idA];
    return `${min}:${max}`;
  }

  // --------------------------------------------------------------------------
  // FLEET QUERIES
  // --------------------------------------------------------------------------

  public getFleet(fleetId: number): FleetState | undefined {
    return this.fleets.get(fleetId);
  }

  public getFleetByMember(memberId: number): FleetState | undefined {
    const fleetId = this.playerToFleet.get(memberId);
    return fleetId !== undefined ? this.fleets.get(fleetId) : undefined;
  }

  public getActiveFleetCount(): number {
    return this.fleets.size;
  }

  /**
   * Returns up to MAX_VISIBLE_FLEETS (5) sorted by score descending,
   * kills descending, and member count descending.
   */
  public getVisibleFleets(): FleetState[] {
    return Array.from(this.fleets.values())
      .sort((a, b) => {
        if (b.score !== a.score) return b.score - a.score;
        if (b.kills !== a.kills) return b.kills - a.kills;
        if (b.memberIds.size !== a.memberIds.size) return b.memberIds.size - a.memberIds.size;
        return a.createdAt - b.createdAt;
      })
      .slice(0, MAX_VISIBLE_FLEETS);
  }

  // --------------------------------------------------------------------------
  // FLEET LIFECYCLE WORKFLOWS
  // --------------------------------------------------------------------------

  /**
   * Creates a new fleet led by leaderId.
   * Rejects if MAX_VISIBLE_FLEETS (5) limit is reached, or if player is already in a fleet.
   */
  public createFleet(leaderId: number, name?: string): FleetState | null {
    if (this.fleets.size >= MAX_VISIBLE_FLEETS) {
      return null;
    }
    if (this.playerToFleet.has(leaderId)) {
      return null;
    }

    const fleetId = this.nextFleetId++;
    const fleet: FleetState = {
      fleetId,
      name: name && name.trim().length > 0 ? name.trim() : `Fleet ${fleetId}`,
      leaderId,
      memberIds: new Set([leaderId]),
      maxMembers: MAX_FLEET_MEMBERS,
      score: 0,
      kills: 0,
      createdAt: Date.now(),
    };

    this.fleets.set(fleetId, fleet);
    this.playerToFleet.set(leaderId, fleetId);
    this.getOrCreateKarmaProfile(leaderId);

    return fleet;
  }

  /**
   * Invites targetId to join fleetId.
   * Inviter must belong to the fleet, target must not already belong to any fleet,
   * and fleet must not be full.
   */
  public inviteMember(
    fleetId: number,
    inviterId: number,
    targetId: number,
    expiresAt?: number
  ): boolean {
    const fleet = this.fleets.get(fleetId);
    if (!fleet) return false;
    if (!fleet.memberIds.has(inviterId)) return false;
    if (this.playerToFleet.has(targetId)) return false;
    if (fleet.memberIds.size >= fleet.maxMembers) return false;

    const key = `${fleetId}:${targetId}`;
    this.pendingInvites.set(key, {
      fleetId,
      inviterId,
      targetId,
      createdAt: Date.now(),
      expiresAt,
    });

    return true;
  }

  /**
   * Returns all pending invites for targetId, or all pending invites if targetId is omitted.
   */
  public getPendingInvites(targetId?: number): FleetInvite[] {
    const all = Array.from(this.pendingInvites.values());
    if (targetId === undefined) return all;
    return all.filter((inv) => inv.targetId === targetId);
  }

  /**
   * Cancels a pending invite.
   */
  public cancelInvite(fleetId: number, targetId: number): boolean {
    const key = `${fleetId}:${targetId}`;
    return this.pendingInvites.delete(key);
  }

  /**
   * Joins targetId to fleetId.
   * If requireInvite is true, a pending invite must exist.
   */
  public joinFleet(fleetId: number, targetId: number, requireInvite = false): boolean {
    const fleet = this.fleets.get(fleetId);
    if (!fleet) return false;
    if (this.playerToFleet.has(targetId)) return false;
    if (fleet.memberIds.size >= fleet.maxMembers) return false;

    const inviteKey = `${fleetId}:${targetId}`;
    if (requireInvite) {
      const invite = this.pendingInvites.get(inviteKey);
      if (!invite) return false;
      if (invite.expiresAt && Date.now() > invite.expiresAt) {
        this.pendingInvites.delete(inviteKey);
        return false;
      }
    }

    // Clean up pending invite on join
    this.pendingInvites.delete(inviteKey);

    fleet.memberIds.add(targetId);
    this.playerToFleet.set(targetId, fleetId);
    this.getOrCreateKarmaProfile(targetId);

    return true;
  }

  /**
   * Member voluntarily leaves their fleet.
   * Automatically establishes 15-second Non-Aggression Pact (zero mutual damage)
   * between the departing member and all remaining fleet members.
   */
  public leaveFleet(memberId: number): {
    success: boolean;
    formerMemberId: number;
    remainingMemberIds: number[];
    createdNaps: NonAggressionPact[];
  } {
    const fleetId = this.playerToFleet.get(memberId);
    if (fleetId === undefined) {
      return { success: false, formerMemberId: memberId, remainingMemberIds: [], createdNaps: [] };
    }

    const fleet = this.fleets.get(fleetId);
    if (!fleet) {
      this.playerToFleet.delete(memberId);
      return { success: false, formerMemberId: memberId, remainingMemberIds: [], createdNaps: [] };
    }

    fleet.memberIds.delete(memberId);
    this.playerToFleet.delete(memberId);

    const remaining = Array.from(fleet.memberIds);
    const createdNaps: NonAggressionPact[] = [];

    // Automatically establish 15-second mutual NAP with all remaining fleet members
    for (const remId of remaining) {
      const nap = this.setNAP(memberId, remId, NAP_DURATION_SECONDS);
      createdNaps.push(nap);
    }

    // Handle leader departure or fleet empty
    if (fleet.memberIds.size === 0) {
      this.fleets.delete(fleetId);
    } else if (fleet.leaderId === memberId) {
      fleet.leaderId = remaining[0];
    }

    return {
      success: true,
      formerMemberId: memberId,
      remainingMemberIds: remaining,
      createdNaps,
    };
  }

  /**
   * Leader kicks a member from the fleet.
   * Automatically establishes 15-second Non-Aggression Pact (zero mutual damage)
   * between the kicked member and all remaining fleet members.
   */
  public kickMember(
    leaderId: number,
    targetId: number
  ): {
    success: boolean;
    kickedMemberId: number;
    remainingMemberIds: number[];
    createdNaps: NonAggressionPact[];
  } {
    if (leaderId === targetId) {
      return { success: false, kickedMemberId: targetId, remainingMemberIds: [], createdNaps: [] };
    }

    const fleetId = this.playerToFleet.get(leaderId);
    if (fleetId === undefined) {
      return { success: false, kickedMemberId: targetId, remainingMemberIds: [], createdNaps: [] };
    }

    const fleet = this.fleets.get(fleetId);
    if (!fleet || fleet.leaderId !== leaderId) {
      return { success: false, kickedMemberId: targetId, remainingMemberIds: [], createdNaps: [] };
    }

    if (!fleet.memberIds.has(targetId)) {
      return { success: false, kickedMemberId: targetId, remainingMemberIds: [], createdNaps: [] };
    }

    fleet.memberIds.delete(targetId);
    this.playerToFleet.delete(targetId);

    const remaining = Array.from(fleet.memberIds);
    const createdNaps: NonAggressionPact[] = [];

    // Automatically establish 15-second mutual NAP with all remaining members
    for (const remId of remaining) {
      const nap = this.setNAP(targetId, remId, NAP_DURATION_SECONDS);
      createdNaps.push(nap);
    }

    return {
      success: true,
      kickedMemberId: targetId,
      remainingMemberIds: remaining,
      createdNaps,
    };
  }

  /**
   * Disbands an entire fleet, establishing pairwise 15-second NAPs
   * between all former members.
   */
  public disbandFleet(
    fleetId: number,
    requesterId?: number
  ): {
    success: boolean;
    formerMemberIds: number[];
    createdNaps: NonAggressionPact[];
  } {
    const fleet = this.fleets.get(fleetId);
    if (!fleet) {
      return { success: false, formerMemberIds: [], createdNaps: [] };
    }

    if (requesterId !== undefined && fleet.leaderId !== requesterId) {
      return { success: false, formerMemberIds: [], createdNaps: [] };
    }

    const members = Array.from(fleet.memberIds);
    for (const m of members) {
      this.playerToFleet.delete(m);
    }
    this.fleets.delete(fleetId);

    const createdNaps: NonAggressionPact[] = [];
    // Establish pairwise 15-second NAPs
    for (let i = 0; i < members.length; i++) {
      for (let j = i + 1; j < members.length; j++) {
        const nap = this.setNAP(members[i], members[j], NAP_DURATION_SECONDS);
        createdNaps.push(nap);
      }
    }

    return {
      success: true,
      formerMemberIds: members,
      createdNaps,
    };
  }

  // --------------------------------------------------------------------------
  // NON-AGGRESSION PACTS & COMBAT PERMISSION
  // --------------------------------------------------------------------------

  /**
   * Sets or refreshes a mutual Non-Aggression Pact between playerA and playerB.
   */
  public setNAP(playerA: number, playerB: number, durationSeconds = NAP_DURATION_SECONDS): NonAggressionPact {
    const key = this.makeNapKey(playerA, playerB);
    const nap: NonAggressionPact = {
      playerA,
      playerB,
      remainingSeconds: Math.max(0, durationSeconds),
      expiredSeconds: 0,
      betrayalPenalized: false,
    };
    this.naps.set(key, nap);
    return nap;
  }

  /**
   * Retrieves active or tracking NAP between two players.
   */
  public getNAP(playerA: number, playerB: number): NonAggressionPact | undefined {
    return this.naps.get(this.makeNapKey(playerA, playerB));
  }

  /**
   * Checks if an active Non-Aggression Pact exists (remainingSeconds > 0).
   */
  public hasActiveNAP(playerA: number, playerB: number): boolean {
    const nap = this.getNAP(playerA, playerB);
    return !!nap && nap.remainingSeconds > 0;
  }

  /**
   * Determines whether player attackerId can damage victimId:
   * Returns false if:
   * 1. Self damage check (attackerId === victimId)
   * 2. Both players are in the same fleet (friendly fire protection)
   * 3. An active Non-Aggression Pact exists between them (remainingSeconds > 0)
   */
  public canDamage(attackerId: number, victimId: number): boolean {
    if (attackerId === victimId) return false;

    const fleetA = this.playerToFleet.get(attackerId);
    const fleetB = this.playerToFleet.get(victimId);
    if (fleetA !== undefined && fleetB !== undefined && fleetA === fleetB) {
      return false; // Friendly fleetmates cannot damage each other
    }

    if (this.hasActiveNAP(attackerId, victimId)) {
      return false; // Non-Aggression Pact mutual 0 damage
    }

    return true;
  }

  /**
   * Checks whether attackerId is attacking victimId inside the 30-second post-NAP betrayal window.
   */
  public isInBetrayalWindow(attackerId: number, victimId: number): boolean {
    const nap = this.getNAP(attackerId, victimId);
    if (!nap) return false;
    if (nap.remainingSeconds > 0) return false; // Still in NAP, damage is 0, not betrayal yet
    return nap.expiredSeconds < BETRAYAL_WINDOW_SECONDS && !nap.betrayalPenalized;
  }

  /**
   * Records an attack attempt.
   * If an active NAP is running or players share a fleet, returns canDamage = false.
   * If the attack occurs during the 30s post-NAP betrayal window, applies -25 Karma penalty
   * clamped to [0, 100], updates reputation status, and debounces future attacks during the same window.
   */
  public recordAttack(
    attackerId: number,
    victimId: number
  ): {
    canDamage: boolean;
    betrayalPenaltyApplied: boolean;
    karmaLoss: number;
    newKarma: number;
    newStatus: KarmaStatus;
  } {
    const allowed = this.canDamage(attackerId, victimId);
    if (!allowed) {
      const profile = this.getOrCreateKarmaProfile(attackerId);
      return {
        canDamage: false,
        betrayalPenaltyApplied: false,
        karmaLoss: 0,
        newKarma: profile.karmaScore,
        newStatus: profile.status,
      };
    }

    const inBetrayal = this.isInBetrayalWindow(attackerId, victimId);
    if (inBetrayal) {
      const nap = this.getNAP(attackerId, victimId);
      if (nap) {
        nap.betrayalPenalized = true; // Debounce so multiple projectiles don't stack penalties
      }
      const change = this.modifyKarma(attackerId, -BETRAYAL_KARMA_PENALTY);
      return {
        canDamage: true,
        betrayalPenaltyApplied: true,
        karmaLoss: BETRAYAL_KARMA_PENALTY,
        newKarma: change.newKarma,
        newStatus: change.newStatus,
      };
    }

    const profile = this.getOrCreateKarmaProfile(attackerId);
    return {
      canDamage: true,
      betrayalPenaltyApplied: false,
      karmaLoss: 0,
      newKarma: profile.karmaScore,
      newStatus: profile.status,
    };
  }

  /**
   * Advances simulation timers for all active NAPs and betrayal windows.
   */
  public tickNAPs(dt: number): void {
    if (dt <= 0) return;

    for (const [key, nap] of this.naps.entries()) {
      if (nap.remainingSeconds > 0) {
        nap.remainingSeconds = Math.max(0, nap.remainingSeconds - dt);
        if (nap.remainingSeconds === 0) {
          nap.expiredSeconds = 0;
        }
      } else {
        nap.expiredSeconds += dt;
        // Clean up expired NAPs past the betrayal window to free memory
        if (nap.expiredSeconds >= BETRAYAL_WINDOW_SECONDS) {
          this.naps.delete(key);
        }
      }
    }
  }

  // --------------------------------------------------------------------------
  // KARMA PROFILES & REPUTATION MANAGEMENT
  // --------------------------------------------------------------------------

  public getOrCreateKarmaProfile(playerId: number): KarmaProfile {
    let profile = this.karmaProfiles.get(playerId);
    if (!profile) {
      profile = createKarmaProfile(playerId);
      this.karmaProfiles.set(playerId, profile);
    }
    return profile;
  }

  public getKarmaProfile(playerId: number): KarmaProfile | undefined {
    return this.karmaProfiles.get(playerId);
  }

  public getKarma(playerId: number): number {
    return this.getOrCreateKarmaProfile(playerId).karmaScore;
  }

  public getKarmaStatusForPlayer(playerId: number): KarmaStatus {
    return this.getOrCreateKarmaProfile(playerId).status;
  }

  public getKarmaColorForPlayer(playerId: number): string {
    return this.getOrCreateKarmaProfile(playerId).color;
  }

  /**
   * Modifies a player's karma score by delta, strictly clamped to [0, 100].
   * Updates status FSM and color accordingly.
   */
  public modifyKarma(
    playerId: number,
    delta: number
  ): {
    oldKarma: number;
    newKarma: number;
    oldStatus: KarmaStatus;
    newStatus: KarmaStatus;
    statusChanged: boolean;
    profile: KarmaProfile;
  } {
    const profile = this.getOrCreateKarmaProfile(playerId);
    const oldKarma = profile.karmaScore;
    const oldStatus = profile.status;
    const newKarma = clampKarma(oldKarma + delta);
    const newStatus = getKarmaStatus(newKarma);
    const statusChanged = oldStatus !== newStatus;

    profile.karmaScore = newKarma;
    profile.status = newStatus;
    profile.color = getKarmaColor(newStatus);

    return {
      oldKarma,
      newKarma,
      oldStatus,
      newStatus,
      statusChanged,
      profile,
    };
  }

  public setKarma(playerId: number, score: number): KarmaProfile {
    const profile = this.getOrCreateKarmaProfile(playerId);
    profile.karmaScore = clampKarma(score);
    profile.status = getKarmaStatus(profile.karmaScore);
    profile.color = getKarmaColor(profile.status);
    return profile;
  }

  /**
   * Cleans up all state for a departing player.
   */
  public removePlayer(playerId: number): void {
    this.leaveFleet(playerId);
    this.karmaProfiles.delete(playerId);
    // Remove pending invites
    for (const [key, inv] of this.pendingInvites.entries()) {
      if (inv.inviterId === playerId || inv.targetId === playerId) {
        this.pendingInvites.delete(key);
      }
    }
  }
}
