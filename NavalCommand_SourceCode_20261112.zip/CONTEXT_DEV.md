# CONTEXT_DEV: Tóm Tắt Toàn Bộ Bối Cảnh Phát Triển NavalCommand.io

> **Thời điểm cập nhật:** 2026-11-12 21:22:00  
> **Trạng thái hệ thống:** Tất cả subagent đã tạm dừng an toàn theo yêu cầu người dùng. Toàn bộ **10/10 bộ kiểm thử (236/236 bài kiểm thử tự động: Unit, Adversarial & 10,000-tick Stability)** đang **PASS 100%**, `npx tsc --noEmit` đạt **0 lỗi**.

---

## 1. Mục Tiêu Hiện Tại Của Dự Án & Tech Stack Đang Dùng

### Mục tiêu dự án
Xây dựng **NavalCommand.io** — tựa game hải chiến chiến thuật nhiều người chơi thời gian thực trên trình duyệt (`.io`), kế nhiệm và giải quyết triệt để các hạn chế của `mk48.io`:
- **100% Clean-Room Development:** Tự viết mới hoàn toàn mã nguồn, đồ họa Vector 2D WebGL và âm thanh tổng hợp Web Audio; tuyệt đối không sao chép mã nguồn hay tài nguyên vi phạm bản quyền và giấy phép `AGPL-3.0` của `SoftbearStudios/mk48`.
- **Roster 28+ tàu qua 10 cấp độ & 8 lớp tàu:** Bao gồm Tàu tuần tra/phóng lôi, Khu trục hạm, Tuần dương hạm, Thiết giáp hạm, Tàu ngầm hạt nhân, Tàu sân bay, Tàu phá băng & Tàu vét bùn, cùng lớp **Tàu hỗ trợ chiến thuật** (Tàu bệnh viện lớp *Mercy* cứu hộ/hồi máu, Tàu chở dầu có bãi đáp trực thăng, Tàu công binh xây giàn khoan).
- **10 hệ thống khí tài chuyên biệt:** Pháo hải quân có góc bắn tháp pháo, Ngư lôi thẳng & tự dẫn + Mồi nhử Decoys, Tên lửa hành trình, Pháo phản lực Rockets, Ngư lôi tên lửa Rocket Torpedoes, Tên lửa phòng không SAM/CIWS, Mìn sâu, Thủy lôi, Phi đội máy bay & trực thăng thả phao thủy âm (Sonar Buoys), và Thiết bị bồi đắp địa hình (Depositor/Dredger).
- **Cân bằng Kéo-Búa-Bao 3 tầng:** Tàu ngầm có độ trễ chuyển trạng thái Lặn/Nổi 4–6s, bắt buộc giữ ở độ sâu kính tiềm vọng khi dẫn bắn tên lửa, nút khóa tốc độ di chuyển êm (*Stealth Cruise Toggle*) dưới ngưỡng bọt khí; máy bay phải giảm tốc độ/bay treo thả Phao thủy âm mới phát hiện được tàu ngầm lặn sâu; Tàu mặt nước có kỹ năng Tác chiến điện tử (*ECM Jamming*) làm lệch tên lửa.
- **3 chế độ chơi & Chống phản bội Hạm đội:** Free-For-All Sandbox, King of the Hill & Convoy Escort (15 phút), Đấu trường 1v1 Private Battle Arena; áp dụng bộ đếm bảo hộ 15 giây khi rời đội/bị kích kèm hệ thống Uy tín (Karma).
- **Meta-Progression & Thương mại hóa Web:** Cây công nghệ (Tech Tree), tùy biến trang bị (Loadouts), trang phục ngụy trang (Camouflage Skins) và adapter tích hợp SDK cổng game (CrazyGames, Poki, Playgama, Y8) giữ dung lượng bản build dưới 15 MB.

### Tech Stack đang dùng
- **Ngôn ngữ:** TypeScript (ES2022, NodeNext modules).
- **Lõi dùng chung (`common/`):** TypeScript thuần không phụ thuộc thư viện ngoài cho toán học vector 2D, va chạm đa giác SAT, thủy động lực học tất định, động học 10 hệ vũ khí, hệ thống cảm biến 3 tầng, quản lý Hạm đội/Karma và giao thức mạng nhị phân.
- **Client (`client/`):** Pixi.js (v8) cho dựng hình đồ họa Vector WebGL, HTML5/CSS cho Tactical HUD, Web Audio API cho âm thanh tổng hợp procedural, Vite cho bundler.
- **Server (`server/`):** Node.js / Bun Authoritative Server vòng lặp 15–20 Hz tick rate, WebSocket nhị phân (gói tin `ArrayBuffer` 28-byte snapshot, không dùng JSON), Spatial Grid quản lý thực thể.
- **Testing & Quality Assurance:** Vitest cho Unit & Stress tests, TypeScript (`tsc`) kiểm tra kiểu tĩnh.

---

## 2. Các File & Tính Năng Đã Hoàn Thành Tính Đến Phiên 2026-11-12

### A. Milestone M1: Hoàn thành 100% & Đạt chứng chỉ Forensic Clean-Room
- [`common/math/vector2.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/common/math/vector2.ts), [`common/math/polygon.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/common/math/polygon.ts)
- [`common/models/ships.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/common/models/ships.ts), [`common/models/terrain.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/common/models/terrain.ts)
- [`common/simulation/hydrodynamics.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/common/simulation/hydrodynamics.ts), [`common/simulation/terrain_engine.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/common/simulation/terrain_engine.ts), [`common/simulation/resource_engine.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/common/simulation/resource_engine.ts), [`common/simulation/collision.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/common/simulation/collision.ts)

### B. Milestone M2: Hoàn thành 100% & Đạt chứng chỉ Forensic Clean-Room (Phiên 2026-11-12)
- [`common/models/weapons.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/common/models/weapons.ts) & [`common/simulation/weapon_kinematics.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/common/simulation/weapon_kinematics.ts): Hoàn thiện 100% động học của 10 hệ khí tài.
- [`server/core/game_server.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/server/core/game_server.ts): Đã tích hợp hoàn chỉnh `WeaponKinematicsEngine`, `TerrainEngine`, miễn nhiễm độ sâu tàu ngầm `DEEP` với đạn pháo/tên lửa mặt nước, CIWS/SAM đánh chặn, mìn sâu, thủy lôi, phi đội máy bay thả phao thủy âm `SonarBuoy`, và tàu vét bùn `Dredger`.
- Bộ kiểm thử M2 mới (104 tests PASS 100%):
  - [`tests/unit/weapons.test.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/tests/unit/weapons.test.ts) (55 tests).
  - [`tests/unit/adversarial_weapons_server.test.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/tests/unit/adversarial_weapons_server.test.ts) (20 tests).
  - [`tests/unit/adversarial_weapons_m2.test.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/tests/unit/adversarial_weapons_m2.test.ts) (29 tests).

### C. Milestone M3: Đã hoàn thành ~75% (Phiên 2026-11-12)
1. **Hệ thống Cảm biến 3 Tầng (`common/sensors/`) — Đã viết xong 100% code:**
   - [`common/sensors/raycasting.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/common/sensors/raycasting.ts): Kiểm tra tầm nhìn thẳng (LoS) và che khuất Radar bởi đa giác đảo.
   - [`common/sensors/acoustic_model.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/common/sensors/acoustic_model.ts): Mô hình độ ồn bọt khí thủy âm $\text{Noise}_{\text{cav}} \propto (v - V_{\text{cav}})^{2.5}$, Sonar chủ động $2\times$ phát hiện ngược và Phao thủy âm `SonarBuoy`.
   - [`common/sensors/sensor_suite.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/common/sensors/sensor_suite.ts): Tổ hợp cảm biến Visual + Radar (có nhiễu ECM) + Acoustic và FSM 5 trạng thái tin cậy mục tiêu.
2. **Hệ thống Hạm đội, Liên minh, NAP 15s, Karma & Mercy Hospital (`common/models/fleet.ts`) — Hoàn thành 100% kèm Unit Tests:**
   - [`common/models/fleet.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/common/models/fleet.ts): Quản lý tối đa 5 hạm đội, tạo/mời/rời/kick, hiệp ước bất khả xâm phạm NAP 15s, máy trạng thái Karma (`LOYAL`, `SUSPECT`, `TRAITOR`), và kỹ năng hồi máu tàu bệnh viện *Mercy*.
   - [`tests/unit/fleet_karma.test.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/tests/unit/fleet_karma.test.ts) (**36/36 tests PASS**).
3. **Các Chế độ Chơi (`common/models/game_modes.ts` & `server/modes/`):**
   - Đã hoàn thành [`common/models/game_modes.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/common/models/game_modes.ts) và [`server/modes/ffa_sandbox.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/server/modes/ffa_sandbox.ts).
   - Đã sửa lỗi import TypeScript tại [`client/src/hud/menus.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/client/src/hud/menus.ts) và [`server/ai/bot_controller.ts`](file:///C:/Users/Administrator/.gemini/antigravity/scratch/naval_warfare_io/server/ai/bot_controller.ts).

---

## 3. Các Phần Đang Dang Dở Cần Làm Tiếp Ở Phiên Sau

1. **Hoàn tất nốt phần còn lại của Milestone M3:**
   - Viết 2 chế độ chơi còn lại: `server/modes/koth_convoy.ts` (King of the Hill & Convoy Escort 900s) và `server/modes/duel_arena.ts` (Đấu trường 1v1).
   - Viết bộ kiểm thử `tests/unit/sensors_asw.test.ts` (cho `common/sensors/`) và `tests/unit/game_modes.test.ts` (cho 3 chế độ chơi).
2. **Hoàn thiện Milestone M4 (Netcode & Loadout Validator):**
   - Tạo `server/netcode/ws_server.ts`, `server/index.ts`, và `server/progression/loadout_validator.ts`.
   - Đồng bộ hóa `client/src/netcode/binary_client.ts` với `common/protocol/serializer.ts`.
3. **Hoàn thiện Milestone M5 (WebGL Client Entry Points & Chạy Trình Duyệt):**
   - Tạo `client/index.html`, `client/src/main.ts`, `client/src/app.ts` và thêm script `"dev": "vite"` vào `package.json`.

---

## 4. Các Bước Chính Xác Cần Làm Ngay Khi Mở Lại Dự Án

### Bước 1: Kiểm tra môi trường & chạy bộ test 236 tests
```powershell
cmd.exe /c "set PATH=C:\Users\Administrator\nodejs;%PATH% && cd C:\Users\Administrator\.gemini\antigravity\scratch\naval_warfare_io && npx tsc --noEmit && npx vitest run"
```
*(Kỳ vọng: `tsc` 0 lỗi, 10 test suites, 236 tests passed).*

### Bước 2: Tiếp tục hoàn thiện M3 → M4 → M5
Yêu cầu Agent đọc `CONTEXT_DEV.md` và tiếp tục triển khai từ mục **3. Các Phần Đang Dang Dở Cần Làm Tiếp Ở Phiên Sau**.
