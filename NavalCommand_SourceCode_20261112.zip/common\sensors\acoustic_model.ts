/**
 * Acoustic Propagation & ASW Sonar Model
 * Clean-Room implementation for NavalCommand.io
 */

import { Vector2D, vec2Distance, knotsToMs } from '../math/vector2.js';
import { SubmarineDepthState } from '../models/types.js';
import { IslandEntity } from '../models/terrain.js';
import { checkLineOfSight } from './raycasting.js';

export const DEFAULT_CAVITATION_EXPONENT = 2.5;
export const DEFAULT_CAVITATION_K = 1.8;
export const DEFAULT_BASE_MACHINERY_DB = 60.0;
export const STEALTH_CRUISE_NOISE_REDUCTION_DB = 20.0;
export const ACTIVE_SONAR_PING_SOURCE_LEVEL_DB = 215.0;
export const ACTIVE_SONAR_DEFAULT_RANGE_METERS = 2000.0;
export const ACTIVE_SONAR_COUNTER_DETECTION_FACTOR = 2.0;
export const AMBIENT_OCEAN_NOISE_DB = 50.0;
export const PASSIVE_DETECTION_THRESHOLD_DB = 5.0;
export const DEFAULT_ABSORPTION_DB_PER_METER = 0.001; // alpha = 0.001 dB/m in seawater

export interface AcousticEmitter {
  id: string;
  position: Vector2D;
  velocity: Vector2D;
  speedKnots: number;
  depthState: SubmarineDepthState;
  cavitationThresholdSpeedMs: number;
  stealthModeActive: boolean;
  isActiveSonarPinging: boolean;
  baseNoiseDb?: number;
}

export interface PassiveDetectionResult {
  detected: boolean;
  snrDb: number;
  receivedLevelDb: number;
  bearingRad: number;
  estimatedDistance?: number;
}

export interface ActiveEcho {
  targetId: string;
  position: Vector2D;
  distance: number;
  bearingRad: number;
}

export interface CounterDetection {
  listenerId: string;
  pingerId: string;
  bearingToPingerRad: number;
  distance: number;
}

export interface ActiveSonarPingResult {
  pingerId: string;
  echoes: ActiveEcho[];
  counterDetections: CounterDetection[];
}

/**
 * Calculates continuous cavitation noise using the physical power law:
 * Noise_cav = K * (v - V_cav)^2.5 when v > V_cav, and 0 otherwise.
 *
 * @param speedMs Current forward speed in m/s
 * @param cavitationThresholdSpeedMs Speed threshold at which cavitation bubbles begin forming
 * @param coefficient Proportionality coefficient K (default 1.8)
 * @param exponent Power law exponent (default 2.5)
 */
export function calculateCavitationNoise(
  speedMs: number,
  cavitationThresholdSpeedMs: number,
  coefficient: number = DEFAULT_CAVITATION_K,
  exponent: number = DEFAULT_CAVITATION_EXPONENT
): number {
  if (speedMs <= cavitationThresholdSpeedMs) {
    return 0.0;
  }
  const deltaV = speedMs - cavitationThresholdSpeedMs;
  return coefficient * Math.pow(deltaV, exponent);
}

/**
 * Calculates total radiated acoustic source level (SL) in dB:
 * SL = SL_base + speed_noise + Noise_cav (+ active ping override, - stealth cruise suppression)
 */
export function calculateVesselSourceLevel(emitter: AcousticEmitter): number {
  if (emitter.isActiveSonarPinging) {
    // High-energy acoustic ping dominates vessel machinery signature
    return ACTIVE_SONAR_PING_SOURCE_LEVEL_DB;
  }

  const baseNoise = emitter.baseNoiseDb ?? DEFAULT_BASE_MACHINERY_DB;
  const speedNoise = Math.max(0, emitter.speedKnots) * 1.0;
  const speedMs = knotsToMs(Math.max(0, emitter.speedKnots));

  let cavitationNoise = 0.0;
  if (!emitter.stealthModeActive) {
    cavitationNoise = calculateCavitationNoise(
      speedMs,
      emitter.cavitationThresholdSpeedMs
    );
  }

  let totalSL = baseNoise + speedNoise + cavitationNoise;

  if (emitter.stealthModeActive) {
    // Stealth cruise dampens auxiliary machinery and decoupling mounts
    totalSL = Math.max(0, totalSL - STEALTH_CRUISE_NOISE_REDUCTION_DB);
  }

  return totalSL;
}

/**
 * Calculates spherical transmission loss (TL) in dB:
 * TL(r) = 20 * log10(max(r, 1)) + alpha * r
 */
export function calculateTransmissionLoss(
  distanceMeters: number,
  absorptionDbPerMeter: number = DEFAULT_ABSORPTION_DB_PER_METER
): number {
  const rClamped = Math.max(distanceMeters, 1.0);
  const geometricSpread = 20.0 * Math.log10(rClamped);
  const absorption = absorptionDbPerMeter * rClamped;
  return geometricSpread + absorption;
}

/**
 * Calculates received acoustic sound pressure level (RL) in dB:
 * RL = SL - TL(r)
 */
export function calculateReceivedLevel(
  sourceLevelDb: number,
  distanceMeters: number,
  absorptionDbPerMeter: number = DEFAULT_ABSORPTION_DB_PER_METER
): number {
  const tl = calculateTransmissionLoss(distanceMeters, absorptionDbPerMeter);
  return sourceLevelDb - tl;
}

/**
 * Evaluates passive acoustic detection by a hydrophone listening post against ocean ambient noise.
 * SNR = RL - AmbientNoise
 * Detected if SNR >= detectionThresholdDb
 */
export function evaluatePassiveAcousticDetection(
  listenerPos: Vector2D,
  emitter: AcousticEmitter,
  ambientNoiseDb: number = AMBIENT_OCEAN_NOISE_DB,
  thresholdDb: number = PASSIVE_DETECTION_THRESHOLD_DB
): PassiveDetectionResult {
  const dist = vec2Distance(listenerPos, emitter.position);
  const sl = calculateVesselSourceLevel(emitter);
  const rl = calculateReceivedLevel(sl, dist);
  const snr = rl - ambientNoiseDb;
  const detected = snr >= thresholdDb;

  const dx = emitter.position.x - listenerPos.x;
  const dy = emitter.position.y - listenerPos.y;
  const bearingRad = Math.atan2(dy, dx);

  return {
    detected,
    snrDb: snr,
    receivedLevelDb: rl,
    bearingRad,
    estimatedDistance: detected ? dist : undefined,
  };
}

/**
 * Executes active sonar ping calculation:
 * 1. Direct echoes returning to pinger: round-trip echo reaches pinger out to R_active.
 * 2. Counter-detection listeners: one-way acoustic path reaches third-party passive sensors
 *    out to 2 * R_active, providing them with the exact bearing to the pinger.
 * 3. Island occlusion blocks both direct echoes and counter-detection paths.
 */
export function evaluateActiveSonarPing(
  pinger: AcousticEmitter,
  potentialTargets: AcousticEmitter[],
  islands: IslandEntity[],
  activeRangeMeters: number = ACTIVE_SONAR_DEFAULT_RANGE_METERS
): ActiveSonarPingResult {
  const echoes: ActiveEcho[] = [];
  const counterDetections: CounterDetection[] = [];

  const counterDetectionRange = activeRangeMeters * ACTIVE_SONAR_COUNTER_DETECTION_FACTOR;

  for (const target of potentialTargets) {
    if (target.id === pinger.id) continue;

    const dist = vec2Distance(pinger.position, target.position);

    // Direct echo check (round-trip path <= activeRangeMeters)
    if (dist <= activeRangeMeters) {
      if (checkLineOfSight(pinger.position, target.position, islands)) {
        const dx = target.position.x - pinger.position.x;
        const dy = target.position.y - pinger.position.y;
        const bearingRad = Math.atan2(dy, dx);

        echoes.push({
          targetId: target.id,
          position: { ...target.position },
          distance: dist,
          bearingRad,
        });
      }
    }

    // Counter-detection check (one-way path <= 2 * activeRangeMeters)
    if (dist <= counterDetectionRange) {
      if (checkLineOfSight(target.position, pinger.position, islands)) {
        // Bearing from listener (target) to pinger
        const dx = pinger.position.x - target.position.x;
        const dy = pinger.position.y - target.position.y;
        const bearingToPingerRad = Math.atan2(dy, dx);

        counterDetections.push({
          listenerId: target.id,
          pingerId: pinger.id,
          bearingToPingerRad,
          distance: dist,
        });
      }
    }
  }

  return {
    pingerId: pinger.id,
    echoes,
    counterDetections,
  };
}
