/**
 * Dynamic Sensor Overlays & Firing Arcs
 * Clean-Room procedural vector implementation using PixiJS v8.
 * Radar sweeps, sonar ping pulses, range rings, and weapon firing arc wedges.
 */

import { Container, Graphics } from 'pixi.js';

export interface FiringArcState {
  baseAngle: number;       // Radians relative to ship heading
  arcCoverage: number;     // Total arc sweep radians
  currentAngle: number;    // Current relative turret angle
  isLoaded: boolean;
  isOnBearing: boolean;
  isObstructed?: boolean;
}

export class SensorOverlays {
  public readonly container: Container;
  private readonly sweepGraphics: Graphics;
  private readonly rangeRingsGraphics: Graphics;
  private readonly firingArcsGraphics: Graphics;

  private radarAngle: number = 0;
  private sonarPulseRadius: number = 0;
  private sonarMaxRadius: number = 600;
  private isSonarActive: boolean = false;

  constructor() {
    this.container = new Container();
    this.sweepGraphics = new Graphics();
    this.rangeRingsGraphics = new Graphics();
    this.firingArcsGraphics = new Graphics();

    this.container.addChild(this.rangeRingsGraphics);
    this.container.addChild(this.firingArcsGraphics);
    this.container.addChild(this.sweepGraphics);
  }

  /**
   * Draw visual, radar, and sonar range rings centered at player vessel.
   */
  public drawRangeRings(
    x: number,
    y: number,
    visualRange: number = 350,
    radarRange: number = 700,
    sonarRange: number = 500
  ): void {
    const g = this.rangeRingsGraphics;
    g.clear();

    // 1. Visual Range Ring (Subtle White)
    g.circle(x, y, visualRange);
    g.stroke({
      color: 0xffffff,
      width: 1,
      alpha: 0.25,
    });

    // 2. Radar Range Ring (Emerald Green)
    g.circle(x, y, radarRange);
    g.stroke({
      color: 0x00e676,
      width: 1.5,
      alpha: 0.35,
    });

    // 3. Sonar Range Ring (Cyan)
    g.circle(x, y, sonarRange);
    g.stroke({
      color: 0x00e5ff,
      width: 1.5,
      alpha: 0.3,
    });
  }

  /**
   * Draw weapon firing arc wedges showing mount coverage and ready status.
   */
  public drawFiringArcs(
    shipX: number,
    shipY: number,
    shipHeading: number,
    arcs: FiringArcState[],
    arcRadius: number = 180
  ): void {
    const g = this.firingArcsGraphics;
    g.clear();

    for (const arc of arcs) {
      const worldCenterAngle = shipHeading + arc.baseAngle;
      const startAngle = worldCenterAngle - arc.arcCoverage * 0.5;
      const endAngle = worldCenterAngle + arc.arcCoverage * 0.5;

      // Arc status color
      let arcColor = 0x00e676; // Green: Ready & on-bearing
      let arcAlpha = 0.15;

      if (arc.isObstructed) {
        arcColor = 0xff1744; // Red: Obstructed
        arcAlpha = 0.22;
      } else if (!arc.isLoaded || !arc.isOnBearing) {
        arcColor = 0xffab00; // Amber: Reloading or traversing
        arcAlpha = 0.18;
      }

      // Draw sector wedge
      g.moveTo(shipX, shipY);
      g.arc(shipX, shipY, arcRadius, startAngle, endAngle);
      g.closePath();
      g.fill({ color: arcColor, alpha: arcAlpha });
      g.stroke({ color: arcColor, width: 1.2, alpha: arcAlpha * 2.5 });

      // Gun current bore-sight line
      const currentWorldAngle = shipHeading + arc.currentAngle;
      const barrelTargetX = shipX + Math.cos(currentWorldAngle) * (arcRadius * 0.95);
      const barrelTargetY = shipY + Math.sin(currentWorldAngle) * (arcRadius * 0.95);

      g.moveTo(shipX, shipY);
      g.lineTo(barrelTargetX, barrelTargetY);
      g.stroke({ color: arcColor, width: 1.5, alpha: 0.7 });
    }
  }

  /**
   * Trigger active sonar acoustic ping animation.
   */
  public triggerSonarPing(maxRadius: number = 600): void {
    this.isSonarActive = true;
    this.sonarPulseRadius = 10;
    this.sonarMaxRadius = maxRadius;
  }

  /**
   * Step radar sweep angle and sonar acoustic pulse expansion.
   */
  public update(dt: number, shipX: number, shipY: number, radarRange: number = 700): void {
    const g = this.sweepGraphics;
    g.clear();

    // 1. Radar sweep rotation (30 RPM = 0.5 rev/sec = PI rad/s)
    this.radarAngle = (this.radarAngle + Math.PI * dt) % (2 * Math.PI);

    // Phosphorescent trailing wedge (15 degrees / ~0.26 rad)
    const trailAngle = 0.26;
    g.moveTo(shipX, shipY);
    g.arc(shipX, shipY, radarRange, this.radarAngle - trailAngle, this.radarAngle);
    g.closePath();
    g.fill({ color: 0x00e676, alpha: 0.12 });

    // Sharp sweep line
    const sweepEndX = shipX + Math.cos(this.radarAngle) * radarRange;
    const sweepEndY = shipY + Math.sin(this.radarAngle) * radarRange;
    g.moveTo(shipX, shipY);
    g.lineTo(sweepEndX, sweepEndY);
    g.stroke({ color: 0x69f0ae, width: 2, alpha: 0.75 });

    // 2. Active Sonar acoustic pulse
    if (this.isSonarActive) {
      this.sonarPulseRadius += dt * 320; // 320 m/s visual pulse speed
      if (this.sonarPulseRadius >= this.sonarMaxRadius) {
        this.isSonarActive = false;
        this.sonarPulseRadius = 0;
      } else {
        const pulseAlpha = Math.max(0, 1.0 - this.sonarPulseRadius / this.sonarMaxRadius) * 0.7;
        g.circle(shipX, shipY, this.sonarPulseRadius);
        g.stroke({
          color: 0x00e5ff,
          width: 2.5,
          alpha: pulseAlpha,
        });
      }
    }
  }

  public clear(): void {
    this.sweepGraphics.clear();
    this.rangeRingsGraphics.clear();
    this.firingArcsGraphics.clear();
  }
}
