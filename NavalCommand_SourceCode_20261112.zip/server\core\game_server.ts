/**
 * Authoritative Simulation Game Server
 * Clean-Room implementation for NavalCommand.io
 */

import { Vector2D, vec2, vec2Distance, vec2Normalize, vec2Scale, vec2Add, degToRad, normalizeAngle } from '../../common/math/vector2.js';
import { ShipDef, SHIP_ROSTER, getAllShipDefs } from '../../common/models/ships.js';
import { PhysicsState, SubmarineDepthState } from '../../common/models/types.js';
import {
  WeaponMountDef,
  WeaponCategory,
  canMountFire,
  fireMount,
  stepMountReloadAndRegen,
  stepMountTraverse,
  isAngleWithinMountArc,
  SubmarineContact,
  SurfaceVesselContact,
  AcousticContact,
  ThreatTarget,
} from '../../common/models/weapons.js';
import { createInitialPhysicsState, updateHydrodynamics, commandDepthState, toggleStealthMode } from '../../common/simulation/hydrodynamics.js';
import { ResourceEngine, PlayerVesselRef } from '../../common/simulation/resource_engine.js';
import { IslandEntity, DEFAULT_ISLAND_PRESETS, createOilRig } from '../../common/models/terrain.js';
import { TerrainEngine } from '../../common/simulation/terrain_engine.js';
import {
  WeaponKinematicsEngine,
  WeaponKinematicsWorldContext,
  stepCIWSEnvelope,
  launchSAMInterceptor,
  calculateDepthChargeDamage,
  executeDredgerAction,
} from '../../common/simulation/weapon_kinematics.js';
import { SpatialGrid, SpatialEntity } from './spatial_grid.js';
import { GameLoop } from './game_loop.js';
import {
  Opcode,
  VesselStatusFlag,
  InputControlFlag,
  GameEventType,
  VesselSnapshotRecord,
  SnapshotPacket,
  InputPacket,
  EventPacket,
} from '../../common/protocol/packet_types.js';

export interface ServerVessel {
  id: number;
  name: string;
  shipDef: ShipDef;
  physics: PhysicsState;
  mounts: WeaponMountDef[];
  isBot: boolean;
  teamId: number;
  fleetId: number;
  karma: number; // -100 to 100 (100 = honorable, 0 = neutral, -100 = traitor)
  camoId: number;
  score: number;
  kills: number;
  deaths: number;
  accumulatedXp: number;
  ecmActive: boolean;
  ecmTimer: number;
  ecmCooldown: number;
  napTimers: Map<number, number>; // otherVesselId -> remaining NAP seconds
  napExpiredTimers: Map<number, number>; // otherVesselId -> seconds elapsed since NAP expired (for karma tracking)
  lastInputSequence: number;
  floodingTimer?: number;
  floodingPenalty?: number;
}

export interface ServerProjectile {
  id: number;
  ownerId: number;
  position: Vector2D;
  velocity: Vector2D;
  category: WeaponCategory;
  damage: number;
  maxRange: number;
  traveledDistance: number;
  targetId?: number;
  isHoming?: boolean;
  radius: number;
}

export interface SpawnVesselOptions {
  id?: number;
  name?: string;
  shipId?: string;
  position?: Vector2D;
  heading?: number;
  isBot?: boolean;
  teamId?: number;
  fleetId?: number;
  camoId?: number;
}

let nextEntityId = 100;
let nextProjectileId = 10000;

class AuthoritativeGameServer {
  public gameLoop: GameLoop;
  public spatialGrid: SpatialGrid;
  public resourceEngine: ResourceEngine;
  public weaponEngine: WeaponKinematicsEngine;
  public terrainEngine: TerrainEngine;
  private vessels: Map<number, ServerVessel> = new Map();
  private projectiles: Map<number, ServerProjectile> = new Map();
  private islands: IslandEntity[] = [...DEFAULT_ISLAND_PRESETS];
  private queuedEvents: EventPacket[] = [];

  constructor(tickRate = 20) {
    this.gameLoop = new GameLoop(tickRate);
    this.spatialGrid = new SpatialGrid(250);
    this.resourceEngine = new ResourceEngine();
    this.terrainEngine = new TerrainEngine(this.islands);
    this.weaponEngine = new WeaponKinematicsEngine();

    // Hook game loop
    this.gameLoop.onTick((tick, dt) => this.step(dt));

    // Initialize 2 default oil rigs for contesting
    const rig1 = createOilRig('rig_alpha', 'Alpha Extraction Platform', vec2(1500, 1500));
    const rig2 = createOilRig('rig_bravo', 'Bravo Deepwater Derrick', vec2(-1500, -1500));
    this.resourceEngine.addOilRig(rig1);
    this.resourceEngine.addOilRig(rig2);
  }

  public getVessel(id: number): ServerVessel | undefined {
    return this.vessels.get(id);
  }

  public getAllVessels(): ServerVessel[] {
    return Array.from(this.vessels.values());
  }

  public getAllProjectiles(): ServerProjectile[] {
    const list: ServerProjectile[] = [];

    // Map shells from weaponEngine
    for (const shell of this.weaponEngine.shells) {
      const dist = vec2Distance(shell.origin, shell.currentPos);
      const maxDist = vec2Distance(shell.origin, shell.targetPos);
      list.push({
        id: parseInt(shell.id.replace(/\D/g, '')) || 1000,
        ownerId: parseInt(shell.shooterId) || 0,
        position: { ...shell.currentPos },
        velocity: {
          x: shell.flightTimeTotal > 0 ? (shell.targetPos.x - shell.origin.x) / shell.flightTimeTotal : 0,
          y: shell.flightTimeTotal > 0 ? (shell.targetPos.y - shell.origin.y) / shell.flightTimeTotal : 0,
        },
        category: 'ARTILLERY',
        damage: shell.damage,
        maxRange: maxDist,
        traveledDistance: dist,
        radius: shell.blastRadius,
      });
    }

    // Map torpedoes from weaponEngine
    for (const torp of this.weaponEngine.torpedoes) {
      list.push({
        id: parseInt(torp.id.replace(/\D/g, '')) || 2000,
        ownerId: parseInt(torp.shooterId) || 0,
        position: { ...torp.position },
        velocity: { ...torp.velocity },
        category: 'TORPEDO',
        damage: torp.damage,
        maxRange: torp.maxRange,
        traveledDistance: torp.distanceTraveled,
        isHoming: torp.isAcousticHoming,
        radius: 4,
      });
    }

    // Map cruise missiles from weaponEngine
    for (const cm of this.weaponEngine.cruiseMissiles) {
      list.push({
        id: parseInt(cm.id.replace(/\D/g, '')) || 3000,
        ownerId: parseInt(cm.shooterId) || 0,
        position: { ...cm.position },
        velocity: { ...cm.velocity },
        category: 'CRUISE_MISSILE',
        damage: cm.damage,
        maxRange: cm.maxRange,
        traveledDistance: cm.distanceTraveled,
        isHoming: cm.guidanceActive && !cm.guidanceAborted,
        radius: 3,
      });
    }

    // Map rockets from weaponEngine
    for (const rocket of this.weaponEngine.rockets) {
      const dPos = vec2(rocket.targetPos.x - rocket.origin.x, rocket.targetPos.y - rocket.origin.y);
      const dir = vec2Normalize(dPos);
      list.push({
        id: parseInt(rocket.id.replace(/\D/g, '')) || 4000,
        ownerId: parseInt(rocket.shooterId) || 0,
        position: { ...rocket.currentPos },
        velocity: vec2Scale(dir, rocket.speed),
        category: 'ROCKET_BARRAGE',
        damage: rocket.damage,
        maxRange: vec2Distance(rocket.origin, rocket.targetPos),
        traveledDistance: vec2Distance(rocket.origin, rocket.currentPos),
        radius: rocket.blastRadius,
      });
    }

    // Map rocket torpedoes from weaponEngine
    for (const asroc of this.weaponEngine.rocketTorpedoes) {
      list.push({
        id: parseInt(asroc.id.replace(/\D/g, '')) || 5000,
        ownerId: parseInt(asroc.shooterId) || 0,
        position: { ...asroc.position },
        velocity: { ...asroc.velocity },
        category: 'ROCKET_TORPEDO',
        damage: asroc.damage,
        maxRange: 5000,
        traveledDistance: asroc.timeElapsed * (asroc.flightPhase === 'AIR_BALLISTIC' ? asroc.airSpeed : asroc.waterSpeed),
        isHoming: asroc.flightPhase === 'UNDERWATER_HOMING',
        radius: 4,
      });
    }

    // Map SAM interceptors from weaponEngine
    for (const sam of this.weaponEngine.samInterceptors) {
      list.push({
        id: parseInt(sam.id.replace(/\D/g, '')) || 6000,
        ownerId: parseInt(sam.shooterId) || 0,
        position: { ...sam.position },
        velocity: { ...sam.velocity },
        category: 'SAM_CIWS',
        damage: sam.damage,
        maxRange: sam.speed * sam.maxFlightTime,
        traveledDistance: sam.speed * sam.timeElapsed,
        isHoming: true,
        radius: sam.proximityRadius,
      });
    }

    // Map depth charges from weaponEngine
    for (const dc of this.weaponEngine.depthCharges) {
      list.push({
        id: parseInt(dc.id.replace(/\D/g, '')) || 7000,
        ownerId: parseInt(dc.dropperId) || 0,
        position: { ...dc.position },
        velocity: { x: 0, y: 0 },
        category: 'DEPTH_CHARGE',
        damage: dc.baseDamage,
        maxRange: 100,
        traveledDistance: Math.abs(dc.currentDepth),
        radius: dc.blastRadius,
      });
    }

    // Map naval mines from weaponEngine
    for (const mine of this.weaponEngine.mines) {
      list.push({
        id: parseInt(mine.id.replace(/\D/g, '')) || 8000,
        ownerId: parseInt(mine.deployerId) || 0,
        position: { ...mine.position },
        velocity: { x: 0, y: 0 },
        category: 'NAVAL_MINE',
        damage: mine.damage,
        maxRange: 0,
        traveledDistance: 0,
        radius: mine.contactRadius,
      });
    }

    // Combine with legacy projectiles map if any
    for (const proj of this.projectiles.values()) {
      list.push(proj);
    }

    return list;
  }

  public getIslands(): IslandEntity[] {
    return this.islands;
  }

  public start(): void {
    this.gameLoop.start();
  }

  public stop(): void {
    this.gameLoop.stop();
  }

  public spawnVessel(options: SpawnVesselOptions = {}): ServerVessel {
    const id = options.id ?? ++nextEntityId;
    const name = options.name ?? `Commander_${id}`;
    const shipDef = options.shipId && SHIP_ROSTER[options.shipId]
      ? SHIP_ROSTER[options.shipId]
      : SHIP_ROSTER['pt_boat_109'];

    const spawnPos = options.position ?? vec2((Math.random() - 0.5) * 400, (Math.random() - 0.5) * 400);
    const heading = options.heading ?? Math.random() * Math.PI * 2;
    const physics = createInitialPhysicsState(shipDef, spawnPos, heading);

    // Deep clone mounts for this vessel instance
    const mounts: WeaponMountDef[] = shipDef.mounts.map(m => ({ ...m }));

    const vessel: ServerVessel = {
      id,
      name,
      shipDef,
      physics,
      mounts,
      isBot: options.isBot ?? false,
      teamId: options.teamId ?? 0,
      fleetId: options.fleetId ?? 0,
      karma: 100,
      camoId: options.camoId ?? 0,
      score: 0,
      kills: 0,
      deaths: 0,
      accumulatedXp: 0,
      ecmActive: false,
      ecmTimer: 0,
      ecmCooldown: 0,
      napTimers: new Map(),
      napExpiredTimers: new Map(),
      lastInputSequence: 0,
      floodingTimer: 0,
      floodingPenalty: 0,
    };

    this.vessels.set(id, vessel);
    this.spatialGrid.insert({
      id,
      type: 'VESSEL',
      x: physics.position.x,
      y: physics.position.y,
      radius: Math.max(shipDef.length, shipDef.beam) / 2,
      data: vessel,
    });

    return vessel;
  }

  public despawnVessel(id: number): boolean {
    const vessel = this.vessels.get(id);
    if (!vessel) return false;

    this.spatialGrid.remove(id);
    this.vessels.delete(id);
    return true;
  }

  /**
   * Enforces 15-second Non-Aggression Pact between two players (e.g. on leaving or being kicked from fleet).
   */
  public setFleetNAP(vesselIdA: number, vesselIdB: number, durationSeconds = 15.0): void {
    const vA = this.vessels.get(vesselIdA);
    const vB = this.vessels.get(vesselIdB);

    if (vA) {
      vA.napTimers.set(vesselIdB, durationSeconds);
      vA.napExpiredTimers.delete(vesselIdB);
    }
    if (vB) {
      vB.napTimers.set(vesselIdA, durationSeconds);
      vB.napExpiredTimers.delete(vesselIdA);
    }
  }

  /**
   * Evaluates if damage can be dealt from attacker to victim.
   * Enforces 15-second Non-Aggression Pact and friendly fleet rules.
   */
  public canDamage(attackerId: number, victimId: number): boolean {
    if (attackerId === victimId) return false;

    const attacker = this.vessels.get(attackerId);
    const victim = this.vessels.get(victimId);
    if (!attacker || !victim) return false;
    if (victim.physics.isDestroyed || attacker.physics.isDestroyed) return false;

    // Active Non-Aggression Pact blocks 100% of mutual damage
    const napRemaining = attacker.napTimers.get(victimId) ?? 0;
    if (napRemaining > 0) {
      return false;
    }

    // Same fleet check (if fleet > 0)
    if (attacker.fleetId > 0 && attacker.fleetId === victim.fleetId) {
      return false;
    }

    return true;
  }

  /**
   * Applies damage to a victim vessel and tracks Karma & Kills.
   */
  public applyDamage(attackerId: number, victimId: number, rawDamage: number): number {
    if (!this.canDamage(attackerId, victimId)) return 0;

    const attacker = this.vessels.get(attackerId);
    const victim = this.vessels.get(victimId);
    if (!attacker || !victim) return 0;

    // If victim was a recent former fleetmate (within 30 seconds after NAP expiration),
    // penalize attacker Karma score!
    const timeSinceNapExpired = attacker.napExpiredTimers.get(victimId);
    if (timeSinceNapExpired !== undefined && timeSinceNapExpired < 30.0) {
      attacker.karma = Math.max(-100, attacker.karma - 25);
      this.queuedEvents.push({
        opcode: Opcode.OP_EVENT,
        eventType: GameEventType.KARMA_PENALTY,
        sourceId: attacker.id,
        targetId: victim.id,
        data: Math.abs(attacker.karma),
      });
    }

    // Armor damage mitigation
    const armorMitigation = 100 / (100 + victim.shipDef.armor);
    const netDamage = Math.max(1, Math.round(rawDamage * armorMitigation));

    victim.physics.hullHp = Math.max(0, victim.physics.hullHp - netDamage);
    attacker.score += Math.round(netDamage * 0.1);

    this.queuedEvents.push({
      opcode: Opcode.OP_EVENT,
      eventType: GameEventType.HIT,
      sourceId: attacker.id,
      targetId: victim.id,
      data: netDamage,
    });

    if (victim.physics.hullHp <= 0) {
      this.destroyVessel(victim, attacker);
    }

    return netDamage;
  }

  private destroyVessel(victim: ServerVessel, killer?: ServerVessel): void {
    victim.physics.isDestroyed = true;
    victim.deaths++;

    if (killer) {
      killer.kills++;
      killer.score += 500;
      killer.accumulatedXp += 250;
    }

    // Spawn wreckage crates
    this.resourceEngine.spawnWreckageCrates(victim.physics.position, victim.accumulatedXp);

    this.queuedEvents.push({
      opcode: Opcode.OP_EVENT,
      eventType: GameEventType.SINK,
      sourceId: killer ? killer.id : 0,
      targetId: victim.id,
      data: killer ? killer.score : 0,
    });
  }

  /**
   * Processes player / client input.
   */
  public processInput(vesselId: number, input: InputPacket): void {
    const vessel = this.vessels.get(vesselId);
    if (!vessel || vessel.physics.isDestroyed) return;

    vessel.lastInputSequence = input.sequence;

    // Convert thrust and rudder from i8 [-100..100] to float [-0.5..1.0] and [-1.0..1.0]
    const throttle = input.thrust >= 0 ? input.thrust / 100.0 : (input.thrust / 100.0) * 0.5;
    const rudder = input.rudder / 100.0;

    vessel.physics.throttle = throttle;
    vessel.physics.rudderAngle = rudder;

    // Submarine depth toggle
    if (input.depthTarget !== undefined) {
      const depthState: SubmarineDepthState =
        input.depthTarget === 2 ? 'DEEP' : input.depthTarget === 1 ? 'PERISCOPE' : 'SURFACE';
      commandDepthState(vessel.shipDef, vessel.physics, depthState);
    }

    // Stealth toggle
    if (input.weaponFireMask & InputControlFlag.STEALTH_TOGGLE) {
      toggleStealthMode(vessel.shipDef, vessel.physics);
    }

    // ECM toggle
    if (input.weaponFireMask & InputControlFlag.ECM_TOGGLE) {
      this.activateECM(vessel);
    }

    // Fire weapon triggers
    const targetCoords = vec2(input.targetX, input.targetY);
    if (input.weaponFireMask & InputControlFlag.FIRE_PRIMARY) {
      this.fireMount(vessel.id, 0, targetCoords);
    }
    if (input.weaponFireMask & InputControlFlag.FIRE_SECONDARY) {
      this.fireMount(vessel.id, 1, targetCoords);
    }
    if (input.weaponFireMask & InputControlFlag.FIRE_TORPEDO) {
      // Find first torpedo mount
      const torpIdx = vessel.mounts.findIndex(m => m.category === 'TORPEDO' || m.category === 'ROCKET_TORPEDO');
      if (torpIdx >= 0) this.fireMount(vessel.id, torpIdx, targetCoords);
    }
    if (input.weaponFireMask & InputControlFlag.FIRE_MISSILE) {
      // Find first missile mount
      const misIdx = vessel.mounts.findIndex(m => m.category === 'CRUISE_MISSILE' || m.category === 'SAM_CIWS');
      if (misIdx >= 0) this.fireMount(vessel.id, misIdx, targetCoords);
    }
  }

  public activateECM(vessel: ServerVessel): boolean {
    if (!vessel.shipDef.traits.includes('ECM_JAMMING') && !vessel.shipDef.specialAbilities.includes('ECM_JAMMING')) {
      return false;
    }
    if (vessel.ecmCooldown > 0 || vessel.ecmActive) {
      return false;
    }

    vessel.ecmActive = true;
    vessel.ecmTimer = 5.0; // 5 seconds active
    vessel.ecmCooldown = 25.0; // 25 seconds cooldown

    this.queuedEvents.push({
      opcode: Opcode.OP_EVENT,
      eventType: GameEventType.ECM_PULSE,
      sourceId: vessel.id,
      targetId: 0,
      data: 5,
    });
    return true;
  }

  public fireMount(vesselId: number, mountIndex: number, targetCoords: Vector2D): boolean {
    const vessel = this.vessels.get(vesselId);
    if (!vessel || vessel.physics.isDestroyed) return false;

    const mount = vessel.mounts[mountIndex];
    if (!mount) return false;

    // Submarine depth restrictions:
    // Cruise missiles and aircraft cannot be launched from DEEP depth (< -5.0m or depthState === 'DEEP')
    const isDeep = vessel.physics.depthState === 'DEEP' || (vessel.physics.currentDepth !== undefined && vessel.physics.currentDepth < -5.0);
    if (isDeep && (mount.category === 'CRUISE_MISSILE' || mount.category === 'AIRCRAFT_SQUADRON')) {
      return false;
    }

    // Calculate mount world coordinates
    const cosH = Math.cos(vessel.physics.heading);
    const sinH = Math.sin(vessel.physics.heading);
    const mountWorldPos: Vector2D = {
      x: vessel.physics.position.x + mount.localOffset.x * cosH - mount.localOffset.y * sinH,
      y: vessel.physics.position.y + mount.localOffset.x * sinH + mount.localOffset.y * cosH,
    };

    // Calculate relative aiming angle to target
    const dx = targetCoords.x - mountWorldPos.x;
    const dy = targetCoords.y - mountWorldPos.y;
    const targetBearing = Math.atan2(dy, dx);
    const targetRelAngle = normalizeAngle(targetBearing - vessel.physics.heading);

    // Enforce mount traverse arc limits for directional mount types
    if (
      mount.category !== 'DEPTH_CHARGE' &&
      mount.category !== 'NAVAL_MINE' &&
      mount.category !== 'DREDGER_TOOL'
    ) {
      if (mount.arcCoverage < 2 * Math.PI - 1e-4) {
        if (!isAngleWithinMountArc(mount, targetRelAngle)) {
          return false;
        }
      }
    }

    // Check if mount has ammo and reload timer is 0
    if (!canMountFire(mount)) return false;

    // Route to WeaponKinematicsEngine based on mount category across all 10 categories
    const shooterIdStr = String(vessel.id);

    switch (mount.category) {
      case 'ARTILLERY': {
        const shell = this.weaponEngine.fireArtilleryMount(
          shooterIdStr,
          mount,
          mountWorldPos,
          targetCoords
        );
        return shell !== null;
      }

      case 'TORPEDO': {
        const isAcoustic = mount.weaponDefId.includes('acoustic');
        const torp = this.weaponEngine.fireTorpedoMount(
          shooterIdStr,
          mount,
          mountWorldPos,
          targetBearing,
          isAcoustic
        );
        return torp !== null;
      }

      case 'CRUISE_MISSILE': {
        const heading = vessel.physics.heading + mount.currentAngle;
        const isSub = vessel.shipDef.canSubmerge ?? false;
        const shooterDepth = vessel.physics.currentDepth ?? 0;
        const missile = this.weaponEngine.fireCruiseMissileMount(
          shooterIdStr,
          mount,
          mountWorldPos,
          heading,
          targetCoords,
          isSub,
          shooterDepth
        );
        return missile !== null;
      }

      case 'ROCKET_BARRAGE': {
        const rockets = this.weaponEngine.fireRocketBarrageMount(
          shooterIdStr,
          mount,
          mountWorldPos,
          targetCoords,
          12
        );
        return rockets.length > 0;
      }

      case 'ROCKET_TORPEDO': {
        const asroc = this.weaponEngine.fireRocketTorpedoMount(
          shooterIdStr,
          mount,
          mountWorldPos,
          targetCoords
        );
        return asroc !== null;
      }

      case 'DEPTH_CHARGE': {
        const fuseSetting: 'SURFACE' | 'PERISCOPE' | 'DEEP' =
          vessel.physics.depthState === 'DEEP' ? 'DEEP' : 'PERISCOPE';
        const dc = this.weaponEngine.dropDepthCharge(
          shooterIdStr,
          mount,
          mountWorldPos,
          fuseSetting
        );
        return dc !== null;
      }

      case 'NAVAL_MINE': {
        const mine = this.weaponEngine.layNavalMine(
          shooterIdStr,
          mount,
          mountWorldPos
        );
        return mine !== null;
      }

      case 'AIRCRAFT_SQUADRON': {
        const isASW = mount.weaponDefId.includes('helicopter') || mount.weaponDefId.includes('asw');
        const airType = isASW ? 'ASW_HELICOPTER' : 'STRIKE_FIGHTER';
        const aircraft = this.weaponEngine.launchAircraft(
          shooterIdStr,
          mount,
          mountWorldPos,
          airType,
          targetCoords
        );
        return aircraft !== null;
      }

      case 'DREDGER_TOOL': {
        if (!fireMount(mount)) return false;
        executeDredgerAction(
          shooterIdStr,
          mountWorldPos,
          targetCoords,
          'EXCAVATE',
          this.terrainEngine
        );
        return true;
      }

      case 'SAM_CIWS': {
        if (!fireMount(mount)) return false;
        const sam = launchSAMInterceptor(
          this.weaponEngine.generateId('sam'),
          shooterIdStr,
          mount.slotId,
          mountWorldPos,
          'target_threat',
          targetCoords
        );
        this.weaponEngine.samInterceptors.push(sam);
        return true;
      }

      default:
        return false;
    }
  }

  /**
   * Step the authoritative simulation for one timestep dt.
   */
  public step(dt: number): void {
    // 1. Step vessels: hydrodynamics, weapon reload, NAP timers, ECM, flooding
    for (const vessel of this.vessels.values()) {
      if (!vessel.physics.isDestroyed) {
        // Step flooding speed penalty countdown
        if (vessel.floodingTimer && vessel.floodingTimer > 0) {
          vessel.floodingTimer = Math.max(0, vessel.floodingTimer - dt);
          const penalty = vessel.floodingPenalty ?? 0.60;
          const factor = Math.max(0.1, 1.0 - penalty);
          vessel.physics.throttle *= factor;
          vessel.physics.speedKnots *= factor;
          vessel.physics.linearVelocity.x *= factor;
          vessel.physics.linearVelocity.y *= factor;
        }

        updateHydrodynamics(
          vessel.shipDef,
          vessel.physics,
          vessel.physics.throttle,
          vessel.physics.rudderAngle,
          dt
        );

        // Step mounts
        for (const mount of vessel.mounts) {
          stepMountReloadAndRegen(mount, dt);
        }

        // Mercy hospital healing passive ability
        if (vessel.shipDef.traits.includes('HOSPITAL_SHIP_HEAL') && !vessel.physics.isDestroyed) {
          const allies = this.spatialGrid.queryRadius(vessel.physics.position.x, vessel.physics.position.y, 120);
          for (const ent of allies) {
            if (ent.type === 'VESSEL' && ent.id !== vessel.id) {
              const allyVessel = this.vessels.get(ent.id as number);
              if (allyVessel && !allyVessel.physics.isDestroyed && allyVessel.fleetId === vessel.fleetId && allyVessel.physics.hullHp < allyVessel.shipDef.maxHp) {
                allyVessel.physics.hullHp = Math.min(allyVessel.shipDef.maxHp, allyVessel.physics.hullHp + 25 * dt);
              }
            }
          }
        }
      }

      // Step ECM timers
      if (vessel.ecmActive) {
        vessel.ecmTimer -= dt;
        if (vessel.ecmTimer <= 0) {
          vessel.ecmActive = false;
        }
      }
      if (vessel.ecmCooldown > 0) {
        vessel.ecmCooldown = Math.max(0, vessel.ecmCooldown - dt);
      }

      // Step NAP countdown
      for (const [targetId, remaining] of vessel.napTimers.entries()) {
        const nextTime = remaining - dt;
        if (nextTime <= 0) {
          vessel.napTimers.delete(targetId);
          vessel.napExpiredTimers.set(targetId, 0); // Start tracking time since expiration
        } else {
          vessel.napTimers.set(targetId, nextTime);
        }
      }

      // Step NAP expired elapsed timers (for karma tracking window)
      for (const [targetId, elapsed] of vessel.napExpiredTimers.entries()) {
        vessel.napExpiredTimers.set(targetId, elapsed + dt);
      }

      // Update position in spatial grid
      this.spatialGrid.update({
        id: vessel.id,
        type: 'VESSEL',
        x: vessel.physics.position.x,
        y: vessel.physics.position.y,
        radius: Math.max(vessel.shipDef.length, vessel.shipDef.beam) / 2,
        data: vessel,
      });
    }

    // 2. Build aerial threats & step automated CIWS Point-Defense Envelopes
    const threats: ThreatTarget[] = [];
    for (const cm of this.weaponEngine.cruiseMissiles) {
      if (!cm.isDetonated && !cm.isIntercepted) {
        threats.push({
          id: cm.id,
          position: cm.position,
          velocity: cm.velocity,
          altitudeMeters: 20,
          hp: 50,
          isDestroyed: false,
          type: 'CRUISE_MISSILE',
        });
      }
    }
    for (const air of this.weaponEngine.aircraft) {
      threats.push({
        id: air.id,
        position: air.position,
        velocity: air.velocity,
        altitudeMeters: 100,
        hp: air.type === 'STRIKE_FIGHTER' ? 120 : 80,
        isDestroyed: false,
        type: 'AIRCRAFT',
      });
    }

    // Step automated CIWS on any vessel with CIWS mounts
    for (const vessel of this.vessels.values()) {
      if (vessel.physics.isDestroyed) continue;
      for (const mount of vessel.mounts) {
        if (mount.category === 'SAM_CIWS' && mount.weaponDefId.includes('ciws')) {
          const cosH = Math.cos(vessel.physics.heading);
          const sinH = Math.sin(vessel.physics.heading);
          const mountWorldPos: Vector2D = {
            x: vessel.physics.position.x + mount.localOffset.x * cosH - mount.localOffset.y * sinH,
            y: vessel.physics.position.y + mount.localOffset.x * sinH + mount.localOffset.y * cosH,
          };
          const res = stepCIWSEnvelope(mount, mountWorldPos, vessel.physics.heading, threats, dt);
          if (res.interceptedThreatId) {
            // Find and neutralize cruise missile
            const cm = this.weaponEngine.cruiseMissiles.find(m => m.id === res.interceptedThreatId);
            if (cm) {
              cm.isIntercepted = true;
              cm.isDetonated = true;
            }
            this.queuedEvents.push({
              opcode: Opcode.OP_EVENT,
              eventType: GameEventType.HIT,
              sourceId: vessel.id,
              targetId: 0,
              data: 1,
            });
          }
        }
      }
    }

    // 3. Build WeaponKinematicsWorldContext
    const submarines: SubmarineContact[] = [];
    const surfaceVessels: SurfaceVesselContact[] = [];
    const acousticContacts: AcousticContact[] = [];

    for (const vessel of this.vessels.values()) {
      if (vessel.physics.isDestroyed) continue;

      let depthMeters = 0;
      if (vessel.physics.depthState === 'DEEP') depthMeters = -30.0;
      else if (vessel.physics.depthState === 'PERISCOPE') depthMeters = -5.0;
      else depthMeters = vessel.physics.currentDepth ?? 0;

      if (vessel.shipDef.canSubmerge) {
        submarines.push({
          id: String(vessel.id),
          position: vessel.physics.position,
          velocity: vessel.physics.linearVelocity,
          depthMeters,
          hullHp: vessel.physics.hullHp,
          isSilent: vessel.physics.stealthModeActive ?? false,
        });
      }

      if (!vessel.shipDef.canSubmerge || vessel.physics.depthState !== 'DEEP') {
        surfaceVessels.push({
          id: String(vessel.id),
          position: vessel.physics.position,
          speedKnots: vessel.physics.speedKnots,
          hullHp: vessel.physics.hullHp,
          draftMeters: vessel.shipDef.draft,
        });
      }

      let signatureDb = 90.0 + vessel.physics.speedKnots * 1.5;
      if (vessel.physics.isCavitationNoise) signatureDb += 30.0;
      if (vessel.physics.stealthModeActive) signatureDb -= 20.0;

      acousticContacts.push({
        id: String(vessel.id),
        position: vessel.physics.position,
        velocity: vessel.physics.linearVelocity,
        isCavitating: vessel.physics.isCavitationNoise,
        isActiveSonarPinging: false,
        acousticSignatureDb: signatureDb,
      });
    }

    const context: WeaponKinematicsWorldContext = {
      submarines,
      surfaceVessels,
      acousticContacts,
      threats,
      terrainEngine: this.terrainEngine,
    };

    // 4. Resolve Hits & Detonations for active projectiles before kinematics step filters them

    // 4a. Artillery Shells arriving at target
    for (const shell of this.weaponEngine.shells) {
      if (!shell.isDetonated && shell.timeElapsed + dt >= shell.flightTimeTotal) {
        const nearby = this.spatialGrid.queryRadius(shell.targetPos.x, shell.targetPos.y, shell.blastRadius + 40);
        for (const ent of nearby) {
          if (ent.type !== 'VESSEL' || String(ent.id) === shell.shooterId) continue;
          const target = this.vessels.get(ent.id as number);
          if (!target || target.physics.isDestroyed) continue;
          // Submarine DEEP depth immunity against surface artillery
          if (target.physics.depthState === 'DEEP' || (target.physics.currentDepth !== undefined && target.physics.currentDepth < -5.0)) {
            continue;
          }
          const dist = vec2Distance(shell.targetPos, target.physics.position);
          const hitRadius = (target.shipDef.beam + target.shipDef.length) / 4 + shell.blastRadius;
          if (dist <= hitRadius) {
            this.applyDamage(Number(shell.shooterId), target.id, shell.damage);
          }
        }
      }
    }

    // 4b. Torpedoes impacting vessels
    for (const torp of this.weaponEngine.torpedoes) {
      if (torp.isDetonated || torp.isDud) continue;
      const nextPos: Vector2D = {
        x: torp.position.x + torp.velocity.x * dt,
        y: torp.position.y + torp.velocity.y * dt,
      };
      const nearby = this.spatialGrid.queryRadius(nextPos.x, nextPos.y, 40);
      for (const ent of nearby) {
        if (ent.type !== 'VESSEL' || String(ent.id) === torp.shooterId) continue;
        const target = this.vessels.get(ent.id as number);
        if (!target || target.physics.isDestroyed) continue;
        const dist = vec2Distance(nextPos, target.physics.position);
        const hitRadius = (target.shipDef.beam + target.shipDef.length) / 4 + 4;
        if (dist <= hitRadius) {
          torp.isDetonated = true;
          this.applyDamage(Number(torp.shooterId), target.id, torp.damage);
          break;
        }
      }
    }

    // 4c. Cruise Missiles hitting target / ECM deflection
    for (const cm of this.weaponEngine.cruiseMissiles) {
      if (cm.isDetonated || cm.isIntercepted) continue;
      const distToTarget = vec2Distance(cm.position, cm.targetCoords);
      const stepDist = cm.currentSpeed * dt;
      if (distToTarget <= Math.max(25.0, stepDist * 1.5)) {
        const nearby = this.spatialGrid.queryRadius(cm.targetCoords.x, cm.targetCoords.y, 50);
        for (const ent of nearby) {
          if (ent.type !== 'VESSEL' || String(ent.id) === cm.shooterId) continue;
          const target = this.vessels.get(ent.id as number);
          if (!target || target.physics.isDestroyed) continue;
          // ECM jamming deflection check: 85% deflection probability
          if (target.ecmActive) {
            if (Math.random() < 0.85) {
              cm.isDetonated = true;
              this.queuedEvents.push({
                opcode: Opcode.OP_EVENT,
                eventType: GameEventType.ECM_PULSE,
                sourceId: target.id,
                targetId: Number(cm.shooterId),
                data: 85,
              });
              break;
            }
          }
          cm.isDetonated = true;
          this.applyDamage(Number(cm.shooterId), target.id, cm.damage);
          break;
        }
      }
    }

    // 4d. Rockets impacting
    for (const rocket of this.weaponEngine.rockets) {
      if (!rocket.isDetonated && rocket.timeElapsed + dt >= rocket.flightTimeTotal) {
        const nearby = this.spatialGrid.queryRadius(rocket.targetPos.x, rocket.targetPos.y, rocket.blastRadius + 30);
        for (const ent of nearby) {
          if (ent.type !== 'VESSEL' || String(ent.id) === rocket.shooterId) continue;
          const target = this.vessels.get(ent.id as number);
          if (!target || target.physics.isDestroyed) continue;
          if (target.physics.depthState === 'DEEP') continue;
          const dist = vec2Distance(rocket.targetPos, target.physics.position);
          const hitRadius = (target.shipDef.beam + target.shipDef.length) / 4 + rocket.blastRadius;
          if (dist <= hitRadius) {
            this.applyDamage(Number(rocket.shooterId), target.id, rocket.damage);
          }
        }
      }
    }

    // 4e. Rocket Torpedoes (ASROC) in underwater homing
    for (const asroc of this.weaponEngine.rocketTorpedoes) {
      if (asroc.isDetonated || asroc.isDud) continue;
      if (asroc.flightPhase === 'UNDERWATER_HOMING') {
        const nearby = this.spatialGrid.queryRadius(asroc.position.x, asroc.position.y, 40);
        for (const ent of nearby) {
          if (ent.type !== 'VESSEL' || String(ent.id) === asroc.shooterId) continue;
          const target = this.vessels.get(ent.id as number);
          if (!target || target.physics.isDestroyed) continue;
          const dist = vec2Distance(asroc.position, target.physics.position);
          const hitRadius = (target.shipDef.beam + target.shipDef.length) / 4 + 4;
          if (dist <= hitRadius) {
            asroc.isDetonated = true;
            this.applyDamage(Number(asroc.shooterId), target.id, asroc.damage);
            break;
          }
        }
      }
    }

    // 4f. Depth Charges sinking & hydrostatic / proximity detonation
    for (const dc of this.weaponEngine.depthCharges) {
      if (dc.isDetonated) continue;
      const nextDepth = dc.currentDepth - dc.sinkRate * dt;
      let shouldDetonate = nextDepth <= dc.targetDetonationDepth;
      if (!shouldDetonate) {
        for (const sub of submarines) {
          const hDist = vec2Distance(dc.position, sub.position);
          const vDist = Math.abs(nextDepth - sub.depthMeters);
          const dist3D = Math.sqrt(hDist * hDist + vDist * vDist);
          if (dist3D <= dc.proximityRadius) {
            shouldDetonate = true;
            break;
          }
        }
      }
      if (shouldDetonate) {
        dc.isDetonated = true;
        for (const sub of submarines) {
          const dmg = calculateDepthChargeDamage(
            dc.position,
            nextDepth,
            sub.position,
            sub.depthMeters,
            dc.baseDamage,
            dc.blastRadius
          );
          if (dmg > 0) {
            this.applyDamage(Number(dc.dropperId), Number(sub.id), dmg);
          }
        }
      }
    }

    // 4g. Naval Mines (contact & magnetic speed triggers)
    for (const mine of this.weaponEngine.mines) {
      if (mine.isDetonated || !mine.isArmed) continue;
      for (const vessel of this.vessels.values()) {
        if (vessel.physics.isDestroyed || String(vessel.id) === mine.deployerId) continue;
        const dist = vec2Distance(mine.position, vessel.physics.position);
        const isNearSurface = !vessel.shipDef.canSubmerge || vessel.physics.depthState !== 'DEEP';
        if (isNearSurface) {
          const contactHit = dist <= mine.contactRadius;
          const magneticHit = dist <= mine.magneticInfluenceRadius && vessel.physics.speedKnots >= mine.speedTriggerThresholdKnots;
          if (contactHit || magneticHit) {
            mine.isDetonated = true;
            this.applyDamage(Number(mine.deployerId), vessel.id, mine.damage);
            vessel.floodingTimer = mine.floodingDurationSeconds ?? 8.0;
            vessel.floodingPenalty = mine.floodingSpeedPenalty ?? 0.60;
            break;
          }
        }
      }
    }

    // 4h. Aircraft squadrons (Strike fighter attack runs & ASW Sonobuoy deployment)
    for (const air of this.weaponEngine.aircraft) {
      if (air.status === 'ATTACK_RUN' && air.payloadAmmo > 0) {
        const nearby = this.spatialGrid.queryRadius(air.position.x, air.position.y, 60);
        for (const ent of nearby) {
          if (ent.type !== 'VESSEL' || String(ent.id) === air.carrierId) continue;
          const target = this.vessels.get(ent.id as number);
          if (!target || target.physics.isDestroyed) continue;
          this.applyDamage(Number(air.carrierId), target.id, air.strikeDamage);
          air.payloadAmmo--;
          air.status = 'RETURNING';
          air.isReturning = true;
          break;
        }
      } else if (air.type === 'ASW_HELICOPTER' && air.canDeploySonobuoy && air.status === 'HOVERING') {
        this.weaponEngine.deployPersistentSonarBuoy(air.carrierId, air.position);
        air.canDeploySonobuoy = false;
        this.queuedEvents.push({
          opcode: Opcode.OP_EVENT,
          eventType: GameEventType.SONAR_BUOY_DEPLOY,
          sourceId: Number(air.carrierId),
          targetId: 0,
          data: 1200,
        });
      }
    }

    // 5. Step WeaponKinematicsEngine
    this.weaponEngine.step(dt, context);

    // 6. Step legacy projectiles map (if any)
    for (const [projId, proj] of this.projectiles.entries()) {
      const stepDist = Math.sqrt(proj.velocity.x * proj.velocity.x + proj.velocity.y * proj.velocity.y) * dt;
      proj.position.x += proj.velocity.x * dt;
      proj.position.y += proj.velocity.y * dt;
      proj.traveledDistance += stepDist;

      if (proj.traveledDistance >= proj.maxRange) {
        this.projectiles.delete(projId);
        continue;
      }

      // Check hits against vessels via spatial grid
      const nearby = this.spatialGrid.queryRadius(proj.position.x, proj.position.y, 40);
      let hit = false;

      for (const ent of nearby) {
        if (ent.type !== 'VESSEL' || ent.id === proj.ownerId) continue;
        const targetVessel = this.vessels.get(ent.id as number);
        if (!targetVessel || targetVessel.physics.isDestroyed) continue;

        // Submarine depth immunity check:
        if (targetVessel.physics.depthState === 'DEEP') {
          const canHitDeep = proj.category === 'DEPTH_CHARGE' || proj.category === 'TORPEDO' || proj.category === 'ROCKET_TORPEDO';
          if (!canHitDeep) continue;
        }

        // ECM deflection check
        if (targetVessel.ecmActive && proj.category === 'CRUISE_MISSILE') {
          if (Math.random() < 0.85) {
            hit = true;
            break;
          }
        }

        const dist = vec2Distance(proj.position, targetVessel.physics.position);
        const hitRadius = (targetVessel.shipDef.beam + targetVessel.shipDef.length) / 4;
        if (dist <= hitRadius) {
          this.applyDamage(proj.ownerId, targetVessel.id, proj.damage);
          hit = true;
          break;
        }
      }

      if (hit) {
        this.projectiles.delete(projId);
      }
    }

    // 3. Step resources: crates & oil rigs
    this.resourceEngine.step(dt);

    // Convert vessels to PlayerVesselRef for resource engine
    const vesselRefs: PlayerVesselRef[] = Array.from(this.vessels.values()).map(v => ({
      playerId: String(v.id),
      factionId: String(v.fleetId || v.teamId || v.id),
      shipDef: v.shipDef,
      physicsState: v.physics,
      accumulatedXp: v.accumulatedXp,
    }));

    // Crate collections
    for (const vRef of vesselRefs) {
      const { collectedCount, totalXpAwarded } = this.resourceEngine.checkCrateCollection(vRef);
      if (collectedCount > 0) {
        const v = this.vessels.get(Number(vRef.playerId));
        if (v) {
          v.accumulatedXp += totalXpAwarded;
          v.score += totalXpAwarded;
          // Heal hull 10% on crate pickup
          v.physics.hullHp = Math.min(v.shipDef.maxHp, v.physics.hullHp + v.shipDef.maxHp * 0.1);
          this.queuedEvents.push({
            opcode: Opcode.OP_EVENT,
            eventType: GameEventType.CRATE_COLLECT,
            sourceId: v.id,
            targetId: 0,
            data: totalXpAwarded,
          });
        }
      }
    }

    // Oil rig captures and passive XP extraction
    const { xpAwards } = this.resourceEngine.updateOilRigs(vesselRefs, dt);
    for (const [pId, xp] of xpAwards.entries()) {
      const v = this.vessels.get(Number(pId));
      if (v) {
        v.accumulatedXp += xp;
        v.score += Math.round(xp);
      }
    }
  }

  /**
   * Creates a compact binary SnapshotPacket representing current world state.
   */
  public createSnapshotPacket(ackSeq = 0): SnapshotPacket {
    const vesselRecords: VesselSnapshotRecord[] = [];

    for (const vessel of this.vessels.values()) {
      let flags = 0;
      if (vessel.physics.isCavitationNoise) flags |= VesselStatusFlag.CAVITATING;
      if (vessel.ecmActive) flags |= VesselStatusFlag.ECM_ACTIVE;
      if (vessel.physics.stealthModeActive) flags |= VesselStatusFlag.STEALTH_ACTIVE;
      if (vessel.physics.isGrounded) flags |= VesselStatusFlag.GROUNDED;
      if (vessel.physics.isDestroyed) flags |= VesselStatusFlag.DESTROYED;
      if (vessel.napTimers.size > 0) flags |= VesselStatusFlag.NAP_ACTIVE;

      const depthByte = vessel.physics.depthState === 'DEEP' ? 2 : vessel.physics.depthState === 'PERISCOPE' ? 1 : 0;
      const hpPct = Math.max(0, Math.min(100, Math.round((vessel.physics.hullHp / vessel.shipDef.maxHp) * 100)));

      const mountAngles: [number, number, number, number] = [
        vessel.mounts[0]?.currentAngle ?? 0,
        vessel.mounts[1]?.currentAngle ?? 0,
        vessel.mounts[2]?.currentAngle ?? 0,
        vessel.mounts[3]?.currentAngle ?? 0,
      ];

      vesselRecords.push({
        vesselId: vessel.id,
        posX: vessel.physics.position.x,
        posY: vessel.physics.position.y,
        heading: vessel.physics.heading,
        speedKnots: Math.round(vessel.physics.speedKnots),
        hullHpPct: hpPct,
        flags,
        depth: depthByte,
        mountAngles,
        velX: vessel.physics.linearVelocity.x,
        velY: vessel.physics.linearVelocity.y,
        fleetId: vessel.fleetId,
        targetId: 0,
      });
    }

    return {
      opcode: Opcode.OP_SNAPSHOT,
      flags: 0,
      serverTick: this.gameLoop.getCurrentTick(),
      ackSequence: ackSeq,
      entityCount: vesselRecords.length,
      worldTimeSeconds: Math.round(this.gameLoop.getWorldTimeSeconds()),
      vessels: vesselRecords,
    };
  }

  public drainQueuedEvents(): EventPacket[] {
    const events = [...this.queuedEvents];
    this.queuedEvents.length = 0;
    return events;
  }
}

export { AuthoritativeGameServer, AuthoritativeGameServer as GameServer };
