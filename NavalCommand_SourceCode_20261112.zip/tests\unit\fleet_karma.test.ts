/**
 * Fleet & Karma Models, Non-Aggression Pacts & Mercy Hospital Ship Unit Tests
 * Milestone M3 Part 2 Verification for NavalCommand.io
 */

import { describe, it, expect, beforeEach } from 'vitest';
import {
  MAX_VISIBLE_FLEETS,
  MAX_FLEET_MEMBERS,
  NAP_DURATION_SECONDS,
  BETRAYAL_WINDOW_SECONDS,
  BETRAYAL_KARMA_PENALTY,
  REPAIR_AURA_COOLDOWN,
  REPAIR_AURA_RADIUS,
  REPAIR_AURA_HP_PCT,
  KarmaStatus,
  KARMA_STATUS_THRESHOLDS,
  KARMA_COLORS,
  clampKarma,
  getKarmaStatus,
  getKarmaColor,
  createKarmaProfile,
  applyBetrayalPenalty,
  calculateMercyRepairAura,
  HospitalShipTarget,
  FleetManager,
} from '../../common/models/fleet.js';

describe('Fleet & Karma Models (Milestone M3 Part 2)', () => {
  let manager: FleetManager;

  beforeEach(() => {
    manager = new FleetManager();
  });

  // ==========================================================================
  // 1. CONSTANTS VERIFICATION
  // ==========================================================================
  describe('Constants & Specifications', () => {
    it('defines exact constants conforming to PROJECT.md specifications', () => {
      expect(MAX_VISIBLE_FLEETS).toBe(5);
      expect(MAX_FLEET_MEMBERS).toBe(8);
      expect(NAP_DURATION_SECONDS).toBe(15.0);
      expect(BETRAYAL_WINDOW_SECONDS).toBe(30.0);
      expect(BETRAYAL_KARMA_PENALTY).toBe(25);
      expect(REPAIR_AURA_COOLDOWN).toBe(30.0);
      expect(REPAIR_AURA_RADIUS).toBe(150.0);
      expect(REPAIR_AURA_HP_PCT).toBe(0.50);
    });
  });

  // ==========================================================================
  // 2. KARMA MODEL, CLAMPING & REPUTATION FSM
  // ==========================================================================
  describe('Karma Model & Clamping', () => {
    it('clamps karma scores strictly to [0, 100]', () => {
      expect(clampKarma(100)).toBe(100);
      expect(clampKarma(150)).toBe(100);
      expect(clampKarma(0)).toBe(0);
      expect(clampKarma(-50)).toBe(0);
      expect(clampKarma(75.4)).toBe(75);
      expect(clampKarma(75.8)).toBe(76);
      expect(clampKarma(NaN)).toBe(0);
    });

    it('evaluates KarmaStatus according to exact FSM thresholds', () => {
      // LOYAL: >= 80
      expect(getKarmaStatus(100)).toBe('LOYAL');
      expect(getKarmaStatus(80)).toBe('LOYAL');

      // SUSPECT: 40..79
      expect(getKarmaStatus(79)).toBe('SUSPECT');
      expect(getKarmaStatus(60)).toBe('SUSPECT');
      expect(getKarmaStatus(40)).toBe('SUSPECT');

      // TRAITOR: < 40
      expect(getKarmaStatus(39)).toBe('TRAITOR');
      expect(getKarmaStatus(20)).toBe('TRAITOR');
      expect(getKarmaStatus(0)).toBe('TRAITOR');
    });

    it('maps karma status and scores to correct visual name colors', () => {
      expect(getKarmaColor('LOYAL')).toBe('#00FF88');
      expect(getKarmaColor('SUSPECT')).toBe('#FFCC00');
      expect(getKarmaColor('TRAITOR')).toBe('#FF3333');

      // Numeric input resolution
      expect(getKarmaColor(90)).toBe('#00FF88');
      expect(getKarmaColor(55)).toBe('#FFCC00');
      expect(getKarmaColor(15)).toBe('#FF3333');
    });

    it('creates initial karma profiles defaulting to 100 LOYAL', () => {
      const profile = createKarmaProfile(101);
      expect(profile.playerId).toBe(101);
      expect(profile.karmaScore).toBe(100);
      expect(profile.status).toBe('LOYAL');
      expect(profile.color).toBe('#00FF88');
    });

    it('applies betrayal penalty (-25) with status transitions and clamping', () => {
      // 100 -> 75: LOYAL -> SUSPECT
      const res1 = applyBetrayalPenalty(100);
      expect(res1.newKarma).toBe(75);
      expect(res1.oldStatus).toBe('LOYAL');
      expect(res1.newStatus).toBe('SUSPECT');
      expect(res1.statusChanged).toBe(true);

      // 75 -> 50: SUSPECT -> SUSPECT (no status change)
      const res2 = applyBetrayalPenalty(75);
      expect(res2.newKarma).toBe(50);
      expect(res2.oldStatus).toBe('SUSPECT');
      expect(res2.newStatus).toBe('SUSPECT');
      expect(res2.statusChanged).toBe(false);

      // 50 -> 25: SUSPECT -> TRAITOR
      const res3 = applyBetrayalPenalty(50);
      expect(res3.newKarma).toBe(25);
      expect(res3.oldStatus).toBe('SUSPECT');
      expect(res3.newStatus).toBe('TRAITOR');
      expect(res3.statusChanged).toBe(true);

      // 15 -> 0: TRAITOR -> TRAITOR, clamped at 0
      const res4 = applyBetrayalPenalty(15);
      expect(res4.newKarma).toBe(0);
      expect(res4.newStatus).toBe('TRAITOR');
      expect(res4.newKarma).toBeGreaterThanOrEqual(0);
    });
  });

  // ==========================================================================
  // 3. FLEET LIFECYCLE & LIMIT ENFORCEMENT
  // ==========================================================================
  describe('Fleet Lifecycle & Max 5 Fleets Enforcement', () => {
    it('allows creation of up to 5 visible fleets per match', () => {
      for (let i = 1; i <= 5; i++) {
        const fleet = manager.createFleet(i, `Alpha Squadron ${i}`);
        expect(fleet).not.toBeNull();
        expect(fleet?.leaderId).toBe(i);
        expect(fleet?.fleetId).toBe(i);
      }
      expect(manager.getActiveFleetCount()).toBe(5);
    });

    it('strictly rejects creation of a 6th fleet', () => {
      for (let i = 1; i <= 5; i++) {
        manager.createFleet(i, `Fleet ${i}`);
      }
      expect(manager.getActiveFleetCount()).toBe(5);

      // Attempt 6th fleet creation
      const sixth = manager.createFleet(6, 'Illegal 6th Fleet');
      expect(sixth).toBeNull();
      expect(manager.getActiveFleetCount()).toBe(5);
    });

    it('prevents a player from creating multiple fleets simultaneously', () => {
      const first = manager.createFleet(42, 'First Fleet');
      expect(first).not.toBeNull();

      const second = manager.createFleet(42, 'Second Fleet');
      expect(second).toBeNull();
      expect(manager.getActiveFleetCount()).toBe(1);
    });

    it('prevents a player already in a fleet from creating a new fleet', () => {
      const fleet = manager.createFleet(1, 'Host Fleet');
      expect(fleet).not.toBeNull();

      // Player 2 joins fleet 1
      const joined = manager.joinFleet(fleet!.fleetId, 2);
      expect(joined).toBe(true);

      // Player 2 attempts to create their own fleet
      const rogueFleet = manager.createFleet(2, 'Rogue Fleet');
      expect(rogueFleet).toBeNull();
    });

    it('reclaims fleet slot when a fleet is disbanded', () => {
      for (let i = 1; i <= 5; i++) {
        manager.createFleet(i, `Fleet ${i}`);
      }
      expect(manager.getActiveFleetCount()).toBe(5);

      // Disband fleet 3
      const disbandRes = manager.disbandFleet(3, 3);
      expect(disbandRes.success).toBe(true);
      expect(manager.getActiveFleetCount()).toBe(4);

      // Now a 5th fleet can be successfully created again
      const newFleet = manager.createFleet(99, 'Reborn Fleet');
      expect(newFleet).not.toBeNull();
      expect(manager.getActiveFleetCount()).toBe(5);
    });

    it('sorts visible fleets by score, kills, and members up to 5', () => {
      for (let i = 1; i <= 5; i++) {
        const f = manager.createFleet(i, `Fleet ${i}`)!;
        f.score = i * 100;
        f.kills = i * 2;
      }

      const visible = manager.getVisibleFleets();
      expect(visible.length).toBe(5);
      expect(visible[0].score).toBe(500);
      expect(visible[4].score).toBe(100);
    });
  });

  // ==========================================================================
  // 4. INVITATION & MEMBERSHIP WORKFLOWS
  // ==========================================================================
  describe('Invitation & Membership Workflows', () => {
    it('manages invite lifecycle and verification', () => {
      const fleet = manager.createFleet(10, 'Carrier Strike Group')!;

      // Valid invite by leader
      const invited = manager.inviteMember(fleet.fleetId, 10, 20);
      expect(invited).toBe(true);
      expect(manager.getPendingInvites(20).length).toBe(1);

      // Invalid invite by non-member
      const rogueInvite = manager.inviteMember(fleet.fleetId, 999, 30);
      expect(rogueInvite).toBe(false);

      // Cannot invite player already in another fleet
      manager.createFleet(50, 'Submarine Wolfpack');
      const conflictInvite = manager.inviteMember(fleet.fleetId, 10, 50);
      expect(conflictInvite).toBe(false);

      // Cancel invite
      const canceled = manager.cancelInvite(fleet.fleetId, 20);
      expect(canceled).toBe(true);
      expect(manager.getPendingInvites(20).length).toBe(0);
    });

    it('enforces maximum 8 members per fleet', () => {
      const fleet = manager.createFleet(1, 'Dreadnought Armada')!;

      // Add 7 more members (total 8)
      for (let p = 2; p <= 8; p++) {
        expect(manager.joinFleet(fleet.fleetId, p)).toBe(true);
      }
      expect(fleet.memberIds.size).toBe(8);

      // 9th member rejected
      expect(manager.joinFleet(fleet.fleetId, 9)).toBe(false);
      expect(manager.inviteMember(fleet.fleetId, 1, 9)).toBe(false);
      expect(fleet.memberIds.size).toBe(8);
    });

    it('requires valid invite when requireInvite flag is set', () => {
      const fleet = manager.createFleet(1, 'Private Fleet')!;

      // Join without invite fails
      expect(manager.joinFleet(fleet.fleetId, 2, true)).toBe(false);

      // Issue invite
      manager.inviteMember(fleet.fleetId, 1, 2);
      expect(manager.joinFleet(fleet.fleetId, 2, true)).toBe(true);
      expect(fleet.memberIds.has(2)).toBe(true);

      // Invite is consumed
      expect(manager.getPendingInvites(2).length).toBe(0);
    });
  });

  // ==========================================================================
  // 5. AUTOMATIC 15-SECOND NON-AGGRESSION PACT (NAP)
  // ==========================================================================
  describe('Automatic 15-Second Non-Aggression Pact (NAP)', () => {
    it('automatically assigns 15s mutual NAP between departing member and all remaining fleetmates upon leave', () => {
      const fleet = manager.createFleet(1, 'Pacific Fleet')!;
      manager.joinFleet(fleet.fleetId, 2);
      manager.joinFleet(fleet.fleetId, 3);
      manager.joinFleet(fleet.fleetId, 4);

      // Member 4 leaves
      const leaveRes = manager.leaveFleet(4);
      expect(leaveRes.success).toBe(true);
      expect(leaveRes.formerMemberId).toBe(4);
      expect(leaveRes.remainingMemberIds).toEqual([1, 2, 3]);
      expect(leaveRes.createdNaps.length).toBe(3);

      for (const nap of leaveRes.createdNaps) {
        expect(nap.remainingSeconds).toBe(15.0);
        expect(nap.expiredSeconds).toBe(0);
        expect(nap.betrayalPenalized).toBe(false);
      }

      // Check active mutual NAP state
      expect(manager.hasActiveNAP(4, 1)).toBe(true);
      expect(manager.hasActiveNAP(1, 4)).toBe(true);
      expect(manager.hasActiveNAP(4, 2)).toBe(true);
      expect(manager.hasActiveNAP(2, 4)).toBe(true);
      expect(manager.hasActiveNAP(4, 3)).toBe(true);
      expect(manager.hasActiveNAP(3, 4)).toBe(true);

      // Unrelated player has no NAP
      expect(manager.hasActiveNAP(4, 99)).toBe(false);
    });

    it('automatically assigns 15s mutual NAP between kicked member and all remaining fleetmates upon kick', () => {
      const fleet = manager.createFleet(1, 'Atlantic Fleet')!;
      manager.joinFleet(fleet.fleetId, 2);
      manager.joinFleet(fleet.fleetId, 3);

      // Leader 1 kicks member 3
      const kickRes = manager.kickMember(1, 3);
      expect(kickRes.success).toBe(true);
      expect(kickRes.kickedMemberId).toBe(3);
      expect(kickRes.remainingMemberIds).toEqual([1, 2]);
      expect(kickRes.createdNaps.length).toBe(2);

      // Both members have 15s NAP with kicked member
      expect(manager.hasActiveNAP(3, 1)).toBe(true);
      expect(manager.hasActiveNAP(1, 3)).toBe(true);
      expect(manager.hasActiveNAP(3, 2)).toBe(true);
      expect(manager.hasActiveNAP(2, 3)).toBe(true);
    });

    it('assigns pairwise 15s mutual NAPs among all former members upon fleet disband', () => {
      const fleet = manager.createFleet(1, 'Task Force')!;
      manager.joinFleet(fleet.fleetId, 2);
      manager.joinFleet(fleet.fleetId, 3);

      const disbandRes = manager.disbandFleet(fleet.fleetId);
      expect(disbandRes.success).toBe(true);
      expect(disbandRes.createdNaps.length).toBe(3); // (1,2), (1,3), (2,3)

      expect(manager.hasActiveNAP(1, 2)).toBe(true);
      expect(manager.hasActiveNAP(1, 3)).toBe(true);
      expect(manager.hasActiveNAP(2, 3)).toBe(true);
    });

    it('enforces mutual zero damage (canDamage = false) during active 15s NAP', () => {
      const fleet = manager.createFleet(10, 'Fleet A')!;
      manager.joinFleet(fleet.fleetId, 20);

      // Member 20 leaves
      manager.leaveFleet(20);

      // During active NAP:
      expect(manager.canDamage(20, 10)).toBe(false);
      expect(manager.canDamage(10, 20)).toBe(false);

      // Attack record returns canDamage: false, 0 damage, 0 penalty
      const atk1 = manager.recordAttack(20, 10);
      expect(atk1.canDamage).toBe(false);
      expect(atk1.betrayalPenaltyApplied).toBe(false);
      expect(atk1.karmaLoss).toBe(0);

      const atk2 = manager.recordAttack(10, 20);
      expect(atk2.canDamage).toBe(false);
      expect(atk2.betrayalPenaltyApplied).toBe(false);
      expect(atk2.karmaLoss).toBe(0);
    });

    it('ticks down NAP timers accurately over time', () => {
      manager.setNAP(1, 2, 15.0);

      manager.tickNAPs(5.0);
      expect(manager.getNAP(1, 2)?.remainingSeconds).toBe(10.0);
      expect(manager.hasActiveNAP(1, 2)).toBe(true);

      manager.tickNAPs(10.0);
      expect(manager.getNAP(1, 2)?.remainingSeconds).toBe(0);
      expect(manager.hasActiveNAP(1, 2)).toBe(false);
    });
  });

  // ==========================================================================
  // 6. BETRAYAL WINDOW & KARMA PENALTIES
  // ==========================================================================
  describe('Betrayal Window (30s Post-NAP Expiry) & -25 Karma Penalties', () => {
    it('activates 30-second betrayal window immediately upon NAP expiration', () => {
      manager.setNAP(10, 20, 15.0);

      // Fast-forward 15 seconds to expire NAP
      manager.tickNAPs(15.0);
      expect(manager.hasActiveNAP(10, 20)).toBe(false);
      expect(manager.isInBetrayalWindow(10, 20)).toBe(true);
      expect(manager.isInBetrayalWindow(20, 10)).toBe(true);
    });

    it('penalizes attacker by -25 Karma and shifts reputation when attacking in betrayal window', () => {
      manager.setNAP(100, 200, 15.0);
      manager.tickNAPs(15.0); // NAP expires, betrayal window opens

      const initProfile = manager.getOrCreateKarmaProfile(100);
      expect(initProfile.karmaScore).toBe(100);
      expect(initProfile.status).toBe('LOYAL');
      expect(initProfile.color).toBe('#00FF88');

      // Player 100 attacks former teammate Player 200 within betrayal window
      const attackRes = manager.recordAttack(100, 200);
      expect(attackRes.canDamage).toBe(true);
      expect(attackRes.betrayalPenaltyApplied).toBe(true);
      expect(attackRes.karmaLoss).toBe(25);
      expect(attackRes.newKarma).toBe(75);
      expect(attackRes.newStatus).toBe('SUSPECT');

      // Check manager profile state
      const updatedProfile = manager.getKarmaProfile(100);
      expect(updatedProfile?.karmaScore).toBe(75);
      expect(updatedProfile?.status).toBe('SUSPECT');
      expect(updatedProfile?.color).toBe('#FFCC00'); // Yellow
    });

    it('debounces rapid multi-projectile attacks during the same betrayal window', () => {
      manager.setNAP(10, 20, 15.0);
      manager.tickNAPs(15.0);

      // First projectile hits: penalizes 25 points
      const hit1 = manager.recordAttack(10, 20);
      expect(hit1.betrayalPenaltyApplied).toBe(true);
      expect(hit1.newKarma).toBe(75);

      // Second projectile in the same volley hits immediately: does NOT penalize again
      const hit2 = manager.recordAttack(10, 20);
      expect(hit2.canDamage).toBe(true);
      expect(hit2.betrayalPenaltyApplied).toBe(false);
      expect(hit2.karmaLoss).toBe(0);
      expect(hit2.newKarma).toBe(75);
    });

    it('closes betrayal window after 30 seconds and inflicts zero karma penalty on future attacks', () => {
      manager.setNAP(10, 20, 15.0);
      manager.tickNAPs(15.0); // NAP expires

      // Advance time past the 30-second betrayal window (e.g. 30.1 seconds)
      manager.tickNAPs(30.1);
      expect(manager.isInBetrayalWindow(10, 20)).toBe(false);

      // Attacking now causes normal damage without betrayal penalty
      const attackRes = manager.recordAttack(10, 20);
      expect(attackRes.canDamage).toBe(true);
      expect(attackRes.betrayalPenaltyApplied).toBe(false);
      expect(attackRes.karmaLoss).toBe(0);
      expect(attackRes.newKarma).toBe(100);
    });

    it('cascades karma down to TRAITOR with multiple betrayals across separate windows, clamping strictly at 0', () => {
      const p = 555;

      // Window 1: 100 -> 75 (SUSPECT)
      manager.setNAP(p, 1, 15.0);
      manager.tickNAPs(15.0);
      manager.recordAttack(p, 1);
      expect(manager.getKarma(p)).toBe(75);
      expect(manager.getKarmaStatusForPlayer(p)).toBe('SUSPECT');
      expect(manager.getKarmaColorForPlayer(p)).toBe('#FFCC00');

      // Window 2: 75 -> 50 (SUSPECT)
      manager.setNAP(p, 2, 15.0);
      manager.tickNAPs(15.0);
      manager.recordAttack(p, 2);
      expect(manager.getKarma(p)).toBe(50);
      expect(manager.getKarmaStatusForPlayer(p)).toBe('SUSPECT');

      // Window 3: 50 -> 25 (TRAITOR)
      manager.setNAP(p, 3, 15.0);
      manager.tickNAPs(15.0);
      manager.recordAttack(p, 3);
      expect(manager.getKarma(p)).toBe(25);
      expect(manager.getKarmaStatusForPlayer(p)).toBe('TRAITOR');
      expect(manager.getKarmaColorForPlayer(p)).toBe('#FF3333'); // Red

      // Window 4: 25 -> 0 (TRAITOR, strictly clamped at 0)
      manager.setNAP(p, 4, 15.0);
      manager.tickNAPs(15.0);
      manager.recordAttack(p, 4);
      expect(manager.getKarma(p)).toBe(0);
      expect(manager.getKarmaStatusForPlayer(p)).toBe('TRAITOR');

      // Window 5: Attempt to go below 0 -> stays 0
      manager.setNAP(p, 5, 15.0);
      manager.tickNAPs(15.0);
      manager.recordAttack(p, 5);
      expect(manager.getKarma(p)).toBe(0);
    });
  });

  // ==========================================================================
  // 7. MERCY HOSPITAL SHIP 50% HP REPAIR AURA
  // ==========================================================================
  describe('Mercy Hospital Ship Repair Aura & 30s Cooldown', () => {
    const hospitalShip = {
      id: 1,
      fleetId: 10,
      repairCooldown: 0,
      position: { x: 100, y: 100 },
    };

    it('repairs damaged fleet allies within 150m for 50% of maximum HP', () => {
      const targets: HospitalShipTarget[] = [
        {
          id: 2,
          fleetId: 10, // Same fleet
          hullHp: 1000,
          maxHp: 3000, // 50% = 1500 heal -> 2500
          position: { x: 150, y: 100 }, // dx = 50m <= 150m
        },
        {
          id: 3,
          fleetId: 10, // Same fleet
          hullHp: 500,
          maxHp: 2000, // 50% = 1000 heal -> 1500
          position: { x: 100, y: 200 }, // dy = 100m <= 150m
        },
      ];

      const res = calculateMercyRepairAura(hospitalShip, targets);
      expect(res.cooldownTriggered).toBe(true);
      expect(res.repairedTargets.length).toBe(2);

      expect(res.repairedTargets[0]).toEqual({
        targetId: 2,
        healAmount: 1500,
        newHp: 2500,
      });

      expect(res.repairedTargets[1]).toEqual({
        targetId: 3,
        healAmount: 1000,
        newHp: 1500,
      });
    });

    it('caps healing so hull HP does not exceed max HP', () => {
      const targets: HospitalShipTarget[] = [
        {
          id: 2,
          fleetId: 10,
          hullHp: 2600,
          maxHp: 3000, // Missing 400 HP. 50% is 1500. Should cap at 400 heal -> 3000
          position: { x: 120, y: 100 },
        },
      ];

      const res = calculateMercyRepairAura(hospitalShip, targets);
      expect(res.cooldownTriggered).toBe(true);
      expect(res.repairedTargets[0].healAmount).toBe(400);
      expect(res.repairedTargets[0].newHp).toBe(3000);
    });

    it('heals hospital ship itself if damaged', () => {
      const damagedHospital = {
        ...hospitalShip,
      };

      const targets: HospitalShipTarget[] = [
        {
          id: 1, // Self
          fleetId: 10,
          hullHp: 1000,
          maxHp: 3000,
          position: { x: 100, y: 100 },
        },
      ];

      const res = calculateMercyRepairAura(damagedHospital, targets);
      expect(res.cooldownTriggered).toBe(true);
      expect(res.repairedTargets[0].targetId).toBe(1);
      expect(res.repairedTargets[0].healAmount).toBe(1500);
      expect(res.repairedTargets[0].newHp).toBe(2500);
    });

    it('does NOT heal targets beyond 150m radius', () => {
      const targets: HospitalShipTarget[] = [
        {
          id: 2,
          fleetId: 10,
          hullHp: 1000,
          maxHp: 3000,
          position: { x: 300, y: 100 }, // dx = 200m > 150m
        },
      ];

      const res = calculateMercyRepairAura(hospitalShip, targets);
      expect(res.cooldownTriggered).toBe(false);
      expect(res.repairedTargets.length).toBe(0);
    });

    it('does NOT heal enemies or neutral vessels outside fleet', () => {
      const targets: HospitalShipTarget[] = [
        {
          id: 99,
          fleetId: 99, // Enemy fleet
          hullHp: 500,
          maxHp: 3000,
          position: { x: 110, y: 100 }, // Inside 150m
        },
      ];

      const res = calculateMercyRepairAura(hospitalShip, targets);
      expect(res.cooldownTriggered).toBe(false);
      expect(res.repairedTargets.length).toBe(0);
    });

    it('does NOT heal destroyed vessels', () => {
      const targets: HospitalShipTarget[] = [
        {
          id: 2,
          fleetId: 10,
          hullHp: 0,
          maxHp: 3000,
          isDestroyed: true,
          position: { x: 110, y: 100 },
        },
      ];

      const res = calculateMercyRepairAura(hospitalShip, targets);
      expect(res.cooldownTriggered).toBe(false);
      expect(res.repairedTargets.length).toBe(0);
    });

    it('does NOT trigger when repair cooldown is active (> 0)', () => {
      const coolingHospital = {
        ...hospitalShip,
        repairCooldown: 12.5, // On cooldown
      };

      const targets: HospitalShipTarget[] = [
        {
          id: 2,
          fleetId: 10,
          hullHp: 1000,
          maxHp: 3000,
          position: { x: 110, y: 100 },
        },
      ];

      const res = calculateMercyRepairAura(coolingHospital, targets);
      expect(res.cooldownTriggered).toBe(false);
      expect(res.repairedTargets.length).toBe(0);
    });

    it('does NOT trigger cooldown if all nearby allies are already at full HP', () => {
      const targets: HospitalShipTarget[] = [
        {
          id: 2,
          fleetId: 10,
          hullHp: 3000,
          maxHp: 3000, // Full HP
          position: { x: 110, y: 100 },
        },
      ];

      const res = calculateMercyRepairAura(hospitalShip, targets);
      expect(res.cooldownTriggered).toBe(false);
      expect(res.repairedTargets.length).toBe(0);
    });
  });

  // ==========================================================================
  // 8. ADVERSARIAL STRESS & INVARIANT INTEGRITY
  // ==========================================================================
  describe('Adversarial Stress & Invariant Integrity', () => {
    it('maintains strict invariants under rapid membership churn', () => {
      const fleet = manager.createFleet(1, 'Churn Fleet')!;

      // 100 churn cycles: players join, leave, get kicked
      for (let i = 2; i <= 100; i++) {
        if (fleet.memberIds.size < 8) {
          manager.joinFleet(fleet.fleetId, i);
        } else {
          manager.kickMember(1, i - 1);
          manager.joinFleet(fleet.fleetId, i);
        }
      }

      expect(fleet.memberIds.size).toBeLessThanOrEqual(MAX_FLEET_MEMBERS);
      expect(manager.getActiveFleetCount()).toBe(1);
    });

    it('handles leader departure gracefully by promoting another member', () => {
      const fleet = manager.createFleet(1, 'Succession Fleet')!;
      manager.joinFleet(fleet.fleetId, 2);
      manager.joinFleet(fleet.fleetId, 3);

      // Leader 1 leaves
      const leaveRes = manager.leaveFleet(1);
      expect(leaveRes.success).toBe(true);
      expect(fleet.memberIds.has(1)).toBe(false);
      expect(fleet.leaderId).toBe(2); // Promoted to leader
      expect(manager.getFleetByMember(2)?.leaderId).toBe(2);
    });

    it('disbands fleet when sole member leaves', () => {
      const fleet = manager.createFleet(1, 'Solo Fleet')!;
      expect(manager.getActiveFleetCount()).toBe(1);

      const leaveRes = manager.leaveFleet(1);
      expect(leaveRes.success).toBe(true);
      expect(manager.getActiveFleetCount()).toBe(0);
      expect(manager.getFleet(fleet.fleetId)).toBeUndefined();
    });
  });
});
