/**
 * Free-For-All (FFA) Sandbox Game Mode Controller
 * Clean-Room implementation for NavalCommand.io
 */

import { Vector2D, vec2, vec2Distance } from '../../common/math/vector2.js';
import { Polygon, isPointInsidePolygon } from '../../common/math/polygon.js';
import { ShipDef, SHIP_ROSTER, getAllShipDefs } from '../../common/models/ships.js';
import { IslandEntity, DEFAULT_ISLAND_PRESETS } from '../../common/models/terrain.js';
import {
  GameModeType,
  IGameModeController,
  LeaderboardEntry,
  FFAState,
} from '../../common/models/game_modes.js';
import { AuthoritativeGameServer, ServerVessel } from '../core/game_server.js';

/**
 * Authoritative XP Curve Benchmarks per Specification:
 * T7: 630 XP, T8: 940 XP, T9: 1430 XP
 */
export const SPEC_TIER_XP_CURVE: Record<number, number> = {
  1: 0,
  2: 50,
  3: 120,
  4: 240,
  5: 400,
  6: 500,
  7: 630,
  8: 940,
  9: 1430,
  10: 2200,
};

export interface FFASandboxOptions {
  respawnCooldownSeconds?: number;
  islandSafeDistance?: number;  // > 150m
  enemySafeDistance?: number;   // > 400m
  mapBounds?: { minX: number; maxX: number; minY: number; maxY: number };
}

interface PendingRespawn {
  vesselId: number;
  timerRemaining: number;
  shipId?: string;
}

export class FFASandboxMode implements IGameModeController {
  public readonly modeType = GameModeType.FFA_SANDBOX;

  private server: AuthoritativeGameServer;
  private worldTime = 0;
  private respawnCooldown: number;
  private islandSafeDist: number;
  private enemySafeDist: number;
  private mapBounds: { minX: number; maxX: number; minY: number; maxY: number };

  private pendingRespawns: Map<number, PendingRespawn> = new Map();
  private cachedLeaderboard: LeaderboardEntry[] = [];

  constructor(server: AuthoritativeGameServer, options: FFASandboxOptions = {}) {
    this.server = server;
    this.respawnCooldown = options.respawnCooldownSeconds ?? 3.0;
    this.islandSafeDist = options.islandSafeDistance ?? 150.0;
    this.enemySafeDist = options.enemySafeDistance ?? 400.0;
    this.mapBounds = options.mapBounds ?? {
      minX: -4000,
      maxX: 4000,
      minY: -4000,
      maxY: 4000,
    };
  }

  public tick(dt: number): void {
    this.worldTime += dt;

    // 1. Process pending respawns
    for (const [vesselId, entry] of this.pendingRespawns.entries()) {
      entry.timerRemaining -= dt;
      if (entry.timerRemaining <= 0) {
        this.pendingRespawns.delete(vesselId);
        this.respawnVessel(vesselId, entry.shipId);
      }
    }

    // 2. Refresh top-10 leaderboard
    this.updateLeaderboard();
  }

  public handleKill(killerId: number, victimId: number): void {
    const victim = this.server.getVessel(victimId);
    if (!victim) return;

    // Schedule persistent safe respawn
    this.pendingRespawns.set(victimId, {
      vesselId: victimId,
      timerRemaining: this.respawnCooldown,
      shipId: victim.shipDef.id,
    });
  }

  public handleVesselSpawn(vesselId: number): void {
    // Vessel spawned into sandbox
    this.pendingRespawns.delete(vesselId);
    this.updateLeaderboard();
  }

  public handleVesselDespawn(vesselId: number): void {
    this.pendingRespawns.delete(vesselId);
    this.updateLeaderboard();
  }

  public getState(): FFAState {
    return {
      worldTime: this.worldTime,
      activeVesselsCount: this.server.getAllVessels().filter(v => !v.physics.isDestroyed).length,
      leaderboard: [...this.cachedLeaderboard],
      pendingRespawnCount: this.pendingRespawns.size,
    };
  }

  public reset(): void {
    this.worldTime = 0;
    this.pendingRespawns.clear();
    this.cachedLeaderboard = [];
  }

  /**
   * Evaluates if a vessel qualifies for next-tier progression based on SPEC_TIER_XP_CURVE.
   */
  public canUpgradeTier(vesselId: number): boolean {
    const vessel = this.server.getVessel(vesselId);
    if (!vessel || vessel.physics.isDestroyed) return false;

    const currentTier = vessel.shipDef.tier;
    const nextTier = currentTier + 1;
    if (nextTier > 10) return false;

    const requiredXp = SPEC_TIER_XP_CURVE[nextTier];
    if (requiredXp === undefined) return false;

    return vessel.accumulatedXp >= requiredXp;
  }

  /**
   * Upgrades a vessel to the next tier, recalculating stats, HP, and weapon mounts.
   */
  public upgradeVessel(vesselId: number, targetShipId?: string): boolean {
    if (!this.canUpgradeTier(vesselId)) return false;

    const vessel = this.server.getVessel(vesselId);
    if (!vessel) return false;

    const currentTier = vessel.shipDef.tier;
    const nextTier = currentTier + 1;

    let targetDef: ShipDef | undefined;
    if (targetShipId && SHIP_ROSTER[targetShipId] && SHIP_ROSTER[targetShipId].tier === nextTier) {
      targetDef = SHIP_ROSTER[targetShipId];
    } else {
      // Pick first ship matching next tier in roster
      targetDef = getAllShipDefs().find(s => s.tier === nextTier);
    }

    if (!targetDef) return false;

    // Swap ship definition & deep clone mounts
    vessel.shipDef = targetDef;
    vessel.mounts = targetDef.mounts.map(m => ({ ...m }));

    // Reset hull HP to new tier maxHp and restore active operational state
    vessel.physics.hullHp = targetDef.maxHp;

    // Update spatial grid entity radius
    this.server.spatialGrid.update({
      id: vessel.id,
      type: 'VESSEL',
      x: vessel.physics.position.x,
      y: vessel.physics.position.y,
      radius: Math.max(targetDef.length, targetDef.beam) / 2,
      data: vessel,
    });

    this.updateLeaderboard();
    return true;
  }

  /**
   * Finds a safe spawn position satisfying:
   * 1. Distance to island boundaries > 150m.
   * 2. Distance to active enemy warships > 400m.
   */
  public findSafeSpawnPosition(excludeVesselId?: number): Vector2D {
    const islands = this.server.getIslands();
    const activeVessels = this.server.getAllVessels().filter(
      v => !v.physics.isDestroyed && (excludeVesselId === undefined || v.id !== excludeVesselId)
    );

    const isSafe = (pos: Vector2D): boolean => {
      // 1. Island distance check (> 150m from perimeter and not inside polygon)
      for (const island of islands) {
        if (isPointInsidePolygon(pos, island.polygon)) {
          return false;
        }
        const dist = this.distanceToPolygon(pos, island.polygon);
        if (dist <= this.islandSafeDist) {
          return false;
        }
      }

      // 2. Enemy warship distance check (> 400m from any active warship)
      for (const enemy of activeVessels) {
        const dist = vec2Distance(pos, enemy.physics.position);
        if (dist <= this.enemySafeDist) {
          return false;
        }
      }

      return true;
    };

    // Attempt random positions within bounds
    const maxAttempts = 60;
    for (let i = 0; i < maxAttempts; i++) {
      const candidate: Vector2D = {
        x: this.mapBounds.minX + Math.random() * (this.mapBounds.maxX - this.mapBounds.minX),
        y: this.mapBounds.minY + Math.random() * (this.mapBounds.maxY - this.mapBounds.minY),
      };

      if (isSafe(candidate)) {
        return candidate;
      }
    }

    // Fallback: systematic grid scan
    const step = 200;
    for (let x = this.mapBounds.minX; x <= this.mapBounds.maxX; x += step) {
      for (let y = this.mapBounds.minY; y <= this.mapBounds.maxY; y += step) {
        const candidate = vec2(x, y);
        if (isSafe(candidate)) {
          return candidate;
        }
      }
    }

    // Ultimate fallback if map is extremely congested
    return vec2(this.mapBounds.minX, this.mapBounds.minY);
  }

  /**
   * Respawns a destroyed vessel with full HP, zero velocity, and reloaded mounts at a safe position.
   */
  public respawnVessel(vesselId: number, shipId?: string): ServerVessel | null {
    const vessel = this.server.getVessel(vesselId);
    if (!vessel) return null;

    if (shipId && SHIP_ROSTER[shipId]) {
      vessel.shipDef = SHIP_ROSTER[shipId];
      vessel.mounts = vessel.shipDef.mounts.map(m => ({ ...m }));
    }

    const safePos = this.findSafeSpawnPosition(vesselId);

    // Reset physics state
    vessel.physics.position = { ...safePos };
    vessel.physics.linearVelocity = { x: 0, y: 0 };
    vessel.physics.speedKnots = 0;
    vessel.physics.throttle = 0;
    vessel.physics.rudderAngle = 0;
    vessel.physics.heading = Math.random() * Math.PI * 2;
    vessel.physics.hullHp = vessel.shipDef.maxHp;
    vessel.physics.isDestroyed = false;
    vessel.physics.isGrounded = false;
    vessel.physics.depthState = 'SURFACE';
    vessel.physics.currentDepth = 0;
    vessel.physics.stealthModeActive = false;
    vessel.floodingTimer = 0;
    vessel.floodingPenalty = 0;

    // Reload mounts
    for (const mount of vessel.mounts) {
      mount.reloadTimeRemaining = 0;
      mount.ammoCurrent = mount.ammoMax;
    }

    this.pendingRespawns.delete(vesselId);

    this.server.spatialGrid.update({
      id: vessel.id,
      type: 'VESSEL',
      x: safePos.x,
      y: safePos.y,
      radius: Math.max(vessel.shipDef.length, vessel.shipDef.beam) / 2,
      data: vessel,
    });

    this.updateLeaderboard();
    return vessel;
  }

  /**
   * Returns current real-time top-10 leaderboard.
   */
  public getLeaderboard(): LeaderboardEntry[] {
    return [...this.cachedLeaderboard];
  }

  public getPendingRespawn(vesselId: number): PendingRespawn | undefined {
    return this.pendingRespawns.get(vesselId);
  }

  private updateLeaderboard(): void {
    const vessels = this.server.getAllVessels();
    const entries: LeaderboardEntry[] = vessels.map(v => ({
      vesselId: v.id,
      name: v.name,
      score: v.score,
      kills: v.kills,
      deaths: v.deaths,
      accumulatedXp: Math.round(v.accumulatedXp),
      tier: v.shipDef.tier,
      shipId: v.shipDef.id,
    }));

    // Rank descending by accumulatedXp, then score, then kills
    entries.sort((a, b) => {
      if (b.accumulatedXp !== a.accumulatedXp) {
        return b.accumulatedXp - a.accumulatedXp;
      }
      if (b.score !== a.score) {
        return b.score - a.score;
      }
      return b.kills - a.kills;
    });

    this.cachedLeaderboard = entries.slice(0, 10);
  }

  private distanceToPolygon(p: Vector2D, poly: Polygon): number {
    let minDist = Number.POSITIVE_INFINITY;
    const verts = poly.vertices;

    for (let i = 0; i < verts.length; i++) {
      const a = verts[i];
      const b = verts[(i + 1) % verts.length];
      const dist = this.pointToSegmentDistance(p, a, b);
      if (dist < minDist) {
        minDist = dist;
      }
    }

    return minDist;
  }

  private pointToSegmentDistance(p: Vector2D, a: Vector2D, b: Vector2D): number {
    const abX = b.x - a.x;
    const abY = b.y - a.y;
    const lenSq = abX * abX + abY * abY;
    if (lenSq < 1e-6) {
      const dx = p.x - a.x;
      const dy = p.y - a.y;
      return Math.sqrt(dx * dx + dy * dy);
    }
    const apX = p.x - a.x;
    const apY = p.y - a.y;
    let t = (apX * abX + apY * abY) / lenSq;
    t = Math.max(0, Math.min(1, t));
    const projX = a.x + t * abX;
    const projY = a.y + t * abY;
    const dx = p.x - projX;
    const dy = p.y - projY;
    return Math.sqrt(dx * dx + dy * dy);
  }
}
