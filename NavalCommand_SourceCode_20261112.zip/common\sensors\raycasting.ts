/**
 * Raycasting & Line-of-Sight Sensor Algorithms
 * Clean-Room implementation for NavalCommand.io
 */

import {
  Vector2D,
  vec2,
  vec2Add,
  vec2Sub,
  vec2Dot,
  vec2Normalize,
  vec2Perp,
  vec2Distance,
  vec2Scale,
  vec2LengthSq,
} from '../math/vector2.js';
import { Polygon, isPointInsidePolygon } from '../math/polygon.js';
import { SubmarineDepthState } from '../models/types.js';
import { IslandEntity } from '../models/terrain.js';

export interface RaycastHit {
  hit: boolean;
  distance: number;
  point: Vector2D;
  normal?: Vector2D;
  islandId?: string;
}

export interface VisualLoSResult {
  hasLoS: boolean;
  distance: number;
  isOccludedByIsland: boolean;
  occludingIslandId?: string;
  hitPoint?: Vector2D;
  depthLimited: boolean;
}

export interface RadarDetectionResult {
  detected: boolean;
  reportedPosition: Vector2D;
  trueDistance: number;
  isBlurred: boolean;
  uncertaintyRadius: number;
  isOccluded: boolean;
  deflected: boolean;
}

export const VISUAL_MAX_RANGE_DEFAULT = 1000.0; // 1000m visual range default
export const SUB_PERISCOPE_VISUAL_MAX_RANGE = 250.0; // 250m max visibility for periscope wake
export const RADAR_BASE_RANGE_DEFAULT = 2000.0; // 2000m base radar range
export const RADAR_REFERENCE_RCS = 20.0; // RCS normalization factor (20 m^2)
export const SUB_PERISCOPE_RCS = 1.0; // Periscope mast RCS (1.0 m^2)
export const ECM_UNCERTAINTY_RADIUS_DEFAULT = 150.0; // 150m ECM spatial blur radius
export const ECM_DEFLECTION_PROBABILITY = 0.85; // 85% missile deflection rate

/**
 * Calculates continuous 2D intersection point between two line segments:
 * Segment 1: p1 -> p2
 * Segment 2: q1 -> q2
 * Returns intersection point Vector2D or null if non-intersecting / parallel.
 */
export function lineSegmentIntersection(
  p1: Vector2D,
  p2: Vector2D,
  q1: Vector2D,
  q2: Vector2D
): Vector2D | null {
  const dx1 = p2.x - p1.x;
  const dy1 = p2.y - p1.y;
  const dx2 = q2.x - q1.x;
  const dy2 = q2.y - q1.y;

  const det = dx1 * dy2 - dy1 * dx2;
  if (Math.abs(det) < 1e-9) {
    // Segments are parallel or collinear
    return null;
  }

  const dx = q1.x - p1.x;
  const dy = q1.y - p1.y;

  const t = (dx * dy2 - dy * dx2) / det;
  const u = (dx * dy1 - dy * dx1) / det;

  const epsilon = 1e-6;
  if (t >= -epsilon && t <= 1 + epsilon && u >= -epsilon && u <= 1 + epsilon) {
    const clampedT = Math.max(0, Math.min(1, t));
    return {
      x: p1.x + clampedT * dx1,
      y: p1.y + clampedT * dy1,
    };
  }

  return null;
}

/**
 * Tests if line segment p1 -> p2 intersects any edge of the given polygon.
 * Returns the closest RaycastHit from p1, or null if no intersection.
 */
export function segmentIntersectsPolygon(
  p1: Vector2D,
  p2: Vector2D,
  poly: Polygon
): RaycastHit | null {
  const verts = poly.vertices;
  if (verts.length < 3) return null;

  // Check if starting point is already inside polygon
  if (isPointInsidePolygon(p1, poly)) {
    return {
      hit: true,
      distance: 0,
      point: { ...p1 },
      normal: { x: 0, y: 0 },
    };
  }

  let closestHit: RaycastHit | null = null;
  let minDistanceSq = Number.POSITIVE_INFINITY;

  for (let i = 0; i < verts.length; i++) {
    const vA = verts[i];
    const vB = verts[(i + 1) % verts.length];

    const hitPoint = lineSegmentIntersection(p1, p2, vA, vB);
    if (hitPoint) {
      const distSq = vec2DistanceSq(p1, hitPoint);
      if (distSq < minDistanceSq) {
        minDistanceSq = distSq;

        // Calculate outward surface normal
        const edge = vec2Sub(vB, vA);
        let normal = vec2Normalize(vec2Perp(edge));
        // Normal should face toward ray origin p1
        const toOrigin = vec2Sub(p1, hitPoint);
        if (vec2Dot(normal, toOrigin) < 0) {
          normal = { x: -normal.x, y: -normal.y };
        }

        closestHit = {
          hit: true,
          distance: Math.sqrt(distSq),
          point: hitPoint,
          normal,
        };
      }
    }
  }

  return closestHit;
}

/**
 * Performs raycast from origin along direction vector up to maxDistance against island polygons.
 * Returns RaycastHit for the closest obstacle, or null if unobstructed.
 */
export function raycastIslands(
  origin: Vector2D,
  direction: Vector2D,
  maxDistance: number,
  islands: IslandEntity[]
): RaycastHit | null {
  if (maxDistance <= 0) return null;
  const dirNorm = vec2Normalize(direction);
  if (vec2LengthSq(dirNorm) < 1e-9) return null;

  const target = vec2Add(origin, vec2Scale(dirNorm, maxDistance));
  let closestHit: RaycastHit | null = null;
  let minDistance = Number.POSITIVE_INFINITY;

  for (const island of islands) {
    const hit = segmentIntersectsPolygon(origin, target, island.polygon);
    if (hit && hit.distance < minDistance) {
      minDistance = hit.distance;
      closestHit = {
        ...hit,
        islandId: island.id,
      };
    }
  }

  return closestHit;
}

/**
 * Tests direct unoccluded line-of-sight between two points across all islands.
 * Returns true if ray is clear, false if occluded by any island polygon.
 */
export function checkLineOfSight(
  origin: Vector2D,
  target: Vector2D,
  islands: IslandEntity[]
): boolean {
  for (const island of islands) {
    const hit = segmentIntersectsPolygon(origin, target, island.polygon);
    if (hit) {
      return false;
    }
  }
  return true;
}

/**
 * Evaluates Visual Line-of-Sight between observer and target:
 * - Submarines at DEEP depth have 0 visual visibility.
 * - Submarines at PERISCOPE depth have reduced visibility (<= 250m).
 * - Target at SURFACE depth visible up to maxVisualRange (default 1000m).
 * - Island polygons block visual line-of-sight.
 */
export function checkVisualLoS(
  observerPos: Vector2D,
  targetPos: Vector2D,
  targetDepth: SubmarineDepthState,
  islands: IslandEntity[],
  maxVisualRange: number = VISUAL_MAX_RANGE_DEFAULT
): VisualLoSResult {
  const dist = vec2Distance(observerPos, targetPos);

  // Depth gating
  if (targetDepth === 'DEEP') {
    return {
      hasLoS: false,
      distance: dist,
      isOccludedByIsland: false,
      depthLimited: true,
    };
  }

  if (targetDepth === 'PERISCOPE') {
    if (dist > SUB_PERISCOPE_VISUAL_MAX_RANGE) {
      return {
        hasLoS: false,
        distance: dist,
        isOccludedByIsland: false,
        depthLimited: true,
      };
    }
  } else if (dist > maxVisualRange) {
    return {
      hasLoS: false,
      distance: dist,
      isOccludedByIsland: false,
      depthLimited: false,
    };
  }

  // Check island occlusion
  for (const island of islands) {
    const hit = segmentIntersectsPolygon(observerPos, targetPos, island.polygon);
    if (hit) {
      return {
        hasLoS: false,
        distance: dist,
        isOccludedByIsland: true,
        occludingIslandId: island.id,
        hitPoint: hit.point,
        depthLimited: false,
      };
    }
  }

  return {
    hasLoS: true,
    distance: dist,
    isOccludedByIsland: false,
    depthLimited: false,
  };
}

/**
 * Calculates radar detection range scaling with target Radar Cross Section (RCS):
 * R_max = R_base * (RCS / 20.0)^0.25
 */
export function calculateRadarDetectionRange(
  baseRadarRange: number,
  targetRCS: number
): number {
  const safeRcs = Math.max(targetRCS, 0.01);
  return baseRadarRange * Math.pow(safeRcs / RADAR_REFERENCE_RCS, 0.25);
}

/**
 * Checks whether radar line-of-sight between transmitter and target is blocked by islands.
 */
export function checkRadarOcclusion(
  transmitterPos: Vector2D,
  targetPos: Vector2D,
  islands: IslandEntity[]
): boolean {
  return !checkLineOfSight(transmitterPos, targetPos, islands);
}

/**
 * Evaluates radar detection considering RCS scaling, depth state, island occlusion,
 * and active ECM jamming position jitter/blurring.
 */
export function evaluateRadarDetection(
  transmitterPos: Vector2D,
  targetPos: Vector2D,
  targetRCS: number,
  targetDepth: SubmarineDepthState,
  targetEcmActive: boolean,
  islands: IslandEntity[],
  baseRadarRange: number = RADAR_BASE_RANGE_DEFAULT,
  jitterOffset?: Vector2D
): RadarDetectionResult {
  const trueDist = vec2Distance(transmitterPos, targetPos);

  // Submarines at DEEP depth have zero radar cross-section (radar waves cannot penetrate water)
  if (targetDepth === 'DEEP') {
    return {
      detected: false,
      reportedPosition: { ...targetPos },
      trueDistance: trueDist,
      isBlurred: false,
      uncertaintyRadius: 0,
      isOccluded: false,
      deflected: false,
    };
  }

  // Submarines at PERISCOPE depth expose only their mast (minimal RCS)
  const effectiveRCS = targetDepth === 'PERISCOPE' ? SUB_PERISCOPE_RCS : targetRCS;
  const maxRange = calculateRadarDetectionRange(baseRadarRange, effectiveRCS);

  if (trueDist > maxRange) {
    return {
      detected: false,
      reportedPosition: { ...targetPos },
      trueDistance: trueDist,
      isBlurred: false,
      uncertaintyRadius: 0,
      isOccluded: false,
      deflected: false,
    };
  }

  // Island occlusion check
  if (checkRadarOcclusion(transmitterPos, targetPos, islands)) {
    return {
      detected: false,
      reportedPosition: { ...targetPos },
      trueDistance: trueDist,
      isBlurred: false,
      uncertaintyRadius: 0,
      isOccluded: true,
      deflected: false,
    };
  }

  // Target is within detection range and unoccluded
  if (targetEcmActive) {
    // ECM Jamming blurs position by introducing bounded spatial jitter
    let offset: Vector2D;
    if (jitterOffset) {
      offset = jitterOffset;
    } else {
      // Deterministic angle based on positions for stability when no seed is given
      const seedAngle = (targetPos.x * 0.013 + targetPos.y * 0.017) % (2 * Math.PI);
      const jitterDist = 120.0;
      offset = {
        x: Math.cos(seedAngle) * jitterDist,
        y: Math.sin(seedAngle) * jitterDist,
      };
    }

    return {
      detected: true,
      reportedPosition: vec2Add(targetPos, offset),
      trueDistance: trueDist,
      isBlurred: true,
      uncertaintyRadius: ECM_UNCERTAINTY_RADIUS_DEFAULT,
      isOccluded: false,
      deflected: true,
    };
  }

  return {
    detected: true,
    reportedPosition: { ...targetPos },
    trueDistance: trueDist,
    isBlurred: false,
    uncertaintyRadius: 0,
    isOccluded: false,
    deflected: false,
  };
}

function vec2DistanceSq(a: Vector2D, b: Vector2D): number {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  return dx * dx + dy * dy;
}
