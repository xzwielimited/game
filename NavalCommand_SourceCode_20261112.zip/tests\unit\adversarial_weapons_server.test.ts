/**
 * Adversarial Weapons & Server Integration Challenge Suite
 * Milestone M2 Verification for NavalCommand.io
 *
 * Empirical adversarial stress harness challenging:
 * 1. Simultaneous firing of all 10 weapon types in a single server tick.
 * 2. Friendly fire & Non-Aggression Pact compliance across weapon explosions.
 * 3. Automated CIWS envelope engagement limits & ammo depletion handling.
 * 4. Torpedo acoustic cone edge boundaries (+/- 35 deg).
 * 5. Invariant stability under entity destruction and game loop stress.
 * 6. Advanced seeker loudness ranking, self-homing immunity & terrain interaction.
 */

import { describe, it, expect, beforeEach } from 'vitest';
import {
  Vector2D,
  vec2,
  vec2Distance,
  degToRad,
  radToDeg,
  normalizeAngle,
  shortestAngleDiff,
  SHIP_ROSTER,
  ShipDef,
  WeaponMountDef,
  WeaponCategory,
  WEAPON_DEFINITIONS,
  createWeaponMount,
  canMountFire,
  fireMount,
  stepMountReloadAndRegen,
  stepMountTraverse,
  isAngleWithinMountArc,
  createArtilleryShell,
  stepArtilleryShell,
  createTorpedo,
  createTorpedoDecoy,
  stepTorpedo,
  stepTorpedoDecoy,
  createCruiseMissile,
  stepCruiseMissile,
  createRocket,
  stepRocket,
  createRocketTorpedo,
  stepRocketTorpedo,
  stepCIWSEnvelope,
  launchSAMInterceptor,
  stepSAMInterceptor,
  createDepthCharge,
  calculateDepthChargeDamage,
  stepDepthCharge,
  createNavalMine,
  stepNavalMine,
  createAircraftSquadron,
  stepAircraft,
  deploySonarBuoy,
  stepSonarBuoy,
  executeDredgerAction,
  WeaponKinematicsEngine,
  WeaponKinematicsWorldContext,
  TerrainEngine,
  SubmarineContact,
  SurfaceVesselContact,
  AcousticContact,
  ThreatTarget,
  GameEventType,
} from '../../common/index.js';
import { AuthoritativeGameServer } from '../../server/core/game_server.js';

describe('Adversarial M2 Verification: Weapons Kinematics & Server Invariants', () => {
  let server: AuthoritativeGameServer;

  beforeEach(() => {
    server = new AuthoritativeGameServer(20);
  });

  // ==========================================================================
  // 1. Simultaneous Firing of All 10 Weapon Types in a Single Server Tick
  // ==========================================================================
  describe('1. Simultaneous Multi-Weapon Concurrency in Single Tick', () => {
    it('fires all 10 weapon categories simultaneously on a single vessel in one tick', () => {
      const allCategoryMounts: WeaponMountDef[] = [
        createWeaponMount('m_art', 'heavy_gun_460mm', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_torp', 'torpedo_acoustic_homing', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_cm', 'cruise_missile_vls', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_rock', 'rocket_barrage_rbu', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_asroc', 'rocket_torpedo_asroc', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_dc', 'depth_charge_rack', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_mine', 'naval_mine_layer', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_air', 'carrier_strike_wing', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_dredge', 'hydraulic_dredge_arm', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_sam', 'sam_interceptor', { x: 0, y: 0 }, 0, Math.PI * 2),
      ];

      const dreadnought = server.spawnVessel({ position: vec2(0, 0), heading: 0 });
      dreadnought.mounts = allCategoryMounts;

      const targetPos = vec2(500, 500);

      // Fire all 10 mounts simultaneously
      const results: boolean[] = [];
      for (let i = 0; i < 10; i++) {
        results.push(server.fireMount(dreadnought.id, i, targetPos));
      }

      // Assert all 10 mounts fired successfully
      expect(results).toEqual(new Array(10).fill(true));

      // Assert active entities in weaponEngine
      expect(server.weaponEngine.shells.length).toBe(1);
      expect(server.weaponEngine.torpedoes.length).toBe(1);
      expect(server.weaponEngine.cruiseMissiles.length).toBe(1);
      expect(server.weaponEngine.rockets.length).toBe(12); // RBU-6000 fires 12 rockets
      expect(server.weaponEngine.rocketTorpedoes.length).toBe(1);
      expect(server.weaponEngine.depthCharges.length).toBe(1);
      expect(server.weaponEngine.mines.length).toBe(1);
      expect(server.weaponEngine.aircraft.length).toBe(1);
      expect(server.weaponEngine.samInterceptors.length).toBe(1);

      // Assert ammo decrement on all mounts
      for (const m of dreadnought.mounts) {
        expect(m.ammoCurrent).toBeLessThan(m.ammoMax);
        expect(m.reloadTimeRemaining).toBeGreaterThan(0);
      }

      // Step simulation for 10 ticks and ensure no NaN/Infinity or crash
      for (let t = 0; t < 10; t++) {
        expect(() => server.step(0.05)).not.toThrow();
      }

      // Validate coordinates of all entities remain finite
      for (const s of server.weaponEngine.shells) {
        expect(Number.isFinite(s.currentPos.x)).toBe(true);
        expect(Number.isFinite(s.currentPos.y)).toBe(true);
      }
      for (const torp of server.weaponEngine.torpedoes) {
        expect(Number.isFinite(torp.position.x)).toBe(true);
        expect(Number.isFinite(torp.position.y)).toBe(true);
      }
      for (const cm of server.weaponEngine.cruiseMissiles) {
        expect(Number.isFinite(cm.position.x)).toBe(true);
        expect(Number.isFinite(cm.position.y)).toBe(true);
      }
    });

    it('rejects firing when mounts have 0 ammo or are undergoing reload cooldown', () => {
      const v = server.spawnVessel({ position: vec2(0, 0) });
      const mount = v.mounts[0];
      mount.ammoCurrent = 0;

      const fired = server.fireMount(v.id, 0, vec2(100, 100));
      expect(fired).toBe(false);

      // Restore ammo but set reload timer
      mount.ammoCurrent = 5;
      mount.reloadTimeRemaining = 2.0;
      const firedReloading = server.fireMount(v.id, 0, vec2(100, 100));
      expect(firedReloading).toBe(false);
    });

    it('enforces Submarine DEEP depth launch restrictions for cruise missiles and aircraft', () => {
      const sub = server.spawnVessel({ shipId: 'type_vii_sub', position: vec2(0, 0) });
      sub.physics.depthState = 'DEEP';
      sub.physics.currentDepth = -30.0;

      sub.mounts = [
        createWeaponMount('m_cm', 'cruise_missile_vls', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_air', 'carrier_strike_wing', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_torp', 'torpedo_acoustic_homing', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_dc', 'depth_charge_rack', { x: 0, y: 0 }, 0, Math.PI * 2),
      ];

      // DEEP depth: Cruise missile and Aircraft must be REJECTED
      expect(server.fireMount(sub.id, 0, vec2(500, 500))).toBe(false);
      expect(server.fireMount(sub.id, 1, vec2(500, 500))).toBe(false);

      // DEEP depth: Torpedo and Depth Charge must be PERMITTED
      expect(server.fireMount(sub.id, 2, vec2(500, 500))).toBe(true);
      expect(server.fireMount(sub.id, 3, vec2(500, 500))).toBe(true);
    });
  });

  // ==========================================================================
  // 2. Friendly Fire & Non-Aggression Pact Compliance across Explosions
  // ==========================================================================
  describe('2. Friendly Fire & NAP Compliance across Explosions', () => {
    it('artillery splash explosion does not damage NAP ally or friendly fleetmate', () => {
      const shooter = server.spawnVessel({ position: vec2(0, 0) });
      const ally = server.spawnVessel({ position: vec2(200, 0) });
      const enemy = server.spawnVessel({ position: vec2(205, 0) });

      ally.fleetId = 1;
      shooter.fleetId = 1;
      enemy.fleetId = 2;

      const allyInitialHp = ally.physics.hullHp;
      const enemyInitialHp = enemy.physics.hullHp;

      // Shooter fires 460mm shell at coordinate (200, 0)
      shooter.mounts[0] = createWeaponMount('m_art', 'heavy_gun_460mm', { x: 0, y: 0 }, 0, Math.PI * 2);
      server.fireMount(shooter.id, 0, vec2(200, 0));

      // Advance server until impact: at 780 m/s, 200m takes ~0.26s = 6 ticks of 0.05s
      for (let i = 0; i < 7; i++) server.step(0.05);

      // Ally HP must be unchanged (100% friendly fire immunity)
      expect(ally.physics.hullHp).toBe(allyInitialHp);

      // Enemy within blast radius must take damage
      expect(enemy.physics.hullHp).toBeLessThan(enemyInitialHp);
    });

    it('depth charge hydrostatic shockwave damages enemy submarine but zeroes ally damage', () => {
      const dropper = server.spawnVessel({ position: vec2(0, 0) });
      const allySub = server.spawnVessel({ shipId: 'type_vii_sub', position: vec2(10, 0) });
      const enemySub = server.spawnVessel({ shipId: 'type_vii_sub', position: vec2(15, 0) });

      dropper.fleetId = 5;
      allySub.fleetId = 5;
      enemySub.fleetId = 9;

      allySub.physics.depthState = 'PERISCOPE';
      allySub.physics.currentDepth = -5.0;
      enemySub.physics.depthState = 'PERISCOPE';
      enemySub.physics.currentDepth = -5.0;

      const allyHp = allySub.physics.hullHp;
      const enemyHp = enemySub.physics.hullHp;

      dropper.mounts = [createWeaponMount('m_dc', 'depth_charge_rack', { x: 0, y: 0 }, 0, Math.PI * 2)];
      server.fireMount(dropper.id, 0, vec2(0, 0));

      // Step until depth charge reaches periscope depth (~1.4s at 3.5 m/s = ~30 ticks)
      for (let i = 0; i < 35; i++) server.step(0.05);

      expect(allySub.physics.hullHp).toBe(allyHp);
      expect(enemySub.physics.hullHp).toBeLessThan(enemyHp);
    });

    it('naval mine does not damage friendly fleetmate or NAP partner upon trigger', () => {
      const minelayer = server.spawnVessel({ position: vec2(0, 0) });
      const ally = server.spawnVessel({ position: vec2(5, 0) });
      ally.fleetId = minelayer.fleetId = 42;

      const initialHp = ally.physics.hullHp;

      minelayer.mounts = [createWeaponMount('m_mine', 'naval_mine_layer', { x: 0, y: 0 }, 0, Math.PI * 2)];
      server.fireMount(minelayer.id, 0, vec2(0, 0));

      // Arm mine instantly by advancing past 5.0s arming time
      server.weaponEngine.mines[0].isArmed = true;

      // Ally sails directly over mine
      server.step(0.05);

      // Ally HP must be 100% preserved
      expect(ally.physics.hullHp).toBe(initialHp);
    });

    it('enforces Karma penalty transition precisely at NAP expiration boundary', () => {
      const v1 = server.spawnVessel({ position: vec2(0, 0) });
      const v2 = server.spawnVessel({ position: vec2(50, 0) });
      v1.karma = 100;

      // 1. NAP active (remaining 5.0s) -> 0 damage, 0 karma loss
      server.setFleetNAP(v1.id, v2.id, 5.0);
      expect(server.applyDamage(v1.id, v2.id, 100)).toBe(0);
      expect(v1.karma).toBe(100);

      // 2. Advance 6.0s (NAP expires, enters 30s karma penalty window)
      for (let i = 0; i < 120; i++) server.step(0.05);
      expect(server.canDamage(v1.id, v2.id)).toBe(true);

      const netDamage = server.applyDamage(v1.id, v2.id, 100);
      expect(netDamage).toBeGreaterThan(0);
      expect(v1.karma).toBe(75); // -25 karma penalty applied

      // 3. Advance past 30.0s penalty window (e.g. 35s total elapsed)
      v1.napExpiredTimers.set(v2.id, 35.0);
      server.applyDamage(v1.id, v2.id, 100);
      expect(v1.karma).toBe(75); // No additional karma penalty after window
    });
  });

  // ==========================================================================
  // 3. Automated CIWS Envelope Engagement Limits & Ammo Depletion Handling
  // ==========================================================================
  describe('3. Automated CIWS Envelope Engagement Limits & Ammo Handling', () => {
    it('engages threats inside 800m envelope but ignores threats at 801m boundary', () => {
      const ciwsMount = createWeaponMount('ciws', 'ciws_phalanx_20mm', { x: 0, y: 0 }, 0, Math.PI * 2);
      ciwsMount.maxRange = 800.0;
      const mountWorldPos = vec2(0, 0);

      const threatInside: ThreatTarget = {
        id: 'threat_inside',
        position: vec2(795, 0),
        velocity: vec2(-200, 0),
        altitudeMeters: 20,
        hp: 50,
        isDestroyed: false,
        type: 'CRUISE_MISSILE',
      };

      const threatOutside: ThreatTarget = {
        id: 'threat_outside',
        position: vec2(805, 0),
        velocity: vec2(-200, 0),
        altitudeMeters: 20,
        hp: 50,
        isDestroyed: false,
        type: 'CRUISE_MISSILE',
      };

      // 1. Outside envelope -> should not fire
      const resOutside = stepCIWSEnvelope(ciwsMount, mountWorldPos, 0, [threatOutside], 0.05);
      expect(resOutside.burstFired).toBe(false);
      expect(threatOutside.hp).toBe(50);

      // 2. Inside envelope -> should fire and deal damage
      const resInside = stepCIWSEnvelope(ciwsMount, mountWorldPos, 0, [threatInside], 0.05);
      expect(resInside.burstFired).toBe(true);
      expect(threatInside.hp).toBeLessThan(50);
    });

    it('prevents CIWS from firing when ammo is exhausted and resumes after regeneration', () => {
      const ciwsMount = createWeaponMount('ciws', 'ciws_phalanx_20mm', { x: 0, y: 0 }, 0, Math.PI * 2);
      ciwsMount.ammoCurrent = 1;
      ciwsMount.ammoMax = 100;
      ciwsMount.ammoRegenRate = 10; // 10 rounds/sec
      ciwsMount.reloadTimeTotal = 0.05;

      const threat: ThreatTarget = {
        id: 'target_threat',
        position: vec2(400, 0),
        velocity: vec2(0, 0),
        altitudeMeters: 20,
        hp: 100,
        isDestroyed: false,
        type: 'CRUISE_MISSILE',
      };

      // Burst 1 consumes the only round
      const b1 = stepCIWSEnvelope(ciwsMount, vec2(0, 0), 0, [threat], 0.05);
      expect(b1.burstFired).toBe(true);
      expect(ciwsMount.ammoCurrent).toBeLessThan(1);

      // Burst 2 immediately next tick without regen -> cannot fire
      const b2 = stepCIWSEnvelope(ciwsMount, vec2(0, 0), 0, [threat], 0.001);
      expect(b2.burstFired).toBe(false);

      // Step mount regeneration for 0.2s -> restores 2 rounds
      for (let i = 0; i < 4; i++) {
        stepMountReloadAndRegen(ciwsMount, 0.05);
      }
      expect(ciwsMount.ammoCurrent).toBeGreaterThanOrEqual(1);

      // Burst 3 can now fire
      const b3 = stepCIWSEnvelope(ciwsMount, vec2(0, 0), 0, [threat], 0.05);
      expect(b3.burstFired).toBe(true);
    });

    it('respects mount traverse arc limits and ignores threats in stern blind spot', () => {
      // Forward-facing mount with 240 deg coverage (+/- 120 deg from bow)
      const forwardCIWS = createWeaponMount('fwd_ciws', 'ciws_phalanx_20mm', { x: 0, y: 0 }, 0, degToRad(240));

      const threatInBlindSpot: ThreatTarget = {
        id: 'stern_threat',
        position: vec2(-400, 0), // Directly aft (180 deg)
        velocity: vec2(100, 0),
        altitudeMeters: 20,
        hp: 50,
        isDestroyed: false,
        type: 'CRUISE_MISSILE',
      };

      const res = stepCIWSEnvelope(forwardCIWS, vec2(0, 0), 0, [threatInBlindSpot], 0.1);
      expect(res.burstFired).toBe(false);
      expect(threatInBlindSpot.hp).toBe(50);
    });

    it('prioritizes the closest threat when multiple aerial contacts are present', () => {
      const ciws = createWeaponMount('ciws', 'ciws_phalanx_20mm', { x: 0, y: 0 }, 0, Math.PI * 2);
      const threatNear: ThreatTarget = {
        id: 'threat_near',
        position: vec2(200, 0),
        velocity: vec2(0, 0),
        altitudeMeters: 20,
        hp: 50,
        isDestroyed: false,
        type: 'CRUISE_MISSILE',
      };
      const threatFar: ThreatTarget = {
        id: 'threat_far',
        position: vec2(500, 0),
        velocity: vec2(0, 0),
        altitudeMeters: 20,
        hp: 50,
        isDestroyed: false,
        type: 'CRUISE_MISSILE',
      };

      const res = stepCIWSEnvelope(ciws, vec2(0, 0), 0, [threatFar, threatNear], 0.05);
      expect(res.burstFired).toBe(true);
      expect(threatNear.hp).toBeLessThan(50);
      expect(threatFar.hp).toBe(50); // Far threat unmolested
    });
  });

  // ==========================================================================
  // 4. Torpedo Acoustic Cone Edge Boundaries (+/- 35 deg)
  // ==========================================================================
  describe('4. Torpedo Acoustic Seeker Cone Boundaries (+/- 35 deg)', () => {
    it('locks onto contacts strictly within +/- 35 deg cone and ignores contacts at +/- 36 deg', () => {
      // Create torpedo moving East (heading 0)
      const torp = createTorpedo('torp_test', 'shooter', 'm0', vec2(0, 0), 0, true);
      torp.isArmed = true; // Pre-armed for seeker boundary evaluation

      const dist = 400; // Within 600m seeker range

      // Contact A at +34.5 deg -> inside cone
      const angleInPlus = degToRad(34.5);
      const contactInPlus: AcousticContact = {
        id: 'contact_in_plus',
        position: vec2(Math.cos(angleInPlus) * dist, Math.sin(angleInPlus) * dist),
        velocity: vec2(0, 0),
        isCavitating: false,
        isActiveSonarPinging: false,
        acousticSignatureDb: 100,
      };

      // Contact B at +35.5 deg -> outside cone
      const angleOutPlus = degToRad(35.5);
      const contactOutPlus: AcousticContact = {
        id: 'contact_out_plus',
        position: vec2(Math.cos(angleOutPlus) * dist, Math.sin(angleOutPlus) * dist),
        velocity: vec2(0, 0),
        isCavitating: false,
        isActiveSonarPinging: false,
        acousticSignatureDb: 120, // Even louder than inside contact!
      };

      // 1. Outside contact must be ignored despite being louder
      stepTorpedo(torp, 0.1, [contactOutPlus]);
      expect(torp.targetContactId).toBeUndefined();
      expect(torp.heading).toBe(0); // Kept straight course

      // 2. Inside contact must be captured
      stepTorpedo(torp, 0.1, [contactInPlus]);
      expect(torp.targetContactId).toBe('contact_in_plus');
      expect(torp.heading).toBeGreaterThan(0); // Turned toward positive angle
    });

    it('verifies symmetrical negative boundary (-34.5 deg inside vs -35.5 deg outside)', () => {
      const torp = createTorpedo('torp_test_neg', 'shooter', 'm0', vec2(0, 0), 0, true);
      torp.isArmed = true;

      const dist = 400;

      // Contact at -35.5 deg -> outside cone
      const angleOutNeg = degToRad(-35.5);
      const contactOutNeg: AcousticContact = {
        id: 'contact_out_neg',
        position: vec2(Math.cos(angleOutNeg) * dist, Math.sin(angleOutNeg) * dist),
        velocity: vec2(0, 0),
        isCavitating: false,
        isActiveSonarPinging: false,
        acousticSignatureDb: 110,
      };

      stepTorpedo(torp, 0.1, [contactOutNeg]);
      expect(torp.targetContactId).toBeUndefined();

      // Contact at -34.5 deg -> inside cone
      const angleInNeg = degToRad(-34.5);
      const contactInNeg: AcousticContact = {
        id: 'contact_in_neg',
        position: vec2(Math.cos(angleInNeg) * dist, Math.sin(angleInNeg) * dist),
        velocity: vec2(0, 0),
        isCavitating: false,
        isActiveSonarPinging: false,
        acousticSignatureDb: 95,
      };

      stepTorpedo(torp, 0.1, [contactInNeg]);
      expect(torp.targetContactId).toBe('contact_in_neg');
      expect(torp.heading).toBeLessThan(0); // Turned toward negative angle
    });

    it('decoy only diverts torpedo if decoy lies inside +/- 35 deg cone', () => {
      const torp = createTorpedo('torp_decoy_edge', 'shooter', 'm0', vec2(0, 0), 0, true);
      torp.isArmed = true;

      // Decoy outside cone at +40 deg
      const decoyOut = createTorpedoDecoy('decoy_out', 'deployer', vec2(300, 300 * Math.tan(degToRad(40))), 0);
      stepTorpedo(torp, 0.1, [], [decoyOut]);
      expect(torp.isSpoofedByDecoy).toBe(false);

      // Decoy inside cone at +20 deg
      const decoyIn = createTorpedoDecoy('decoy_in', 'deployer', vec2(300, 300 * Math.tan(degToRad(20))), 0);
      stepTorpedo(torp, 0.1, [], [decoyIn]);
      expect(torp.isSpoofedByDecoy).toBe(true);
      expect(torp.spoofedDecoyId).toBe('decoy_in');
    });

    it('torpedo remains strictly straight during un-armed run (< 300m) and turns only after arming', () => {
      const torp = createTorpedo('torp_arming', 'shooter', 'm0', vec2(0, 0), 0, true);
      expect(torp.isArmed).toBe(false);

      // Place target contact at (600, 50) so it remains ahead of torpedo throughout test
      const contact: AcousticContact = {
        id: 'target_sub',
        position: vec2(600, 50),
        velocity: vec2(0, 0),
        isCavitating: true,
        isActiveSonarPinging: true,
        acousticSignatureDb: 150,
      };

      // Step while distance < 300m (10s * 19.5 m/s = 195m traveled)
      stepTorpedo(torp, 10.0, [contact]);
      expect(torp.distanceTraveled).toBeLessThan(300);
      expect(torp.isArmed).toBe(false);
      expect(torp.heading).toBe(0); // Did not turn!

      // Step past 300m arming threshold (additional 6s = 117m, total 312m)
      stepTorpedo(torp, 6.0, [contact]);
      expect(torp.distanceTraveled).toBeGreaterThanOrEqual(300);
      expect(torp.isArmed).toBe(true);

      // Now with contact ahead at (600, 50) from torpedo at (312, 0), bearing is atan2(50, 288) ~ 9.8 deg (inside +/-35 cone)
      stepTorpedo(torp, 0.5, [contact]);
      expect(torp.targetContactId).toBe('target_sub');
      expect(torp.heading).toBeGreaterThan(0);
    });

    it('guarantees self-homing immunity so launching vessel is never targeted by own torpedo', () => {
      const torp = createTorpedo('torp_self_test', 'shooter_vessel_99', 'm0', vec2(0, 0), 0, true);
      torp.isArmed = true;

      // Contact representing the shooter itself right ahead within cone
      const shooterSelfContact: AcousticContact = {
        id: 'shooter_vessel_99',
        position: vec2(200, 10),
        velocity: vec2(0, 0),
        isCavitating: true,
        isActiveSonarPinging: true,
        acousticSignatureDb: 180, // Extremely loud noise!
      };

      stepTorpedo(torp, 0.5, [shooterSelfContact]);
      expect(torp.targetContactId).toBeUndefined();
      expect(torp.heading).toBe(0); // Unaltered
    });

    it('ranks contacts inside seeker cone by Net Acoustic Score = (dB - distance/10)', () => {
      const torp = createTorpedo('torp_score_test', 'shooter', 'm0', vec2(0, 0), 0, true);
      torp.isArmed = true;

      // Contact Near: 100m, 90 dB -> score = 90 - 10 = 80 dB
      const contactNear: AcousticContact = {
        id: 'contact_near',
        position: vec2(100, 10),
        velocity: vec2(0, 0),
        isCavitating: false,
        isActiveSonarPinging: false,
        acousticSignatureDb: 90,
      };

      // Contact Far: 400m, 140 dB -> score = 140 - 40 = 100 dB (higher net score!)
      const contactFar: AcousticContact = {
        id: 'contact_far',
        position: vec2(400, 20),
        velocity: vec2(0, 0),
        isCavitating: true,
        isActiveSonarPinging: true,
        acousticSignatureDb: 140,
      };

      stepTorpedo(torp, 0.2, [contactNear, contactFar]);
      expect(torp.targetContactId).toBe('contact_far'); // Picked higher score target
    });
  });

  // ==========================================================================
  // 5. Game Loop Invariants & Extended Stability Stress
  // ==========================================================================
  describe('5. Game Loop Invariants & Stability Stress', () => {
    it('handles target vessel despawning mid-flight without throwing null references', () => {
      const shooter = server.spawnVessel({ position: vec2(0, 0) });
      const victim = server.spawnVessel({ position: vec2(600, 0) });
      const victimId = victim.id;

      // Shooter fires artillery shell and cruise missile
      shooter.mounts[0] = createWeaponMount('m_art', 'heavy_gun_460mm', { x: 0, y: 0 }, 0, Math.PI * 2);
      shooter.mounts[1] = createWeaponMount('m_cm', 'cruise_missile_vls', { x: 0, y: 0 }, 0, Math.PI * 2);

      server.fireMount(shooter.id, 0, vec2(600, 0));
      server.fireMount(shooter.id, 1, vec2(600, 0));

      expect(server.weaponEngine.shells.length).toBe(1);
      expect(server.weaponEngine.cruiseMissiles.length).toBe(1);

      // Despawn victim while projectiles are in flight
      server.despawnVessel(victimId);
      expect(server.getVessel(victimId)).toBeUndefined();

      // Step game server until projectiles hit coordinates
      expect(() => {
        for (let i = 0; i < 40; i++) {
          server.step(0.1);
        }
      }).not.toThrow();
    });

    it('maintains continuous loop stability for 100 ticks with saturated multi-vessel combat', () => {
      const v1 = server.spawnVessel({ position: vec2(0, 0), heading: 0 });
      const v2 = server.spawnVessel({ position: vec2(300, 200), heading: Math.PI });
      const v3 = server.spawnVessel({ position: vec2(-200, 300), heading: Math.PI / 2 });

      v1.fleetId = 1;
      v2.fleetId = 2;
      v3.fleetId = 3;

      for (let tick = 0; tick < 100; tick++) {
        // Fire bursts periodically
        if (tick % 10 === 0) {
          server.fireMount(v1.id, 0, v2.physics.position);
          server.fireMount(v2.id, 0, v1.physics.position);
          server.fireMount(v3.id, 0, v1.physics.position);
        }
        server.step(0.05);

        // Snapshot packet generation check
        const snapshot = server.createSnapshotPacket(tick);
        expect(snapshot.vessels.length).toBe(3);
      }

      // Assert health states remain finite and within bounds
      for (const v of [v1, v2, v3]) {
        expect(Number.isFinite(v.physics.hullHp)).toBe(true);
        expect(v.physics.hullHp).toBeGreaterThanOrEqual(0);
        expect(v.physics.hullHp).toBeLessThanOrEqual(v.shipDef.maxHp);
      }
    });

    it('assembles getAllProjectiles without property corruption across 8 active projectile types', () => {
      const v = server.spawnVessel({ position: vec2(0, 0) });
      v.mounts = [
        createWeaponMount('m_art', 'heavy_gun_460mm', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_torp', 'torpedo_acoustic_homing', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_cm', 'cruise_missile_vls', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_rock', 'rocket_barrage_rbu', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_asroc', 'rocket_torpedo_asroc', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_dc', 'depth_charge_rack', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_mine', 'naval_mine_layer', { x: 0, y: 0 }, 0, Math.PI * 2),
        createWeaponMount('m_sam', 'sam_interceptor', { x: 0, y: 0 }, 0, Math.PI * 2),
      ];

      for (let i = 0; i < 8; i++) {
        server.fireMount(v.id, i, vec2(300, 300));
      }

      const allProj = server.getAllProjectiles();
      expect(allProj.length).toBeGreaterThanOrEqual(8);

      for (const p of allProj) {
        expect(Number.isFinite(p.id)).toBe(true);
        expect(Number.isFinite(p.position.x)).toBe(true);
        expect(Number.isFinite(p.position.y)).toBe(true);
        expect(Number.isFinite(p.damage)).toBe(true);
        expect(p.damage).toBeGreaterThan(0);
        expect(p.category).toBeDefined();
      }
    });
  });
});
