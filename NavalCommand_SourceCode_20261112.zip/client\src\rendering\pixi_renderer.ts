/**
 * PixiJS v8 Application Renderer & Camera Viewport
 * Clean-Room implementation for NavalCommand.io
 * Coordinates ocean background, terrain layers, vector vessels, wakes, and sensor overlays.
 */

import { Application, Container, Graphics } from 'pixi.js';
import { WakeFX } from './wake_fx.js';
import { VectorParticleSystem } from './particle_system.js';
import { SensorOverlays } from './sensor_overlays.js';
import { ProceduralVessel } from './vector_hulls.js';

export class PixiRenderer {
  public app: Application | null = null;
  public readonly worldContainer: Container;

  // Scene layer hierarchy
  public readonly oceanLayer: Container;
  public readonly terrainLayer: Container;
  public readonly wakeLayer: Container;
  public readonly submergedLayer: Container;
  public readonly surfaceLayer: Container;
  public readonly projectilesLayer: Container;
  public readonly particleLayer: Container;
  public readonly sensorLayer: Container;
  public readonly worldUILayer: Container;

  // Subsystems
  public readonly wakeFX: WakeFX;
  public readonly particles: VectorParticleSystem;
  public readonly sensorOverlays: SensorOverlays;

  // Procedural background
  private oceanGridGraphics: Graphics;
  private projectileGraphics: Graphics;

  // Camera state
  public cameraX: number = 0;
  public cameraY: number = 0;
  public zoom: number = 1.0;
  public minZoom: number = 0.3;
  public maxZoom: number = 2.5;

  private isInitialized: boolean = false;

  constructor() {
    this.worldContainer = new Container();

    this.oceanLayer = new Container();
    this.terrainLayer = new Container();
    this.wakeLayer = new Container();
    this.submergedLayer = new Container();
    this.surfaceLayer = new Container();
    this.projectilesLayer = new Container();
    this.particleLayer = new Container();
    this.sensorLayer = new Container();
    this.worldUILayer = new Container();

    this.wakeFX = new WakeFX();
    this.particles = new VectorParticleSystem();
    this.sensorOverlays = new SensorOverlays();

    this.oceanGridGraphics = new Graphics();
    this.projectileGraphics = new Graphics();

    this.wakeLayer.addChild(this.wakeFX.container);
    this.particleLayer.addChild(this.particles.container);
    this.sensorLayer.addChild(this.sensorOverlays.container);
    this.projectilesLayer.addChild(this.projectileGraphics);
    this.oceanLayer.addChild(this.oceanGridGraphics);

    this.worldContainer.addChild(this.oceanLayer);
    this.worldContainer.addChild(this.terrainLayer);
    this.worldContainer.addChild(this.wakeLayer);
    this.worldContainer.addChild(this.submergedLayer);
    this.worldContainer.addChild(this.surfaceLayer);
    this.worldContainer.addChild(this.projectilesLayer);
    this.worldContainer.addChild(this.particleLayer);
    this.worldContainer.addChild(this.sensorLayer);
    this.worldContainer.addChild(this.worldUILayer);
  }

  /**
   * Initialize PixiJS v8 Application onto parent container / canvas.
   */
  public async init(parentElement: HTMLElement): Promise<void> {
    if (this.isInitialized) return;

    this.app = new Application();
    await this.app.init({
      resizeTo: parentElement,
      backgroundColor: 0x091422, // Deep tactical maritime navy
      antialias: true,
      autoDensity: true,
      resolution: window.devicePixelRatio || 1,
    });

    parentElement.appendChild(this.app.canvas);
    this.app.stage.addChild(this.worldContainer);

    this.drawOceanGrid();
    this.isInitialized = true;
  }

  public drawOceanGrid(): void {
    const g = this.oceanGridGraphics;
    g.clear();

    const mapSize = 6000;
    const half = mapSize * 0.5;
    const step = 200;

    // Tactical coordinate grid lines
    for (let x = -half; x <= half; x += step) {
      g.moveTo(x, -half);
      g.lineTo(x, half);
      g.stroke({
        color: 0x142b44,
        width: 1,
        alpha: 0.35,
      });
    }

    for (let y = -half; y <= half; y += step) {
      g.moveTo(-half, y);
      g.lineTo(half, y);
      g.stroke({
        color: 0x142b44,
        width: 1,
        alpha: 0.35,
      });
    }

    // World boundary outline
    g.rect(-half, -half, mapSize, mapSize);
    g.stroke({
      color: 0x00e676,
      width: 2,
      alpha: 0.5,
    });
  }

  /**
   * Center camera smoothly on target world coordinates.
   */
  public setCameraPosition(x: number, y: number, smoothLerp: number = 1.0): void {
    if (smoothLerp >= 1.0) {
      this.cameraX = x;
      this.cameraY = y;
    } else {
      this.cameraX += (x - this.cameraX) * smoothLerp;
      this.cameraY += (y - this.cameraY) * smoothLerp;
    }

    this.updateViewportTransform();
  }

  public setZoom(targetZoom: number): void {
    this.zoom = Math.max(this.minZoom, Math.min(this.maxZoom, targetZoom));
    this.updateViewportTransform();
  }

  public zoomBy(deltaFactor: number): void {
    this.setZoom(this.zoom * deltaFactor);
  }

  private updateViewportTransform(): void {
    if (!this.app) return;

    const screenWidth = this.app.screen.width;
    const screenHeight = this.app.screen.height;

    this.worldContainer.scale.set(this.zoom);
    this.worldContainer.position.set(
      screenWidth * 0.5 - this.cameraX * this.zoom,
      screenHeight * 0.5 - this.cameraY * this.zoom
    );
  }

  public screenToWorld(screenX: number, screenY: number): { x: number; y: number } {
    if (!this.app) return { x: screenX, y: screenY };
    const screenWidth = this.app.screen.width;
    const screenHeight = this.app.screen.height;

    const worldX = (screenX - screenWidth * 0.5) / this.zoom + this.cameraX;
    const worldY = (screenY - screenHeight * 0.5) / this.zoom + this.cameraY;
    return { x: worldX, y: worldY };
  }

  public worldToScreen(worldX: number, worldY: number): { x: number; y: number } {
    if (!this.app) return { x: worldX, y: worldY };
    const screenWidth = this.app.screen.width;
    const screenHeight = this.app.screen.height;

    const screenX = (worldX - this.cameraX) * this.zoom + screenWidth * 0.5;
    const screenY = (worldY - this.cameraY) * this.zoom + screenHeight * 0.5;
    return { x: screenX, y: screenY };
  }

  /**
   * Draw projectiles (torpedoes, shells, missiles) as vector shapes.
   */
  public renderProjectiles(
    projectiles: Array<{
      x: number;
      y: number;
      heading: number;
      type: 'SHELL' | 'TORPEDO' | 'MISSILE' | 'MINE' | 'DEPTH_CHARGE';
    }>
  ): void {
    const g = this.projectileGraphics;
    g.clear();

    for (const p of projectiles) {
      if (p.type === 'TORPEDO') {
        // Torpedo: elongated green/cyan cylinder with propeller wake
        const len = 10;
        const width = 2.5;
        const cos = Math.cos(p.heading);
        const sin = Math.sin(p.heading);

        g.circle(p.x, p.y, width * 0.8);
        g.fill({ color: 0x00e5ff });

        g.moveTo(p.x - cos * len, p.y - sin * len);
        g.lineTo(p.x + cos * len * 0.5, p.y + sin * len * 0.5);
        g.stroke({ color: 0x00e5ff, width });
      } else if (p.type === 'MISSILE') {
        // Missile: fast needle with orange thrust flame
        const len = 12;
        const cos = Math.cos(p.heading);
        const sin = Math.sin(p.heading);

        g.moveTo(p.x - cos * len, p.y - sin * len);
        g.lineTo(p.x + cos * len, p.y + sin * len);
        g.stroke({ color: 0xffffff, width: 2.5 });

        // Rocket plume
        g.circle(p.x - cos * len, p.y - sin * len, 3);
        g.fill({ color: 0xff9100 });
      } else if (p.type === 'MINE') {
        // Sea mine: spiky circular contact mine
        g.circle(p.x, p.y, 4);
        g.fill({ color: 0x222222 });
        g.stroke({ color: 0xff1744, width: 1.5 });
      } else {
        // Standard naval artillery shell: glowing tracer dot
        g.circle(p.x, p.y, 2.5);
        g.fill({ color: 0xffea00 });
      }
    }
  }

  public update(dt: number): void {
    this.wakeFX.update(dt);
    this.particles.update(dt);
  }

  public destroy(): void {
    if (this.app) {
      this.app.destroy(true, { children: true });
      this.app = null;
      this.isInitialized = false;
    }
  }
}
