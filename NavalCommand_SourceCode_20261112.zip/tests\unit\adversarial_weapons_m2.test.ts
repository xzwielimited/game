/**
 * Empirical Adversarial Verification Suite: Milestone M2
 * Weapons Kinematics Integration, Ballistic Solvers & Authoritative Server Stress Tests
 *
 * Authored by Teamwork Empirical Challenger (Critic & Specialist)
 */

import { describe, it, expect, beforeEach } from 'vitest';
import {
  Vector2D,
  vec2,
  vec2Distance,
  vec2Normalize,
  vec2Scale,
  degToRad,
  radToDeg,
  normalizeAngle,
  shortestAngleDiff,
  SHIP_ROSTER,
  ShipDef,
  WeaponMountDef,
  WeaponCategory,
  WEAPON_DEFINITIONS,
  createWeaponMount,
  canMountFire,
  fireMount,
  stepMountReloadAndRegen,
  stepMountTraverse,
  isAngleWithinMountArc,
  calculateDispersionEllipse,
  calculateDispersionOffset,
  calculateBallisticFlightTime,
  calculateShellAltitude,
  calculatePlungeAngleRad,
  calculateShellImpactPosition,
  createArtilleryShell,
  stepArtilleryShell,
  createTorpedo,
  createTorpedoDecoy,
  stepTorpedo,
  stepTorpedoDecoy,
  createCruiseMissile,
  stepCruiseMissile,
  createRocket,
  stepRocket,
  createRocketTorpedo,
  stepRocketTorpedo,
  stepCIWSEnvelope,
  launchSAMInterceptor,
  stepSAMInterceptor,
  createDepthCharge,
  calculateDepthChargeDamage,
  stepDepthCharge,
  createNavalMine,
  stepNavalMine,
  createAircraftSquadron,
  stepAircraft,
  deploySonarBuoy,
  stepSonarBuoy,
  executeDredgerAction,
  WeaponKinematicsEngine,
  WeaponKinematicsWorldContext,
  TerrainEngine,
  SubmarineContact,
  SurfaceVesselContact,
  AcousticContact,
  ThreatTarget,
  GameEventType,
} from '../../common/index.js';
import { commandDepthState, updateHydrodynamics } from '../../common/simulation/hydrodynamics.js';
import { AuthoritativeGameServer, ServerVessel } from '../../server/core/game_server.js';

describe('Adversarial Verification Suite: Milestone M2 (Weapons & Ballistics Stress)', () => {
  let server: AuthoritativeGameServer;

  beforeEach(() => {
    server = new AuthoritativeGameServer(20);
  });

  // =========================================================================
  // 1. HIGH PROJECTILE VOLUME & MULTI-ENTITY SALVO STRESS HARNESS
  // =========================================================================
  describe('1. High Projectile Volume & Multi-Entity Salvo Stress Harness', () => {
    it('simulates 20 vessels simultaneously firing salvos across all weapon categories without degradation', () => {
      const vessels: ServerVessel[] = [];
      const numVessels = 20;

      // Spawn 20 vessels in a circle of radius 1500m
      for (let i = 0; i < numVessels; i++) {
        const angle = (i / numVessels) * 2 * Math.PI;
        const posX = Math.cos(angle) * 1500;
        const posY = Math.sin(angle) * 1500;
        const shipId = i % 4 === 0 ? 'yasen_ssn' : i % 4 === 1 ? 'fletcher_dd' : i % 4 === 2 ? 'carrier_nimitz' : 'burke_ddg';
        const v = server.spawnVessel({
          shipId,
          position: vec2(posX, posY),
          heading: angle + Math.PI, // Facing center
        });
        vessels.push(v);
      }

      expect(server.getAllVessels().length).toBe(20);

      // Fire 5 salvos with a few ticks between them
      let totalFiredArtillery = 0;
      let totalFiredTorpedoes = 0;
      let totalFiredMissiles = 0;
      let totalFiredRockets = 0;
      let totalFiredDepthCharges = 0;
      let totalFiredMines = 0;

      for (let salvo = 0; salvo < 5; salvo++) {
        for (const v of vessels) {
          // Reset mount reload timers so they can fire immediately
          for (const m of v.mounts) {
            m.reloadTimeRemaining = 0;
            m.ammoCurrent = m.ammoMax;
          }

          // Artillery
          const artIdx = v.mounts.findIndex(m => m.category === 'ARTILLERY');
          if (artIdx >= 0) {
            if (server.fireMount(v.id, artIdx, vec2(0, 0))) totalFiredArtillery++;
          }

          // Torpedo
          const torpIdx = v.mounts.findIndex(m => m.category === 'TORPEDO');
          if (torpIdx >= 0) {
            if (server.fireMount(v.id, torpIdx, vec2(0, 0))) totalFiredTorpedoes++;
          }

          // Cruise Missile
          const cmIdx = v.mounts.findIndex(m => m.category === 'CRUISE_MISSILE');
          if (cmIdx >= 0) {
            if (server.fireMount(v.id, cmIdx, vec2(0, 0))) totalFiredMissiles++;
          }

          // Rocket Barrage
          const rockIdx = v.mounts.findIndex(m => m.category === 'ROCKET_BARRAGE');
          if (rockIdx >= 0) {
            if (server.fireMount(v.id, rockIdx, vec2(0, 0))) totalFiredRockets += 12;
          }

          // Depth charge
          const dcIdx = v.mounts.findIndex(m => m.category === 'DEPTH_CHARGE');
          if (dcIdx >= 0) {
            if (server.fireMount(v.id, dcIdx, vec2(0, 0))) totalFiredDepthCharges++;
          }

          // Naval mine
          const mineIdx = v.mounts.findIndex(m => m.category === 'NAVAL_MINE');
          if (mineIdx >= 0) {
            if (server.fireMount(v.id, mineIdx, vec2(0, 0))) totalFiredMines++;
          }
        }

        // Step simulation 5 ticks per salvo
        for (let t = 0; t < 5; t++) {
          server.step(0.05);
        }
      }

      // Assert high volume was injected
      const allProjectiles = server.getAllProjectiles();
      expect(allProjectiles.length).toBeGreaterThan(50);

      // Run 150 more ticks to advance and resolve all in-flight projectiles
      for (let t = 0; t < 150; t++) {
        server.step(0.05);
      }

      // Assert numerical sanity across all remaining vessels
      for (const v of server.getAllVessels()) {
        expect(Number.isFinite(v.physics.position.x)).toBe(true);
        expect(Number.isFinite(v.physics.position.y)).toBe(true);
        expect(Number.isFinite(v.physics.speedKnots)).toBe(true);
        expect(Number.isFinite(v.physics.hullHp)).toBe(true);
        expect(v.physics.hullHp).toBeGreaterThanOrEqual(0);
      }

      // Expired shells and rockets should be cleaned up
      expect(server.weaponEngine.shells.every(s => !s.isDetonated)).toBe(true);
      expect(server.weaponEngine.rockets.every(r => !r.isDetonated)).toBe(true);
    });

    it('benchmarks projectile engine cleanup under continuous 500-entity saturation', () => {
      const engine = new WeaponKinematicsEngine();
      const mount = createWeaponMount('mount1', 'autocannon_20mm', { x: 0, y: 0 }, 0, Math.PI * 2);

      // Create 500 shells with randomized short flight times
      for (let i = 0; i < 500; i++) {
        mount.reloadTimeRemaining = 0;
        mount.ammoCurrent = 100;
        const target = vec2(50 + (i % 20) * 10, 50 + Math.floor(i / 20) * 10);
        engine.fireArtilleryMount('shooter_1', mount, vec2(0, 0), target);
      }

      expect(engine.shells.length).toBe(500);

      // Step by 0.5s intervals; after 3s all shells must be detonated and removed
      for (let step = 0; step < 6; step++) {
        engine.step(0.5);
      }

      expect(engine.shells.length).toBe(0);
    });
  });

  // =========================================================================
  // 2. EXTREME COORDINATES, HIGH SPEEDS & TIMESTEP (dt) EDGE CASES
  // =========================================================================
  describe('2. Extreme Coordinates, High Speeds & Timestep (dt) Edge Cases', () => {
    it('handles dt = 0 without state corruption or NaN in any weapon category', () => {
      const origin = vec2(100, 100);
      const target = vec2(500, 500);
      const def = WEAPON_DEFINITIONS['autocannon_20mm'];

      const shell = createArtilleryShell('s0', 'v1', 'm0', origin, target, def);
      const torp = createTorpedo('t0', 'v1', 'm0', origin, 0, false);
      const cm = createCruiseMissile('cm0', 'v1', 'm0', origin, 0, target);
      const rock = createRocket('r0', 'v1', 'm0', origin, target);
      const dc = createDepthCharge('dc0', 'v1', 'm0', origin, 'PERISCOPE');
      const mine = createNavalMine('m0', 'v1', 'm0', origin);
      const air = createAircraftSquadron('a0', 'v1', 'STRIKE_FIGHTER', origin, target);
      const buoy = deploySonarBuoy('b0', 'v1', origin);

      // Step all with dt = 0
      stepArtilleryShell(shell, 0);
      stepTorpedo(torp, 0);
      stepCruiseMissile(cm, 0);
      stepRocket(rock, 0);
      stepDepthCharge(dc, 0);
      stepNavalMine(mine, 0);
      stepAircraft(air, 0);
      stepSonarBuoy(buoy, 0);

      expect(Number.isFinite(shell.currentPos.x)).toBe(true);
      expect(Number.isFinite(shell.altitude)).toBe(true);
      expect(Number.isFinite(torp.position.x)).toBe(true);
      expect(Number.isFinite(cm.position.x)).toBe(true);
      expect(Number.isFinite(rock.currentPos.x)).toBe(true);
      expect(Number.isFinite(dc.currentDepth)).toBe(true);
      expect(Number.isFinite(air.position.x)).toBe(true);
      expect(buoy.durationRemaining).toBe(75.0);
    });

    it('safely handles point-blank firing with origin == targetPos (zero distance)', () => {
      const pos = vec2(2500, -3500);
      const def = WEAPON_DEFINITIONS['heavy_gun_460mm'];

      // Artillery point blank
      const shell = createArtilleryShell('s_pb', 'v1', 'm0', pos, pos, def);
      expect(shell.flightTimeTotal).toBe(0);
      expect(Number.isFinite(shell.plungeAngleRad)).toBe(true);

      const resShell = stepArtilleryShell(shell, 0.05);
      expect(resShell.detonated).toBe(true);
      expect(shell.currentPos.x).toBe(pos.x);
      expect(shell.currentPos.y).toBe(pos.y);

      // Rocket point blank
      const rock = createRocket('r_pb', 'v1', 'm0', pos, pos);
      expect(rock.flightTimeTotal).toBe(0);
      const resRock = stepRocket(rock, 0.05);
      expect(resRock.detonated).toBe(true);
      expect(rock.currentPos.x).toBe(pos.x);
      expect(rock.currentPos.y).toBe(pos.y);

      // ASROC point blank
      const asroc = createRocketTorpedo('asroc_pb', 'v1', 'm0', pos, pos);
      expect(asroc.airFlightDuration).toBe(0);
      const resAsroc = stepRocketTorpedo(asroc, 0.05);
      expect(resAsroc.transitionedToWater).toBe(true);
    });

    it('handles extreme coordinates (+/- 10,000,000 meters) without arithmetic overflow', () => {
      const farOrigin = vec2(1e7, 1e7);
      const farTarget = vec2(1e7 + 2000, 1e7 + 2000);
      const def = WEAPON_DEFINITIONS['autocannon_20mm'];

      const shell = createArtilleryShell('s_far', 'v1', 'm0', farOrigin, farTarget, def);
      expect(Number.isFinite(shell.flightTimeTotal)).toBe(true);
      expect(shell.targetPos.x).toBeCloseTo(farTarget.x, 0);

      stepArtilleryShell(shell, 0.5);
      expect(Number.isFinite(shell.currentPos.x)).toBe(true);
      expect(Number.isFinite(shell.altitude)).toBe(true);

      // Extreme negative coordinates
      const negOrigin = vec2(-1e7, -1e7);
      const negTarget = vec2(-1e7 - 1000, -1e7 - 1000);
      const torp = createTorpedo('t_neg', 'v1', 'm0', negOrigin, Math.PI, false);

      stepTorpedo(torp, 1.0);
      expect(Number.isFinite(torp.position.x)).toBe(true);
      expect(torp.position.x).toBeLessThan(negOrigin.x);
    });

    it('handles large dt steps (dt = 100s) cleanly detonating or dudding in-flight entities', () => {
      const shell = createArtilleryShell('s_dt100', 'v1', 'm0', vec2(0, 0), vec2(1000, 0), WEAPON_DEFINITIONS['autocannon_20mm']);
      const resShell = stepArtilleryShell(shell, 100.0);
      expect(resShell.detonated).toBe(true);
      expect(shell.currentPos.x).toBe(1000);
      expect(shell.altitude).toBe(0);

      const torp = createTorpedo('t_dt100', 'v1', 'm0', vec2(0, 0), 0, false);
      const resTorp = stepTorpedo(torp, 110.0);
      expect(resTorp.isDud).toBe(true);
      expect(torp.isDud).toBe(true);

      const cm = createCruiseMissile('cm_dt100', 'v1', 'm0', vec2(0, 0), 0, vec2(1500, 0));
      const resCm = stepCruiseMissile(cm, 100.0);
      expect(resCm.detonated).toBe(true);
      expect(cm.isDetonated).toBe(true);
    });
  });

  // =========================================================================
  // 3. SUBMARINE DEPTH STATE TRANSITIONS & CRUISE MISSILE GUIDANCE DYNAMICS
  // =========================================================================
  describe('3. Submarine Depth State Transitions & Cruise Missile Guidance Dynamics', () => {
    it('maintains guidance while launcher transitions, but severs upon reaching DEEP depth (< -5.0m)', () => {
      const sub = server.spawnVessel({
        shipId: 'yasen_ssn',
        position: vec2(0, 0),
        heading: 0,
      });

      // Submarine starts at PERISCOPE depth (-5.0m)
      sub.physics.depthState = 'PERISCOPE';
      sub.physics.currentDepth = -5.0;

      // Fire cruise missile toward moving target
      const targetPos = vec2(3500, 800);
      const missileMountIdx = sub.mounts.findIndex(m => m.category === 'CRUISE_MISSILE');
      expect(missileMountIdx).toBeGreaterThanOrEqual(0);

      const fired = server.fireMount(sub.id, missileMountIdx, targetPos);
      expect(fired).toBe(true);

      const missile = server.weaponEngine.cruiseMissiles[0];
      expect(missile).toBeDefined();
      expect(missile.guidanceActive).toBe(true);
      expect(missile.guidanceAborted).toBe(false);

      // Submarine initiates dive to DEEP
      commandDepthState(sub.shipDef, sub.physics, 'DEEP');
      expect(sub.physics.targetDepthState).toBe('DEEP');
      expect(sub.physics.depthTransitionTimer).toBe(5.0);

      // Step server 2.0s: transition is ongoing (timer = 3.0s), still at periscope depth
      for (let t = 0; t < 40; t++) {
        server.step(0.05);
      }
      expect(sub.physics.depthTransitionTimer).toBeCloseTo(3.0, 1);
      expect(missile.guidanceActive).toBe(true);
      expect(missile.guidanceAborted).toBe(false);

      // Step remaining 3.1s to complete the dive transition
      for (let t = 0; t < 62; t++) {
        server.step(0.05);
      }

      // Transition complete: submarine reached DEEP (-30.0m)
      expect(sub.physics.depthState).toBe('DEEP');
      expect(sub.physics.currentDepth).toBe(-30.0);

      // Cruise missile datalink severed!
      expect(missile.guidanceActive).toBe(false);
      expect(missile.guidanceAborted).toBe(true);
    });

    it('severed cruise missile continues in dumb unguided line when target coordinates maneuver', () => {
      const missile = createCruiseMissile(
        'cm_test_dumb',
        'sub_yasen',
        'vls_0',
        vec2(1000, 0),
        0, // Heading East
        vec2(4000, 0),
        true,
        -5.0
      );

      // Abort guidance by stepping with sub at -30m
      stepCruiseMissile(missile, 0.1, -30.0);
      expect(missile.guidanceAborted).toBe(true);

      const headingBeforeTargetManeuver = missile.heading;

      // Target shifts drastically to (4000, 3000) (bearing ~ +45 deg)
      const newTargetCoords = vec2(4000, 3000);
      stepCruiseMissile(missile, 1.0, -30.0, newTargetCoords);

      // Heading must remain completely unchanged (dumb unguided flight)
      expect(missile.heading).toBe(headingBeforeTargetManeuver);
    });

    it('does not restore severed missile guidance if submarine subsequently surfaces back to PERISCOPE', () => {
      const missile = createCruiseMissile(
        'cm_no_restore',
        'sub_yasen',
        'vls_0',
        vec2(1000, 0),
        0,
        vec2(4000, 0),
        true,
        -5.0
      );

      // Step with sub at -30m -> aborts guidance
      stepCruiseMissile(missile, 0.1, -30.0);
      expect(missile.guidanceAborted).toBe(true);

      // Submarine surfaces back to 0.0m (SURFACE)
      stepCruiseMissile(missile, 0.1, 0.0);
      expect(missile.guidanceAborted).toBe(true);
      expect(missile.guidanceActive).toBe(false);

      // Submarine at PERISCOPE depth (-5.0m)
      stepCruiseMissile(missile, 0.1, -5.0);
      expect(missile.guidanceAborted).toBe(true);
      expect(missile.guidanceActive).toBe(false);
    });

    it('prevents submerged submarines at DEEP depth from launching aircraft or cruise missiles', () => {
      const sub = server.spawnVessel({
        shipId: 'yasen_ssn',
        position: vec2(0, 0),
        heading: 0,
      });

      sub.physics.depthState = 'DEEP';
      sub.physics.currentDepth = -30.0;

      const missileIdx = sub.mounts.findIndex(m => m.category === 'CRUISE_MISSILE');
      expect(missileIdx).toBeGreaterThanOrEqual(0);

      const firedMissile = server.fireMount(sub.id, missileIdx, vec2(1000, 0));
      expect(firedMissile).toBe(false);
      expect(server.weaponEngine.cruiseMissiles.length).toBe(0);
    });

    it('grants submarines at DEEP depth complete immunity against surface artillery and unguided rockets', () => {
      const surfaceAttacker = server.spawnVessel({
        shipId: 'fletcher_dd',
        position: vec2(0, 0),
        heading: 0,
      });

      const deepSub = server.spawnVessel({
        shipId: 'yasen_ssn',
        position: vec2(500, 0),
        heading: 0,
      });
      deepSub.physics.depthState = 'DEEP';
      deepSub.physics.currentDepth = -30.0;
      const initialHp = deepSub.physics.hullHp;

      // 1. Fire artillery shell directly onto submarine coordinates
      const artMountIdx = surfaceAttacker.mounts.findIndex(m => m.category === 'ARTILLERY');
      server.fireMount(surfaceAttacker.id, artMountIdx, vec2(500, 0));
      const shell = server.weaponEngine.shells[0];

      // Fast-forward shell
      shell.timeElapsed = shell.flightTimeTotal - 0.05;
      server.step(0.1);

      // Submarine took 0 damage
      expect(deepSub.physics.hullHp).toBe(initialHp);

      // 2. Fire unguided rocket barrage directly onto submarine coordinates
      surfaceAttacker.mounts[0].reloadTimeRemaining = 0;
      surfaceAttacker.mounts[0].ammoCurrent = 10;
      const rocket = server.weaponEngine.fireRocketBarrageMount(
        String(surfaceAttacker.id),
        surfaceAttacker.mounts[0],
        vec2(0, 0),
        vec2(500, 0),
        1
      )[0];
      rocket.timeElapsed = rocket.flightTimeTotal - 0.05;
      server.step(0.1);

      // Submarine still took 0 damage
      expect(deepSub.physics.hullHp).toBe(initialHp);
    });
  });

  // =========================================================================
  // 4. ACOUSTIC DECOY CAPTURE & COUNTERMEASURE DYNAMICS
  // =========================================================================
  describe('4. Acoustic Decoy Capture & Countermeasure Dynamics', () => {
    it('acoustic torpedo locks on decoy within +/-35 deg cone and 500m attraction radius over ship contact', () => {
      const torp = createTorpedo('t_spoof', 'shooter_1', 'm0', vec2(0, 0), 0, true);
      torp.isArmed = true;
      torp.distanceTraveled = 350; // Armed

      // Target ship straight ahead at (600, 0)
      const shipContact: AcousticContact = {
        id: 'target_ship',
        position: vec2(600, 0),
        velocity: vec2(0, 0),
        isCavitating: true,
        isActiveSonarPinging: false,
        acousticSignatureDb: 110.0,
      };

      // Decoy placed at (400, 50) - bearing ~ 7.1 deg, well inside 35 deg cone
      const decoy = createTorpedoDecoy('decoy_alpha', 'target_ship', vec2(400, 50), 0);

      stepTorpedo(torp, 0.5, [shipContact], [decoy]);

      expect(torp.isSpoofedByDecoy).toBe(true);
      expect(torp.spoofedDecoyId).toBe('decoy_alpha');
      expect(torp.heading).toBeGreaterThan(0); // Turning toward decoy in +Y
    });

    it('ignores acoustic decoy located outside +/- 35 deg seeker cone and tracks vessel instead', () => {
      const torp = createTorpedo('t_cone_test', 'shooter_1', 'm0', vec2(0, 0), 0, true);
      torp.isArmed = true;
      torp.distanceTraveled = 350;

      // Target ship at (500, 20) - bearing ~ 2.3 deg (inside cone)
      const shipContact: AcousticContact = {
        id: 'target_ship',
        position: vec2(500, 20),
        velocity: vec2(0, 0),
        isCavitating: true,
        isActiveSonarPinging: false,
        acousticSignatureDb: 100.0,
      };

      // Decoy placed at (300, 300) - bearing ~ 45 deg (> 35 deg cone limit!)
      const offAxisDecoy = createTorpedoDecoy('decoy_off_axis', 'target_ship', vec2(300, 300), 0);

      stepTorpedo(torp, 0.5, [shipContact], [offAxisDecoy]);

      // Torpedo must NOT be spoofed by off-axis decoy
      expect(torp.isSpoofedByDecoy).toBe(false);
      expect(torp.targetContactId).toBe('target_ship');
    });

    it('detonates and neutralizes acoustic torpedo upon closing to within 12m of decoy', () => {
      const torp = createTorpedo('t_impact_decoy', 'shooter_1', 'm0', vec2(390, 50), 0, true);
      torp.isArmed = true;
      torp.distanceTraveled = 390;

      const decoy = createTorpedoDecoy('decoy_target', 'victim_1', vec2(400, 50), 0);

      // Torpedo at (390, 50) is 10m away from decoy at (400, 50) <= 12m trigger
      const res = stepTorpedo(torp, 0.05, [], [decoy]);

      expect(res.detonated).toBe(true);
      expect(res.targetHitId).toBe('decoy_target');
      expect(torp.isDetonated).toBe(true);
      expect(res.isDud).toBe(false);
    });

    it('prioritizes closest active decoy among multiple deployed decoys', () => {
      const torp = createTorpedo('t_multi_decoy', 's1', 'm0', vec2(0, 0), 0, true);
      torp.isArmed = true;
      torp.distanceTraveled = 400;

      const decoyFar = createTorpedoDecoy('decoy_far', 'v1', vec2(450, 10), 0);
      const decoyNear = createTorpedoDecoy('decoy_near', 'v1', vec2(200, 5), 0);

      // Array has far decoy first, but near decoy should capture or first matching in cone
      stepTorpedo(torp, 0.1, [], [decoyNear, decoyFar]);
      expect(torp.isSpoofedByDecoy).toBe(true);
      expect(torp.spoofedDecoyId).toBe('decoy_near');
    });
  });

  // =========================================================================
  // 5. MONTE CARLO VERIFICATION OF ECM MISSILE DEFLECTION PROBABILITY
  // =========================================================================
  describe('5. Monte Carlo Verification of ECM Missile Deflection Probability', () => {
    it('verifies empirical ECM missile deflection matches 85% probability across N=1000 trials', () => {
      // 99.9% confidence interval for N=1000 and p=0.85:
      // stdDev = sqrt(1000 * 0.85 * 0.15) = 11.29
      // 3.29 * stdDev = 37.1 -> expected hits: between 813 and 887 (81.3% to 88.7%)
      const trials = 1000;
      let deflectedCount = 0;
      let penetratedCount = 0;

      for (let i = 0; i < trials; i++) {
        const testServer = new AuthoritativeGameServer(20);
        const attacker = testServer.spawnVessel({ position: vec2(0, 0), heading: 0 });
        const target = testServer.spawnVessel({ position: vec2(200, 0), heading: 0 });
        target.ecmActive = true;
        target.ecmTimer = 5.0;
        const initialHp = target.physics.hullHp;

        // Position cruise missile 10m from target heading directly at it
        testServer.weaponEngine.fireCruiseMissileMount(
          String(attacker.id),
          attacker.mounts[0],
          vec2(190, 0),
          0,
          vec2(200, 0)
        );

        // Step 1 tick to resolve impact and ECM check
        testServer.step(0.05);

        const events = testServer.drainQueuedEvents();
        const ecmPulse = events.find(e => e.eventType === GameEventType.ECM_PULSE);

        if (ecmPulse) {
          deflectedCount++;
          // Deflected missile must deal 0 damage
          expect(target.physics.hullHp).toBe(initialHp);
        } else {
          penetratedCount++;
          // Penetrated missile must deal damage
          expect(target.physics.hullHp).toBeLessThan(initialHp);
        }
      }

      expect(deflectedCount + penetratedCount).toBe(trials);
      const empiricalRate = deflectedCount / trials;

      // Assert empirical deflection rate is within [81.5%, 88.5%]
      expect(empiricalRate).toBeGreaterThanOrEqual(0.815);
      expect(empiricalRate).toBeLessThanOrEqual(0.885);
    });

    it('records ECM_PULSE event with 85 deflection data on successful deflection', () => {
      const attacker = server.spawnVessel({ position: vec2(0, 0), heading: 0 });
      const target = server.spawnVessel({ position: vec2(100, 0), heading: 0 });
      target.ecmActive = true;
      target.ecmTimer = 5.0;

      // Mock Math.random to guarantee deflection (< 0.85)
      const originalRandom = Math.random;
      Math.random = () => 0.42;

      try {
        server.weaponEngine.fireCruiseMissileMount(
          String(attacker.id),
          attacker.mounts[0],
          vec2(90, 0),
          0,
          vec2(100, 0)
        );

        server.step(0.05);

        const events = server.drainQueuedEvents();
        const ecmEvent = events.find(e => e.eventType === GameEventType.ECM_PULSE);
        expect(ecmEvent).toBeDefined();
        expect(ecmEvent?.sourceId).toBe(target.id);
        expect(ecmEvent?.data).toBe(85);
      } finally {
        Math.random = originalRandom;
      }
    });
  });

  // =========================================================================
  // 6. POINT DEFENSE CIWS & SAM AUTOMATED INTERCEPTION
  // =========================================================================
  describe('6. Point Defense CIWS & SAM Automated Interception', () => {
    it('CIWS Phalanx does not fire on threats outside 800m defensive envelope', () => {
      const ciwsMount = createWeaponMount('ciws_1', 'ciws_phalanx_20mm', { x: 0, y: 0 }, 0, Math.PI * 2);
      const threats: ThreatTarget[] = [
        {
          id: 'cm_out_of_range',
          position: vec2(850, 0), // 850m > 800m
          velocity: vec2(-300, 0),
          altitudeMeters: 20,
          hp: 50,
          isDestroyed: false,
          type: 'CRUISE_MISSILE',
        },
      ];

      const res = stepCIWSEnvelope(ciwsMount, vec2(0, 0), 0, threats, 0.05);
      expect(res.burstFired).toBe(false);
      expect(threats[0].hp).toBe(50);
    });

    it('CIWS respects turret mount arc boundaries when threat is in blind spot', () => {
      // Forward-only mount: baseAngle = 0, coverage = 90 deg (+/- 45 deg)
      const forwardMount = createWeaponMount('ciws_fwd', 'ciws_phalanx_20mm', { x: 0, y: 0 }, 0, degToRad(90));
      const threats: ThreatTarget[] = [
        {
          id: 'cm_behind',
          position: vec2(-400, 0), // Directly behind (-180 deg)
          velocity: vec2(300, 0),
          altitudeMeters: 20,
          hp: 50,
          isDestroyed: false,
          type: 'CRUISE_MISSILE',
        },
      ];

      const res = stepCIWSEnvelope(forwardMount, vec2(0, 0), 0, threats, 0.05);
      expect(res.burstFired).toBe(false);
      expect(threats[0].hp).toBe(50);
    });

    it('SAM ESSM makes high-G turn up to 40 deg/s and detonates within 15m proximity radius', () => {
      const sam = launchSAMInterceptor(
        'sam_g',
        'ddg_1',
        'vls',
        vec2(0, 0),
        'high_g_target',
        vec2(500, 100)
      );

      const threats: ThreatTarget[] = [
        {
          id: 'high_g_target',
          position: vec2(400, 300), // Off-axis target
          velocity: vec2(0, 0),
          altitudeMeters: 40,
          hp: 200,
          isDestroyed: false,
          type: 'AIRCRAFT',
        },
      ];

      const initialHeading = sam.heading;
      stepSAMInterceptor(sam, 0.5, threats);

      // Must have turned toward target (+Y direction)
      expect(sam.heading).toBeGreaterThan(initialHeading);

      // Move SAM within 10m proximity
      sam.position = vec2(395, 300);
      const res = stepSAMInterceptor(sam, 0.05, threats);

      expect(res.detonated).toBe(true);
      expect(res.interceptedThreatId).toBe('high_g_target');
      expect(threats[0].isDestroyed).toBe(true);
    });
  });

  // =========================================================================
  // 7. ASW DEPTH CHARGE 3D DAMAGE & NAVAL MINE ARMING LOGIC
  // =========================================================================
  describe('7. ASW Depth Charge 3D Damage & Naval Mine Arming Logic', () => {
    it('applies quadratic shockwave damage across a 3D submarine depth column', () => {
      const chargePos = vec2(100, 100);
      const chargeDepth = -20.0;
      const baseDamage = 1500;
      const blastRadius = 25.0;

      // Sub 1: exactly at detonation point (0m dist) -> 1500 damage
      const dmg0 = calculateDepthChargeDamage(chargePos, chargeDepth, vec2(100, 100), -20.0, baseDamage, blastRadius);
      expect(dmg0).toBe(1500);

      // Sub 2: 15m horizontal distance, same depth -> 1500 * (1 - (15/25)^2) = 1500 * 0.64 = 960
      const dmg15 = calculateDepthChargeDamage(chargePos, chargeDepth, vec2(115, 100), -20.0, baseDamage, blastRadius);
      expect(dmg15).toBe(960);

      // Sub 3: 0m horizontal, 20m vertical depth difference (at surface: depth = 0m) -> 1500 * (1 - (20/25)^2) = 540
      const dmgVert = calculateDepthChargeDamage(chargePos, chargeDepth, vec2(100, 100), 0.0, baseDamage, blastRadius);
      expect(dmgVert).toBe(540);

      // Sub 4: 20m horizontal + 20m vertical -> 3D dist = sqrt(800) ~ 28.3m > 25m blast radius -> 0 damage
      const dmgBeyond = calculateDepthChargeDamage(chargePos, chargeDepth, vec2(120, 100), 0.0, baseDamage, blastRadius);
      expect(dmgBeyond).toBe(0);
    });

    it('unarmed naval mine ignores high-speed vessel directly over it during 5s arming timer', () => {
      const mine = createNavalMine('m_safe', 'v1', 'm0', vec2(0, 0));
      expect(mine.isArmed).toBe(false);
      expect(mine.armingTimerRemaining).toBe(5.0);

      const speedingVessel: SurfaceVesselContact[] = [
        { id: 'v_speed', position: vec2(0, 0), speedKnots: 40, hullHp: 500, draftMeters: 2.0 },
      ];

      // Step 4.0 seconds (still 1.0s before armed)
      const res = stepNavalMine(mine, 4.0, speedingVessel);
      expect(res.detonated).toBe(false);
      expect(mine.isDetonated).toBe(false);
      expect(mine.isArmed).toBe(false);
    });

    it('armed naval mine does not detonate on submarine cruising at DEEP depth (-30m)', () => {
      const mine = createNavalMine('m_sub', 'v1', 'm0', vec2(100, 100));
      mine.isArmed = true;

      // Submarine at -30m depth passing right beneath mine
      const deepSub: SubmarineContact[] = [
        { id: 'sub_deep', position: vec2(100, 100), velocity: vec2(10, 0), depthMeters: -30.0, hullHp: 1000, isSilent: false },
      ];

      const res = stepNavalMine(mine, 0.1, [], deepSub);
      expect(res.detonated).toBe(false);
      expect(mine.isDetonated).toBe(false);
    });

    it('armed naval mine detonates on near-surface submarine (depth >= -10m)', () => {
      const mine = createNavalMine('m_sub_near', 'v1', 'm0', vec2(100, 100));
      mine.isArmed = true;

      // Submarine at periscope depth (-5.0m >= -10.0m)
      const shallowSub: SubmarineContact[] = [
        { id: 'sub_peri', position: vec2(102, 100), velocity: vec2(5, 0), depthMeters: -5.0, hullHp: 1000, isSilent: false },
      ];

      const res = stepNavalMine(mine, 0.1, [], shallowSub);
      expect(res.detonated).toBe(true);
      expect(res.victimId).toBe('sub_peri');
      expect(mine.isDetonated).toBe(true);
    });
  });

  // =========================================================================
  // 8. ADVERSARIAL INTEGRATION & EDGE CASE STRESS TESTS
  // =========================================================================
  describe('8. Adversarial Integration & Edge Case Stress Tests', () => {
    it('empirical probe: cruise missile strike vs submerged submarine at DEEP depth (-30m)', () => {
      const attacker = server.spawnVessel({ shipId: 'fletcher_dd', position: vec2(0, 0), heading: 0 });
      const deepSub = server.spawnVessel({ shipId: 'yasen_ssn', position: vec2(1000, 0), heading: 0 });
      deepSub.physics.depthState = 'DEEP';
      deepSub.physics.currentDepth = -30.0;
      const initialHp = deepSub.physics.hullHp;

      // Spawn cruise missile close to target
      server.weaponEngine.fireCruiseMissileMount(
        String(attacker.id),
        attacker.mounts[0],
        vec2(980, 0),
        0,
        vec2(1000, 0)
      );

      server.step(0.1);

      // Probe whether cruise missile damage bypassed submarine DEEP immunity:
      const damageTaken = initialHp - deepSub.physics.hullHp;
      // EMPIRICAL VULNERABILITY CONFIRMED:
      // Cruise missile lacks submarine DEEP depth immunity check in server/core/game_server.ts:960
      // Submarine takes 1268 damage while submerged at -30m depth.
      expect(damageTaken).toBeGreaterThan(0);
    });

    it('empirical probe: SAM interceptor launched through GameServer.fireMount retains hardcoded targetThreatId', () => {
      const defender = server.spawnVessel({ shipId: 'burke_ddg', position: vec2(0, 0), heading: 0 });
      const samMountIdx = defender.mounts.findIndex(m => m.category === 'SAM_CIWS' && !m.weaponDefId.includes('ciws'));
      expect(samMountIdx).toBeGreaterThanOrEqual(0);

      const fired = server.fireMount(defender.id, samMountIdx, vec2(1000, 500));
      expect(fired).toBe(true);

      const sam = server.weaponEngine.samInterceptors[0];
      expect(sam).toBeDefined();
      // EMPIRICAL VULNERABILITY CONFIRMED:
      // In server/core/game_server.ts:698, targetThreatId is hardcoded to 'target_threat',
      // so SAM interceptors can never track actual cruise missiles (id 'c_missile_X') or aircraft (id 'air_X').
      expect(sam.targetThreatId).toBe('target_threat');
    });

    it('empirical probe: SAM interception of cruise missile does not neutralize cruise missile in WeaponKinematicsEngine', () => {
      const engine = server.weaponEngine;
      const missile = createCruiseMissile('cm_target', 'enemy', 'vls', vec2(500, 0), 0, vec2(2000, 0));
      engine.cruiseMissiles.push(missile);

      // Launch SAM with targetThreatId matching missile id
      const sam = launchSAMInterceptor('sam_1', 'defender', 'vls', vec2(500, 0), 'cm_target', vec2(500, 0));
      engine.samInterceptors.push(sam);

      // Step server: threats list is generated, SAM proximity detonates
      server.step(0.05);

      // SAM detonated
      expect(sam.isDetonated).toBe(true);
      // EMPIRICAL VULNERABILITY CONFIRMED:
      // In weapon_kinematics.ts:1574, stepSAMInterceptor return value is ignored.
      // In game_server.ts, no code checks or neutralizes the intercepted cruise missile.
      // The missile is NOT intercepted and continues flying:
      expect(missile.isIntercepted).toBe(false);
      expect(missile.isDetonated).toBe(false);
    });

    it('empirical probe: CIWS neutralization of aircraft target in GameServer.step', () => {
      const defender = server.spawnVessel({ shipId: 'burke_ddg', position: vec2(0, 0), heading: 0 });
      const ciwsMount = defender.mounts.find(m => m.category === 'SAM_CIWS' && m.weaponDefId.includes('ciws'));
      expect(ciwsMount).toBeDefined();

      // Launch an aircraft near the defender
      const aircraft = server.weaponEngine.launchAircraft(
        'carrier_enemy',
        createWeaponMount('air_mount', 'carrier_strike_wing', { x: 0, y: 0 }, 0, Math.PI * 2),
        vec2(200, 0),
        'STRIKE_FIGHTER',
        vec2(0, 0)
      );
      expect(aircraft).toBeDefined();
      expect(server.weaponEngine.aircraft.length).toBe(1);

      // Step simulation: CIWS fires bursts at incoming aircraft
      server.step(0.1);

      // Probe if aircraft is tracked in threats and whether it survives
      expect(server.weaponEngine.aircraft.length).toBe(1);
    });

    it('empirical probe: naval mine flooding speed decay over multiple consecutive ticks', () => {
      const vessel = server.spawnVessel({ shipId: 'fletcher_dd', position: vec2(0, 0), heading: 0 });
      vessel.physics.throttle = 1.0;
      vessel.physics.speedKnots = 30.0;
      vessel.physics.linearVelocity = vec2(15.0, 0);

      // Apply flooding from naval mine (8 seconds duration, 60% penalty)
      vessel.floodingTimer = 8.0;
      vessel.floodingPenalty = 0.60;

      // Step for 10 ticks (0.5 seconds)
      for (let t = 0; t < 10; t++) {
        server.step(0.05);
      }

      // Check remaining speed
      expect(vessel.floodingTimer).toBeCloseTo(7.5, 1);
      // EMPIRICAL VULNERABILITY CONFIRMED:
      // In server/core/game_server.ts:722-725, speed is multiplied by factor (0.40) every tick.
      // Over 10 ticks (0.5s), speed is reduced by (0.4)^10 = 0.0001, effectively stopping the ship dead (0.003 kts)
      // instead of applying a static 60% speed penalty (running at 40% speed, i.e., 12 kts).
      expect(vessel.physics.speedKnots).toBeLessThan(0.05);
    });
  });
});
