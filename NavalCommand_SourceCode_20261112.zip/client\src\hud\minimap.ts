/**
 * Interactive Tactical Minimap
 * Clean-Room implementation for NavalCommand.io
 * Renders terrain, objectives, fleet members, enemy pings, and click-to-pan coordinates.
 */

export interface MinimapContact {
  id: number;
  x: number;
  y: number;
  heading: number;
  isPlayer: boolean;
  isFriendly: boolean;
  isSubmerged?: boolean;
}

export interface MinimapTerrain {
  x: number;
  y: number;
  radius: number;
  type: 'ISLAND' | 'SHALLOW' | 'ICEBERG';
}

export interface MinimapObjective {
  x: number;
  y: number;
  radius: number;
  name: string;
  progress: number; // 0..1
}

export type MinimapClickCallback = (worldX: number, worldY: number) => void;

export class TacticalMinimap {
  public readonly container: HTMLElement;
  private readonly canvas: HTMLCanvasElement;
  private readonly ctx: CanvasRenderingContext2D;
  private worldSize: number = 6000;
  private onClickCb: MinimapClickCallback | null = null;
  private highlightedFleetMemberId: number | null = null;

  constructor(sizePx: number = 200, worldSize: number = 6000) {
    this.worldSize = worldSize;

    this.container = document.createElement('div');
    this.container.className = 'tactical-minimap-panel';
    this.container.style.cssText = `
      position: absolute;
      bottom: 20px;
      left: 20px;
      width: ${sizePx}px;
      height: ${sizePx}px;
      background: rgba(10, 20, 35, 0.85);
      border: 1px solid rgba(0, 230, 118, 0.4);
      border-radius: 4px;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
      overflow: hidden;
      cursor: crosshair;
      user-select: none;
      z-index: 100;
    `;

    this.canvas = document.createElement('canvas');
    this.canvas.width = sizePx;
    this.canvas.height = sizePx;
    this.canvas.style.width = '100%';
    this.canvas.style.height = '100%';
    this.container.appendChild(this.canvas);

    const ctx = this.canvas.getContext('2d');
    if (!ctx) throw new Error('Failed to get 2D context for minimap');
    this.ctx = ctx;

    this.canvas.addEventListener('click', (e) => {
      const rect = this.canvas.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const clickY = e.clientY - rect.top;

      const normX = clickX / this.canvas.width - 0.5;
      const normY = clickY / this.canvas.height - 0.5;

      const worldX = normX * this.worldSize;
      const worldY = normY * this.worldSize;

      if (this.onClickCb) {
        this.onClickCb(worldX, worldY);
      }
    });
  }

  public onClick(cb: MinimapClickCallback): void {
    this.onClickCb = cb;
  }

  public highlightFleetMember(id: number | null): void {
    this.highlightedFleetMemberId = id;
  }

  /**
   * Render complete minimap situational layer.
   */
  public render(
    playerX: number,
    playerY: number,
    contacts: MinimapContact[],
    terrainList: MinimapTerrain[] = [],
    objectives: MinimapObjective[] = []
  ): void {
    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;
    const half = this.worldSize * 0.5;

    ctx.clearRect(0, 0, w, h);

    // 1. Ocean Background & Grid
    ctx.fillStyle = '#081422';
    ctx.fillRect(0, 0, w, h);

    ctx.strokeStyle = 'rgba(20, 50, 80, 0.5)';
    ctx.lineWidth = 1;
    const gridDivisions = 4;
    for (let i = 1; i < gridDivisions; i++) {
      const pos = (i / gridDivisions) * w;
      ctx.beginPath();
      ctx.moveTo(pos, 0);
      ctx.lineTo(pos, h);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, pos);
      ctx.lineTo(w, pos);
      ctx.stroke();
    }

    const toMapCoord = (wx: number, wy: number) => {
      return {
        mx: ((wx + half) / this.worldSize) * w,
        my: ((wy + half) / this.worldSize) * h,
      };
    };

    // 2. Terrain Features (Islands, Icebergs)
    for (const t of terrainList) {
      const { mx, my } = toMapCoord(t.x, t.y);
      const mr = (t.radius / this.worldSize) * w;

      if (t.type === 'ISLAND') {
        ctx.fillStyle = '#2e5836'; // Island foliage
        ctx.beginPath();
        ctx.arc(mx, my, mr, 0, Math.PI * 2);
        ctx.fill();
      } else if (t.type === 'SHALLOW') {
        ctx.fillStyle = 'rgba(38, 166, 154, 0.35)'; // Sandbar shoal
        ctx.beginPath();
        ctx.arc(mx, my, mr, 0, Math.PI * 2);
        ctx.fill();
      } else if (t.type === 'ICEBERG') {
        ctx.fillStyle = '#b2ebf2'; // Arctic ice
        ctx.beginPath();
        ctx.arc(mx, my, mr, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 3. Objectives & Capture Zones
    for (const obj of objectives) {
      const { mx, my } = toMapCoord(obj.x, obj.y);
      const mr = (obj.radius / this.worldSize) * w;

      ctx.strokeStyle = 'rgba(255, 235, 59, 0.7)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(mx, my, mr, 0, Math.PI * 2);
      ctx.stroke();

      ctx.fillStyle = 'rgba(255, 235, 59, 0.15)';
      ctx.fill();
    }

    // 4. Contacts (Vessels, Teammates, Enemies)
    for (const c of contacts) {
      const { mx, my } = toMapCoord(c.x, c.y);

      if (c.isPlayer) {
        // Player Ship: bright white arrow
        ctx.save();
        ctx.translate(mx, my);
        ctx.rotate(c.heading);

        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.moveTo(5, 0);
        ctx.lineTo(-4, -3);
        ctx.lineTo(-2, 0);
        ctx.lineTo(-4, 3);
        ctx.closePath();
        ctx.fill();

        ctx.restore();
      } else if (c.isFriendly) {
        // Friendly Fleet member: cyan dot
        ctx.fillStyle = '#00e5ff';
        ctx.beginPath();
        ctx.arc(mx, my, 2.5, 0, Math.PI * 2);
        ctx.fill();

        // Pulsating highlight if selected on fleet list
        if (c.id === this.highlightedFleetMemberId) {
          ctx.strokeStyle = '#00e5ff';
          ctx.lineWidth = 1.5;
          ctx.beginPath();
          ctx.arc(mx, my, 6, 0, Math.PI * 2);
          ctx.stroke();
        }
      } else {
        // Hostile contact: red diamond
        ctx.fillStyle = c.isSubmerged ? 'rgba(255, 23, 68, 0.45)' : '#ff1744';
        ctx.beginPath();
        ctx.moveTo(mx, my - 3);
        ctx.lineTo(mx + 3, my);
        ctx.lineTo(mx, my + 3);
        ctx.lineTo(mx - 3, my);
        ctx.closePath();
        ctx.fill();
      }
    }

    // Outer border
    ctx.strokeStyle = '#00e676';
    ctx.lineWidth = 1;
    ctx.strokeRect(0, 0, w, h);
  }
}
