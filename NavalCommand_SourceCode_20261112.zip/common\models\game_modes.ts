/**
 * Game Modes Data Models & Interfaces
 * Clean-Room implementation for NavalCommand.io
 */

import { Vector2D } from '../math/vector2.js';

export enum GameModeType {
  FFA_SANDBOX = 'FFA_SANDBOX',
  KOTH_CONVOY = 'KOTH_CONVOY',
  DUEL_ARENA = 'DUEL_ARENA',
}

export interface IGameModeController {
  readonly modeType: GameModeType;
  tick(dt: number): void;
  handleKill(killerId: number, victimId: number): void;
  handleVesselSpawn(vesselId: number): void;
  handleVesselDespawn(vesselId: number): void;
  getState(): any;
  reset(): void;
}

export enum KotHZoneState {
  NEUTRAL = 'NEUTRAL',
  CONTESTED = 'CONTESTED',
  CONTROLLED = 'CONTROLLED',
}

export interface SectorControlZone {
  center: Vector2D;
  radius: number;
  controlState: KotHZoneState;
  controllingTeamId?: number;
  captureProgress: number; // In seconds [0, captureProgressRequired]
  captureProgressRequired: number; // Default 10.0s
}

export interface ConvoyShipState {
  id: number;
  name: string;
  position: Vector2D;
  heading: number;
  speedKnots: number;
  currentWaypointIndex: number;
  isDocked: boolean;
  isDestroyed: boolean;
  hullHp: number;
  maxHp: number;
  distanceAdvancedMeters: number;
}

export enum DuelMatchState {
  IDLE = 'IDLE',
  CHALLENGE_PENDING = 'CHALLENGE_PENDING',
  STARTING = 'STARTING',
  ACTIVE = 'ACTIVE',
  ROUND_INTERMISSION = 'ROUND_INTERMISSION',
  MATCH_COMPLETED = 'MATCH_COMPLETED',
}

export enum DuelFormat {
  SUDDEN_DEATH = 'SUDDEN_DEATH',
  BEST_OF_3 = 'BEST_OF_3',
}

export interface LeaderboardEntry {
  vesselId: number;
  name: string;
  score: number;
  kills: number;
  deaths: number;
  accumulatedXp: number;
  tier: number;
  shipId: string;
}

export interface FFAState {
  worldTime: number;
  activeVesselsCount: number;
  leaderboard: LeaderboardEntry[];
  pendingRespawnCount: number;
}

export interface KotHConvoyState {
  matchTimeRemaining: number;
  matchDuration: number;
  scoreCap: number;
  teamScores: Record<number, number>;
  controlZone: SectorControlZone;
  convoyShips: ConvoyShipState[];
  isCompleted: boolean;
  winningTeamId?: number;
}

export interface DuelChallenge {
  challengeId: string;
  challengerId: number;
  targetId: number;
  format: DuelFormat;
  createdAt: number;
  expiresAt: number;
}

export interface DuelSavedPosition {
  position: Vector2D;
  heading: number;
  hullHp: number;
}

export interface DuelMatchStateData {
  duelId: string;
  challengerId: number;
  targetId: number;
  format: DuelFormat;
  state: DuelMatchState;
  currentRound: number;
  challengerWins: number;
  targetWins: number;
  countdownTimer: number;
  intermissionTimer: number;
  weaponsLocked: boolean;
  winnerId?: number;
}
