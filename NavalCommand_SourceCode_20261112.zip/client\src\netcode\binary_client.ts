/**
 * High-Performance Binary WebSocket Client
 * Clean-Room implementation for NavalCommand.io
 * Compact ArrayBuffer / DataView serialization with 28-byte entity snapshots.
 */

export const OP_CLIENT_INPUT = 0x01;
export const OP_SERVER_SNAPSHOT = 0x02;
export const OP_PROJECTILE_EVENT = 0x03;
export const OP_SENSOR_DELTA = 0x04;
export const OP_GAME_EVENT = 0x05;
export const OP_SPAWN_REQ = 0x06;
export const OP_SPAWN_RES = 0x07;
export const OP_PING_PONG = 0x08;

export interface EntitySnapshot {
  entityId: number;
  hullTypeId: number;
  depthState: number; // 0 = SURFACE, 1 = PERISCOPE, 2 = DEEP
  x: number;          // meters
  y: number;          // meters
  vx: number;         // m/s
  vy: number;         // m/s
  heading: number;    // radians
  turretAngle: number;// radians
  currentHealth: number;
  maxHealth: number;
  statusBitflags: number;
  karmaScore: number;
  fleetId: number;
  isCavitating: boolean;
  isFiring: boolean;
  ecmActive: boolean;
  sonarActive: boolean;
  nonAggressionTimer: boolean;
}

export interface WorldSnapshot {
  serverTick: number;
  ackInputSequence: number;
  worldTimeSeconds: number;
  timestamp: number;
  entities: EntitySnapshot[];
}

export interface ClientInputData {
  sequence: number;
  steer: number;     // -1.0 to 1.0
  throttle: number;  // -1.0 to 1.0
  aimAngleRad: number;
  targetDistance: number;
  firePrimary: boolean;
  fireSecondary: boolean;
  fireTorpedo: boolean;
  fireMissile: boolean;
  diveToggle: boolean;
  stealthToggle: boolean;
  ecmToggle: boolean;
  activeSonar: boolean;
}

export type SnapshotCallback = (snapshot: WorldSnapshot) => void;
export type SpawnCallback = (entityId: number, startX: number, startY: number) => void;

export class BinaryClient {
  private ws: WebSocket | null = null;
  private url: string = '';
  private isConnected: boolean = false;
  private onSnapshotCb: SnapshotCallback | null = null;
  private onSpawnCb: SpawnCallback | null = null;

  public pingMs: number = 0;
  private lastPingTime: number = 0;

  constructor() {}

  public connect(url: string): Promise<boolean> {
    this.url = url;
    return new Promise((resolve) => {
      try {
        if (typeof WebSocket === 'undefined') {
          resolve(false);
          return;
        }

        this.ws = new WebSocket(url);
        this.ws.binaryType = 'arraybuffer';

        this.ws.onopen = () => {
          this.isConnected = true;
          this.startPingLoop();
          resolve(true);
        };

        this.ws.onclose = () => {
          this.isConnected = false;
        };

        this.ws.onerror = () => {
          this.isConnected = false;
          resolve(false);
        };

        this.ws.onmessage = (event: MessageEvent) => {
          if (event.data instanceof ArrayBuffer) {
            this.handleBinaryMessage(event.data);
          }
        };
      } catch {
        this.isConnected = false;
        resolve(false);
      }
    });
  }

  public onSnapshot(cb: SnapshotCallback): void {
    this.onSnapshotCb = cb;
  }

  public onSpawn(cb: SpawnCallback): void {
    this.onSpawnCb = cb;
  }

  /**
   * Serialize and transmit 16-byte OP_CLIENT_INPUT packet.
   */
  public sendInput(input: ClientInputData): void {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;

    const buffer = new ArrayBuffer(16);
    const view = new DataView(buffer);

    view.setUint8(0, OP_CLIENT_INPUT);

    let flags = 0;
    if (input.firePrimary) flags |= 1 << 0;
    if (input.fireSecondary) flags |= 1 << 1;
    if (input.fireTorpedo) flags |= 1 << 2;
    if (input.fireMissile) flags |= 1 << 3;
    if (input.diveToggle) flags |= 1 << 4;
    if (input.stealthToggle) flags |= 1 << 5;
    if (input.ecmToggle) flags |= 1 << 6;
    if (input.activeSonar) flags |= 1 << 7;
    view.setUint8(1, flags);

    view.setUint16(2, input.sequence & 0xffff, true);
    view.setInt16(4, Math.round(Math.max(-1, Math.min(1, input.steer)) * 1000), true);
    view.setInt16(6, Math.round(Math.max(-1, Math.min(1, input.throttle)) * 1000), true);

    // Aim angle normalized 0..2*PI mapped to 0..65535
    const normAngle = ((input.aimAngleRad % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI);
    const angleU16 = Math.round((normAngle / (2 * Math.PI)) * 65535);
    view.setUint16(8, angleU16, true);

    view.setUint16(10, Math.min(65535, Math.round(input.targetDistance * 10)), true);
    view.setUint32(12, Date.now() & 0xffffffff, true);

    this.ws.send(buffer);
  }

  /**
   * Send spawn request (OP_SPAWN_REQ = 0x06)
   */
  public sendSpawnRequest(shipClassIndex: number, camoIndex: number, loadoutMask: number = 0): void {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;

    const buffer = new ArrayBuffer(8);
    const view = new DataView(buffer);
    view.setUint8(0, OP_SPAWN_REQ);
    view.setUint8(1, shipClassIndex);
    view.setUint8(2, camoIndex);
    view.setUint8(3, 0); // reserved
    view.setUint32(4, loadoutMask, true);

    this.ws.send(buffer);
  }

  /**
   * Parse incoming binary frames according to 1-byte opcode.
   */
  public handleBinaryMessage(buffer: ArrayBuffer): void {
    if (buffer.byteLength < 1) return;
    const view = new DataView(buffer);
    const opcode = view.getUint8(0);

    if (opcode === OP_SERVER_SNAPSHOT) {
      this.parseServerSnapshot(view);
    } else if (opcode === OP_SPAWN_RES) {
      if (view.byteLength >= 16 && this.onSpawnCb) {
        const entityId = view.getUint16(2, true);
        const startX = view.getInt16(4, true) / 10;
        const startY = view.getInt16(6, true) / 10;
        this.onSpawnCb(entityId, startX, startY);
      }
    } else if (opcode === OP_PING_PONG) {
      if (view.byteLength >= 8) {
        const sentTime = view.getUint32(4, true);
        this.pingMs = Math.max(1, (Date.now() & 0xffffffff) - sentTime);
      }
    }
  }

  /**
   * Parse 28-byte entity records from authoritative snapshot packet.
   */
  public parseServerSnapshot(view: DataView): WorldSnapshot | null {
    if (view.byteLength < 12) return null;

    const serverTick = view.getUint32(2, true);
    const ackInputSequence = view.getUint16(6, true);
    const entityCount = view.getUint16(8, true);
    const worldTimeSeconds = view.getUint16(10, true);

    const entities: EntitySnapshot[] = [];
    const RECORD_SIZE = 28;

    for (let i = 0; i < entityCount; i++) {
      const offset = 12 + i * RECORD_SIZE;
      if (offset + RECORD_SIZE > view.byteLength) break;

      const entityId = view.getUint16(offset + 0, true);
      const hullTypeId = view.getUint8(offset + 2);
      const depthState = view.getUint8(offset + 3);

      const x = view.getInt16(offset + 4, true) / 10.0;
      const y = view.getInt16(offset + 6, true) / 10.0;
      const vx = view.getInt16(offset + 8, true) / 100.0;
      const vy = view.getInt16(offset + 10, true) / 100.0;

      const headingU16 = view.getUint16(offset + 12, true);
      const heading = (headingU16 / 65535.0) * (2 * Math.PI);

      const turretU16 = view.getUint16(offset + 14, true);
      const turretAngle = (turretU16 / 65535.0) * (2 * Math.PI);

      const currentHealth = view.getUint16(offset + 16, true);
      const maxHealth = view.getUint16(offset + 18, true);

      const statusBitflags = view.getUint16(offset + 20, true);
      const karmaScore = view.getUint16(offset + 22, true);
      const fleetId = view.getUint32(offset + 24, true);

      entities.push({
        entityId,
        hullTypeId,
        depthState,
        x,
        y,
        vx,
        vy,
        heading,
        turretAngle,
        currentHealth,
        maxHealth,
        statusBitflags,
        karmaScore,
        fleetId,
        isCavitating: (statusBitflags & (1 << 0)) !== 0,
        isFiring: (statusBitflags & (1 << 1)) !== 0,
        ecmActive: (statusBitflags & (1 << 2)) !== 0,
        sonarActive: (statusBitflags & (1 << 5)) !== 0,
        nonAggressionTimer: (statusBitflags & (1 << 7)) !== 0,
      });
    }

    const snapshot: WorldSnapshot = {
      serverTick,
      ackInputSequence,
      worldTimeSeconds,
      timestamp: performance.now(),
      entities,
    };

    if (this.onSnapshotCb) {
      this.onSnapshotCb(snapshot);
    }

    return snapshot;
  }

  private startPingLoop(): void {
    setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        const buffer = new ArrayBuffer(8);
        const view = new DataView(buffer);
        view.setUint8(0, OP_PING_PONG);
        view.setUint32(4, Date.now() & 0xffffffff, true);
        this.lastPingTime = Date.now();
        this.ws.send(buffer);
      }
    }, 2000);
  }

  public disconnect(): void {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
      this.isConnected = false;
    }
  }

  public get connected(): boolean {
    return this.isConnected;
  }
}
