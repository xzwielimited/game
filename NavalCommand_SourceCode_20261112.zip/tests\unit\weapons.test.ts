/**
 * Comprehensive Unit & Integration Tests for Milestone M2:
 * Weapons Kinematics, Ballistic Solvers, Equipment Systems & Authoritative Server Integration
 */

import { describe, it, expect, beforeEach } from 'vitest';
import {
  Vector2D,
  vec2,
  vec2Distance,
  degToRad,
  radToDeg,
  normalizeAngle,
  shortestAngleDiff,
  SHIP_ROSTER,
  ShipDef,
  WeaponMountDef,
  WeaponCategory,
  WEAPON_DEFINITIONS,
  createWeaponMount,
  canMountFire,
  fireMount,
  stepMountReloadAndRegen,
  stepMountTraverse,
  isAngleWithinMountArc,
  calculateDispersionEllipse,
  calculateDispersionOffset,
  calculateBallisticFlightTime,
  calculateShellAltitude,
  calculatePlungeAngleRad,
  calculateShellImpactPosition,
  createArtilleryShell,
  stepArtilleryShell,
  createTorpedo,
  createTorpedoDecoy,
  stepTorpedo,
  stepTorpedoDecoy,
  createCruiseMissile,
  stepCruiseMissile,
  createRocket,
  stepRocket,
  createRocketTorpedo,
  stepRocketTorpedo,
  stepCIWSEnvelope,
  launchSAMInterceptor,
  stepSAMInterceptor,
  createDepthCharge,
  calculateDepthChargeDamage,
  stepDepthCharge,
  createNavalMine,
  stepNavalMine,
  createAircraftSquadron,
  stepAircraft,
  deploySonarBuoy,
  stepSonarBuoy,
  executeDredgerAction,
  WeaponKinematicsEngine,
  WeaponKinematicsWorldContext,
  TerrainEngine,
  SubmarineContact,
  SurfaceVesselContact,
  AcousticContact,
  ThreatTarget,
  GameEventType,
} from '../../common/index.js';
import { AuthoritativeGameServer, GameServer } from '../../server/core/game_server.js';

describe('Milestone M2: Weapons Kinematics & Equipment Systems', () => {

  // ==========================================================================
  // Suite 1: Naval Artillery Turrets & Ballistic Solvers
  // ==========================================================================
  describe('1. Naval Artillery Turrets & Ballistic Trajectories', () => {
    it('calculates dispersion ellipse axes proportional to line-of-fire distance', () => {
      const dist1000 = calculateDispersionEllipse(1000.0);
      expect(dist1000.semiMajorAxis).toBeCloseTo(25.0, 1); // 2.5% of 1000m
      expect(dist1000.semiMinorAxis).toBeCloseTo(12.0, 1); // 1.2% of 1000m

      const dist2000 = calculateDispersionEllipse(2000.0);
      expect(dist2000.semiMajorAxis).toBeCloseTo(50.0, 1);
      expect(dist2000.semiMinorAxis).toBeCloseTo(24.0, 1);

      // Zero distance check
      const dist0 = calculateDispersionEllipse(0.0);
      expect(dist0.semiMajorAxis).toBe(0);
      expect(dist0.semiMinorAxis).toBe(0);
    });

    it('calculates deterministic dispersion offsets and shell impact coordinates', () => {
      const origin = vec2(0, 0);
      const targetPos = vec2(1000, 0);
      const dispersion = calculateDispersionOffset(1000, 1.0, 0.5);

      expect(dispersion.dr).toBeCloseTo(25.0, 1);
      expect(dispersion.dtheta).toBeCloseTo(6.0, 1);

      const impactPos = calculateShellImpactPosition(origin, targetPos, dispersion);
      expect(impactPos.x).toBeCloseTo(1025.0, 1);
      expect(impactPos.y).toBeCloseTo(6.0, 1);
    });

    it('models parabolic altitude z(t) and returns to zero at flight expiration', () => {
      const flightTimeTotal = 4.0;
      const peakAltitude = 80.0;

      // At launch (t = 0), altitude is 0
      expect(calculateShellAltitude(flightTimeTotal, 0, peakAltitude)).toBe(0);

      // At peak midpoint (t = T/2), altitude equals peakAltitude
      expect(calculateShellAltitude(flightTimeTotal, 2.0, peakAltitude)).toBeCloseTo(80.0, 1);

      // At 1/4 flight time: 4 * 80 * 0.25 * 0.75 = 60m
      expect(calculateShellAltitude(flightTimeTotal, 1.0, peakAltitude)).toBeCloseTo(60.0, 1);

      // At landing (t = T), altitude is 0
      expect(calculateShellAltitude(flightTimeTotal, 4.0, peakAltitude)).toBe(0);
      expect(calculateShellAltitude(flightTimeTotal, 4.5, peakAltitude)).toBe(0);
    });

    it('computes plunging fire impact angle theta_plunge = atan(4 * h_peak / d)', () => {
      const peakAltitude = 100.0;
      const distance = 1000.0;
      const expectedAngle = Math.atan2(4.0 * 100.0, 1000.0);
      const plungeAngle = calculatePlungeAngleRad(peakAltitude, distance);

      expect(plungeAngle).toBeCloseTo(expectedAngle, 4);
      expect(radToDeg(plungeAngle)).toBeCloseTo(21.8, 1);
    });

    it('scales shell blast radius and peak altitude with authentic naval caliber (20mm vs 460mm)', () => {
      const origin = vec2(0, 0);
      const target = vec2(2000, 0);

      const shell20mm = createArtilleryShell('s_20', 'ship1', 'mount0', origin, target, {
        id: 'autocannon_20mm',
        name: '20mm',
        category: 'ARTILLERY',
        baseDamage: 25,
        maxRange: 1500,
        projectileSpeed: 900,
        reloadTimeTotal: 0.1,
        ammoMax: 200,
        ammoRegenRate: 10,
        traverseSpeed: 1.5,
        defaultArcCoverage: Math.PI * 2,
        caliberMm: 20,
      });

      const shell460mm = createArtilleryShell('s_460', 'ship2', 'mount0', origin, target, {
        id: 'gun_460mm',
        name: '460mm Type 94',
        category: 'ARTILLERY',
        baseDamage: 1200,
        maxRange: 5000,
        projectileSpeed: 780,
        reloadTimeTotal: 30,
        ammoMax: 20,
        ammoRegenRate: 0.1,
        traverseSpeed: 0.05,
        defaultArcCoverage: Math.PI * 1.5,
        caliberMm: 460,
      });

      expect(shell20mm.blastRadius).toBeCloseTo(3.0, 1);
      expect(shell460mm.blastRadius).toBeCloseTo(45.0, 1);
      expect(shell460mm.peakAltitude).toBeGreaterThan(shell20mm.peakAltitude * 3);

      // Step shell until detonation
      let res = stepArtilleryShell(shell460mm, shell460mm.flightTimeTotal / 2);
      expect(res.detonated).toBe(false);
      expect(shell460mm.altitude).toBeGreaterThan(0);

      res = stepArtilleryShell(shell460mm, shell460mm.flightTimeTotal / 2 + 0.1);
      expect(res.detonated).toBe(true);
      expect(shell460mm.altitude).toBe(0);
      expect(shell460mm.isDetonated).toBe(true);
    });
  });

  // ==========================================================================
  // Suite 2: Torpedoes, Acoustic Homing & Countermeasure Decoys
  // ==========================================================================
  describe('2. Torpedoes, Acoustic Homing & Countermeasure Decoys', () => {
    it('straight-running torpedoes arm immediately and advance along launch vector', () => {
      const pos = vec2(100, 100);
      const heading = 0; // East
      const torp = createTorpedo('t1', 'v1', 'm0', pos, heading, false);

      expect(torp.isArmed).toBe(true);
      expect(torp.isAcousticHoming).toBe(false);
      expect(torp.speed).toBeCloseTo(24.69, 1); // 48 knots in m/s

      stepTorpedo(torp, 1.0);
      expect(torp.position.x).toBeCloseTo(100 + 24.69, 1);
      expect(torp.position.y).toBeCloseTo(100, 1);
      expect(torp.distanceTraveled).toBeCloseTo(24.69, 1);
    });

    it('straight-running torpedoes become duds upon reaching max range without impact', () => {
      const torp = createTorpedo('t1', 'v1', 'm0', vec2(0, 0), 0, false);
      torp.distanceTraveled = torp.maxRange - 5;

      const res = stepTorpedo(torp, 1.0); // travels ~24.7m > 5m remaining
      expect(res.isDud).toBe(true);
      expect(torp.isDud).toBe(true);
      expect(torp.isDetonated).toBe(false);
    });

    it('acoustic homing torpedoes require 300m arming run before activating seeker cone', () => {
      const torp = createTorpedo('t_ac', 'v1', 'm0', vec2(0, 0), 0, true);
      expect(torp.isArmed).toBe(false);
      expect(torp.armingDistance).toBe(300.0);

      // Acoustic contact at 200m ahead with bearing 0.2 rad
      const contacts: AcousticContact[] = [
        {
          id: 'target1',
          position: vec2(250, 50),
          velocity: vec2(0, 0),
          isCavitating: true,
          isActiveSonarPinging: false,
          acousticSignatureDb: 100,
        },
      ];

      // Step 5 seconds: travels ~98m (< 300m)
      stepTorpedo(torp, 5.0, contacts);
      expect(torp.isArmed).toBe(false);
      expect(torp.heading).toBe(0); // Heading untouched

      // Step until past 300m
      stepTorpedo(torp, 12.0, contacts); // travels ~234m more, total > 330m
      expect(torp.isArmed).toBe(true);
    });

    it('armed acoustic torpedo acquires and tracks moving acoustic target within +/-35 deg cone', () => {
      const torp = createTorpedo('t_ac', 'v1', 'm0', vec2(400, 0), 0, true);
      torp.isArmed = true;
      torp.distanceTraveled = 400;

      // Contact at 600m X, 50m Y (bearing ~ 14 degrees, within 35 deg cone)
      const contacts: AcousticContact[] = [
        {
          id: 'enemy_sub',
          position: vec2(600, 50),
          velocity: vec2(0, 0),
          isCavitating: true,
          isActiveSonarPinging: false,
          acousticSignatureDb: 110,
        },
      ];

      const initialHeading = torp.heading;
      stepTorpedo(torp, 0.5, contacts);

      // Seeker turns toward contact (+Y)
      expect(torp.heading).toBeGreaterThan(initialHeading);
      expect(torp.targetContactId).toBe('enemy_sub');
    });

    it('torpedo decoy deploys 120 dB noisemaker and diverts acoustic torpedo within 500m attraction radius', () => {
      const torp = createTorpedo('t_ac', 'v1', 'm0', vec2(500, 0), 0, true);
      torp.isArmed = true;
      torp.distanceTraveled = 500;

      // Target ship is straight ahead at (900, 0)
      const contacts: AcousticContact[] = [
        {
          id: 'target_ship',
          position: vec2(900, 0),
          velocity: vec2(0, 0),
          isCavitating: true,
          isActiveSonarPinging: false,
          acousticSignatureDb: 95,
        },
      ];

      // Decoy is deployed off-axis at (700, 80) with 120 dB attraction
      const decoy = createTorpedoDecoy('decoy_1', 'target_ship', vec2(700, 80), degToRad(45));
      expect(decoy.acousticSignatureDb).toBe(120.0);
      expect(decoy.attractionRadius).toBe(500.0);

      // Step torpedo with decoy present
      stepTorpedo(torp, 1.0, contacts, [decoy]);

      expect(torp.isSpoofedByDecoy).toBe(true);
      expect(torp.spoofedDecoyId).toBe('decoy_1');
      expect(torp.heading).toBeGreaterThan(0); // Veered off towards decoy!

      // Decoy detonation proximity: position torpedo 5m from decoy pointing directly at it
      torp.position = vec2(700, 75);
      torp.heading = Math.PI / 2;
      torp.velocity = vec2(0, torp.speed);
      const res = stepTorpedo(torp, 0.05, contacts, [decoy]);
      expect(res.detonated).toBe(true);
      expect(res.targetHitId).toBe('decoy_1');
      expect(torp.isDetonated).toBe(true);
    });
  });

  // ==========================================================================
  // Suite 3: Cruise Missiles & Submarine Tactical Guidance Constraint
  // ==========================================================================
  describe('3. Cruise Missiles & Submarine Tactical Guidance Constraint', () => {
    it('transitions through BOOST, MIDCOURSE, and TERMINAL flight phases with radar seeker activation', () => {
      const missile = createCruiseMissile(
        'cm_1',
        'sub_1',
        'vls_0',
        vec2(0, 0),
        0,
        vec2(5000, 0),
        false,
        0
      );

      expect(missile.flightPhase).toBe('BOOST');
      expect(missile.boostDuration).toBe(1.5);
      expect(missile.currentSpeed).toBe(120.0);

      // Step through boost phase
      stepCruiseMissile(missile, 1.0);
      expect(missile.flightPhase).toBe('BOOST');
      expect(missile.currentSpeed).toBeGreaterThan(120.0);

      // Step past boost phase into midcourse
      stepCruiseMissile(missile, 1.0);
      expect(missile.flightPhase).toBe('MIDCOURSE');
      expect(missile.currentSpeed).toBe(350.0);
      expect(missile.radarSeekerActive).toBe(false);

      // Transport missile near target (< 1200m)
      missile.position = vec2(4200, 0);
      stepCruiseMissile(missile, 0.1);
      expect(missile.flightPhase).toBe('TERMINAL');
      expect(missile.radarSeekerActive).toBe(true);
    });

    it('rejects cruise missile launch when submarine is at DEEP depth', () => {
      const server = new AuthoritativeGameServer();
      const sub = server.spawnVessel({
        shipId: 'yasen_ssn', // Yasen-M SSGN with cruise_missile_vls
        position: vec2(0, 0),
        heading: 0,
      });

      // Command sub to DEEP depth
      sub.physics.depthState = 'DEEP';
      sub.physics.currentDepth = -30.0;

      // Find missile mount
      const missileMountIdx = sub.mounts.findIndex(m => m.category === 'CRUISE_MISSILE');
      expect(missileMountIdx).toBeGreaterThanOrEqual(0);

      const fired = server.fireMount(sub.id, missileMountIdx, vec2(2000, 0));
      expect(fired).toBe(false);
      expect(server.weaponEngine.cruiseMissiles.length).toBe(0);
    });

    it('allows surface and periscope depth submarine cruise missile launches', () => {
      const server = new AuthoritativeGameServer();
      const sub = server.spawnVessel({
        shipId: 'yasen_ssn',
        position: vec2(0, 0),
        heading: 0,
      });

      // At PERISCOPE depth (-5.0m)
      sub.physics.depthState = 'PERISCOPE';
      sub.physics.currentDepth = -5.0;

      const missileMountIdx = sub.mounts.findIndex(m => m.category === 'CRUISE_MISSILE');
      const fired = server.fireMount(sub.id, missileMountIdx, vec2(2000, 0));
      expect(fired).toBe(true);
      expect(server.weaponEngine.cruiseMissiles.length).toBe(1);
    });

    it('aborts guidance when launching submarine dives below PERISCOPE_DEPTH (< -5.0m)', () => {
      const missile = createCruiseMissile(
        'cm_dive',
        'sub_typhoon',
        'vls_0',
        vec2(0, 0),
        0,
        vec2(3000, 500),
        true,
        -5.0 // Launched at periscope depth
      );

      expect(missile.guidanceActive).toBe(true);
      expect(missile.guidanceAborted).toBe(false);

      // Launcher is at -5.0m: guidance intact
      stepCruiseMissile(missile, 0.5, -5.0);
      expect(missile.guidanceActive).toBe(true);

      // Submarine dived to -10.0m: guidance severed!
      stepCruiseMissile(missile, 0.5, -10.0);
      expect(missile.guidanceActive).toBe(false);
      expect(missile.guidanceAborted).toBe(true);
    });

    it('aborted cruise missile continues along dumb unguided ballistic course', () => {
      const missile = createCruiseMissile(
        'cm_dumb',
        'sub_1',
        'vls_0',
        vec2(0, 0),
        0,
        vec2(3000, 1000),
        true,
        -20.0 // Launched from deep or sub dived
      );

      // Guidance immediately aborted
      stepCruiseMissile(missile, 0.1, -20.0);
      expect(missile.guidanceAborted).toBe(true);

      const frozenHeading = missile.heading;
      // Target moves drastically, missile does not steer
      stepCruiseMissile(missile, 1.0, -20.0, vec2(1000, -2000));
      expect(missile.heading).toBe(frozenHeading);
    });
  });

  // ==========================================================================
  // Suite 4: Unguided Rocket Barrages & Hybrid ASROC Rocket Torpedoes
  // ==========================================================================
  describe('4. Unguided Rocket Barrages & Hybrid ASROC Rocket Torpedoes', () => {
    it('fires 12-round RBU saturation rocket barrage with radial/cross dispersion pattern', () => {
      const engine = new WeaponKinematicsEngine();
      const mount = createWeaponMount('rbu_mount', 'rocket_barrage_rbu', { x: 5, y: 0 }, 0, Math.PI);
      const origin = vec2(0, 0);
      const target = vec2(1200, 0);

      const rockets = engine.fireRocketBarrageMount('v_ddg', mount, origin, target, 12);
      expect(rockets.length).toBe(12);

      // Verify dispersion spread around target coordinates
      const xCoords = rockets.map(r => r.targetPos.x);
      const yCoords = rockets.map(r => r.targetPos.y);

      const minX = Math.min(...xCoords);
      const maxX = Math.max(...xCoords);
      const minY = Math.min(...yCoords);
      const maxY = Math.max(...yCoords);

      expect(maxX - minX).toBeGreaterThan(10);
      expect(maxY - minY).toBeGreaterThan(5);
    });

    it('steps unguided rockets to impact and marks detonated', () => {
      const rocket = createRocket('r1', 'v1', 'm0', vec2(0, 0), vec2(420, 0));
      expect(rocket.flightTimeTotal).toBeCloseTo(1.0, 2); // 420m at 420 m/s = 1.0s

      let res = stepRocket(rocket, 0.5);
      expect(res.detonated).toBe(false);
      expect(rocket.isDetonated).toBe(false);

      res = stepRocket(rocket, 0.6); // Total 1.1s >= 1.0s
      expect(res.detonated).toBe(true);
      expect(rocket.isDetonated).toBe(true);
      expect(rocket.currentPos.x).toBeCloseTo(420, 1);
    });

    it('transitions ASROC from AIR_BALLISTIC to WATER_ENTRY at designated water entry coordinates', () => {
      const asroc = createRocketTorpedo('asroc_1', 'cruiser_1', 'asroc_launcher', vec2(0, 0), vec2(560, 0));
      expect(asroc.flightPhase).toBe('AIR_BALLISTIC');
      expect(asroc.airSpeed).toBe(280.0);
      expect(asroc.airFlightDuration).toBeCloseTo(2.0, 2); // 560m / 280 m/s = 2.0s

      // Step 1 second in air
      stepRocketTorpedo(asroc, 1.0);
      expect(asroc.flightPhase).toBe('AIR_BALLISTIC');
      expect(asroc.position.x).toBeCloseTo(280, 1);

      // Step past 2 seconds: transitions to parachute water entry
      stepRocketTorpedo(asroc, 1.1);
      expect(asroc.flightPhase).toBe('WATER_ENTRY');
    });

    it('transitions ASROC from WATER_ENTRY to UNDERWATER_HOMING and acquires submerged contact', () => {
      const asroc = createRocketTorpedo('asroc_1', 'cruiser_1', 'asroc_launcher', vec2(0, 0), vec2(280, 0));
      // Advance into water entry
      stepRocketTorpedo(asroc, 1.1);
      expect(asroc.flightPhase).toBe('WATER_ENTRY');

      // Parachute deployment phase takes 0.8s
      stepRocketTorpedo(asroc, 0.9);
      expect(asroc.flightPhase).toBe('UNDERWATER_HOMING');
      expect(asroc.waterSpeed).toBeCloseTo(25.72, 1); // 50 knots

      // Acoustic contact at 350m X, 20m Y
      const contacts: AcousticContact[] = [
        {
          id: 'hostile_sub',
          position: vec2(350, 20),
          velocity: vec2(0, 0),
          isCavitating: true,
          isActiveSonarPinging: false,
          acousticSignatureDb: 105,
        },
      ];

      const prevHeading = asroc.heading;
      stepRocketTorpedo(asroc, 0.5, contacts);
      expect(asroc.targetContactId).toBe('hostile_sub');
      expect(asroc.heading).toBeGreaterThan(prevHeading); // Turned toward target
    });
  });

  // ==========================================================================
  // Suite 5: Point Defense: Automated CIWS & SAM Interception
  // ==========================================================================
  describe('5. Point Defense: Automated CIWS & SAM Interception', () => {
    it('CIWS Phalanx traverses and engages aerial threat within 800m defensive envelope', () => {
      const ciwsMount = createWeaponMount('ciws_mount', 'ciws_phalanx_20mm', { x: 0, y: 0 }, 0, degToRad(300));
      const mountWorldPos = vec2(0, 0);
      const shipHeading = 0;

      const threats: ThreatTarget[] = [
        {
          id: 'cm_threat_1',
          position: vec2(600, 50),
          velocity: vec2(-300, 0),
          altitudeMeters: 20,
          hp: 50,
          isDestroyed: false,
          type: 'CRUISE_MISSILE',
        },
      ];

      // Step CIWS envelope
      const res = stepCIWSEnvelope(ciwsMount, mountWorldPos, shipHeading, threats, 0.05);
      expect(res.burstFired).toBe(true);
      expect(threats[0].hp).toBeLessThan(50);
    });

    it('CIWS deals burst damage and successfully neutralizes incoming cruise missile', () => {
      const ciwsMount = createWeaponMount('ciws_mount', 'ciws_phalanx_20mm', { x: 0, y: 0 }, 0, Math.PI * 2);
      ciwsMount.baseDamage = 25;
      const mountWorldPos = vec2(0, 0);

      const threats: ThreatTarget[] = [
        {
          id: 'missile_incoming',
          position: vec2(400, 0),
          velocity: vec2(-350, 0),
          altitudeMeters: 15,
          hp: 40,
          isDestroyed: false,
          type: 'CRUISE_MISSILE',
        },
      ];

      // Burst 1 deals 25 damage -> 15 HP left
      let res = stepCIWSEnvelope(ciwsMount, mountWorldPos, 0, threats, 0.1);
      expect(res.burstFired).toBe(true);
      expect(threats[0].hp).toBe(15);
      expect(threats[0].isDestroyed).toBe(false);

      // Burst 2 deals 25 damage -> <= 0 HP, intercepted!
      res = stepCIWSEnvelope(ciwsMount, mountWorldPos, 0, threats, 0.1);
      expect(res.burstFired).toBe(true);
      expect(res.interceptedThreatId).toBe('missile_incoming');
      expect(threats[0].isDestroyed).toBe(true);
    });

    it('launches RIM-162 ESSM interceptor against high-speed aerial threat', () => {
      const sam = launchSAMInterceptor(
        'sam_1',
        'ship_aegis',
        'mk41_vls',
        vec2(0, 0),
        'air_target_1',
        vec2(1500, 200)
      );

      expect(sam.speed).toBe(680.0);
      expect(sam.maxFlightTime).toBe(5.0);
      expect(sam.proximityRadius).toBe(15.0);
      expect(sam.damage).toBe(450);
      expect(sam.isDetonated).toBe(false);
    });

    it('ESSM tracks with 40 deg/s high-G turns and detonates on 15m proximity fuse', () => {
      const sam = launchSAMInterceptor(
        'sam_2',
        'ship_aegis',
        'mk41_vls',
        vec2(0, 0),
        'hostile_bomber',
        vec2(100, 0)
      );

      const threats: ThreatTarget[] = [
        {
          id: 'hostile_bomber',
          position: vec2(10, 0), // Within 15m proximity
          velocity: vec2(0, 0),
          altitudeMeters: 50,
          hp: 400,
          isDestroyed: false,
          type: 'AIRCRAFT',
        },
      ];

      const res = stepSAMInterceptor(sam, 0.05, threats);
      expect(res.detonated).toBe(true);
      expect(res.interceptedThreatId).toBe('hostile_bomber');
      expect(sam.isDetonated).toBe(true);
      expect(threats[0].hp).toBeLessThanOrEqual(0);
      expect(threats[0].isDestroyed).toBe(true);
    });
  });

  // ==========================================================================
  // Suite 6: ASW Depth Charges & Hydrostatic Fuses
  // ==========================================================================
  describe('6. ASW Depth Charges & Hydrostatic Fuses', () => {
    it('sinks through water column at authentic 3.5 m/s sink rate', () => {
      const dc = createDepthCharge('dc_1', 'ddg_fletcher', 'dc_rack', vec2(100, 100), 'DEEP');
      expect(dc.currentDepth).toBe(0.0);
      expect(dc.sinkRate).toBe(3.5);

      stepDepthCharge(dc, 2.0); // 2 seconds * 3.5 m/s = 7.0m sink
      expect(dc.currentDepth).toBeCloseTo(-7.0, 1);
      expect(dc.isDetonated).toBe(false);
    });

    it('detonates upon reaching preset hydrostatic fuse depth (SURFACE, PERISCOPE, DEEP)', () => {
      const dcSurface = createDepthCharge('dc_s', 'v1', 'm0', vec2(0, 0), 'SURFACE');
      expect(dcSurface.targetDetonationDepth).toBe(0.0);
      const resSurface = stepDepthCharge(dcSurface, 0.1);
      expect(resSurface.detonated).toBe(true);

      const dcPeriscope = createDepthCharge('dc_p', 'v1', 'm0', vec2(0, 0), 'PERISCOPE');
      expect(dcPeriscope.targetDetonationDepth).toBe(-5.0);
      stepDepthCharge(dcPeriscope, 1.0); // -3.5m
      expect(dcPeriscope.isDetonated).toBe(false);
      stepDepthCharge(dcPeriscope, 1.0); // -7.0m <= -5.0m -> detonated
      expect(dcPeriscope.isDetonated).toBe(true);

      const dcDeep = createDepthCharge('dc_d', 'v1', 'm0', vec2(0, 0), 'DEEP');
      expect(dcDeep.targetDetonationDepth).toBe(-30.0);
    });

    it('detonates early via magnetic proximity fuse when submarine passes within 15m', () => {
      const dc = createDepthCharge('dc_prox', 'v1', 'm0', vec2(50, 50), 'DEEP');
      // Submarine is located at (55, 52) at depth -4.0m
      const subs: SubmarineContact[] = [
        {
          id: 'sub_alpha',
          position: vec2(55, 52),
          velocity: vec2(0, 0),
          depthMeters: -4.0,
          hullHp: 1000,
          isSilent: true,
        },
      ];

      // Sink to depth -3.5m (horizontal dist ~ 5.8m, vertical ~ 0.5m -> 3D dist ~ 5.8m <= 15m)
      const res = stepDepthCharge(dc, 1.0, subs);
      expect(res.detonated).toBe(true);
      expect(dc.isDetonated).toBe(true);
      expect(res.damageMap.has('sub_alpha')).toBe(true);
    });

    it('applies 3D quadratic shockwave damage falloff and zeroes damage beyond 25m blast radius', () => {
      const chargePos = vec2(0, 0);
      const chargeDepth = -10.0;
      const baseDamage = 1500;
      const blastRadius = 25.0;

      // 0m distance: 100% damage = 1500
      const dmg0 = calculateDepthChargeDamage(chargePos, chargeDepth, vec2(0, 0), -10.0, baseDamage, blastRadius);
      expect(dmg0).toBe(1500);

      // 12.5m distance (half radius): 1500 * (1 - 0.25) = 1125
      const dmgHalf = calculateDepthChargeDamage(chargePos, chargeDepth, vec2(12.5, 0), -10.0, baseDamage, blastRadius);
      expect(dmgHalf).toBe(1125);

      // 20m distance: 1500 * (1 - (20/25)^2) = 1500 * (1 - 0.64) = 540
      const dmg20 = calculateDepthChargeDamage(chargePos, chargeDepth, vec2(16, 0), -22.0, baseDamage, blastRadius);
      expect(dmg20).toBeCloseTo(540, -1);

      // 26m distance (> 25m blast radius): 0 damage
      const dmgOut = calculateDepthChargeDamage(chargePos, chargeDepth, vec2(26, 0), -10.0, baseDamage, blastRadius);
      expect(dmgOut).toBe(0);
    });
  });

  // ==========================================================================
  // Suite 7: Moored Contact & Magnetic Naval Mines
  // ==========================================================================
  describe('7. Moored Contact & Magnetic Naval Mines', () => {
    it('enforces 5.0s arming delay during which mine cannot be triggered', () => {
      const mine = createNavalMine('mine_1', 'minelayer_1', 'mine_rack', vec2(0, 0));
      expect(mine.isArmed).toBe(false);
      expect(mine.armingTimerRemaining).toBe(5.0);

      const surfaceVessels: SurfaceVesselContact[] = [
        { id: 'patrol_boat', position: vec2(2, 2), speedKnots: 20, hullHp: 500, draftMeters: 1.5 },
      ];

      // Step 3 seconds: not armed, no detonation even though boat is right on top
      const res = stepNavalMine(mine, 3.0, surfaceVessels);
      expect(res.detonated).toBe(false);
      expect(mine.isArmed).toBe(false);

      // Step past 5 seconds: arms
      stepNavalMine(mine, 2.5, []);
      expect(mine.isArmed).toBe(true);
    });

    it('triggers immediate detonation on direct vessel hull contact within 10m', () => {
      const mine = createNavalMine('mine_contact', 'minelayer_1', 'mine_rack', vec2(100, 100));
      mine.isArmed = true;

      const surfaceVessels: SurfaceVesselContact[] = [
        { id: 'dd_fletcher', position: vec2(106, 100), speedKnots: 5, hullHp: 2000, draftMeters: 4.0 },
      ];

      const res = stepNavalMine(mine, 0.1, surfaceVessels);
      expect(res.detonated).toBe(true);
      expect(res.victimId).toBe('dd_fletcher');
      expect(res.damage).toBe(2200);
      expect(mine.isDetonated).toBe(true);
    });

    it('triggers magnetic influence detonation when fast vessel (>= 15 kts) passes within 18m', () => {
      const mine = createNavalMine('mine_mag', 'minelayer_1', 'mine_rack', vec2(200, 200));
      mine.isArmed = true;

      // Vessel at 14m distance with speed 10 kts (< 15 kts threshold): does not trigger
      const slowVessel: SurfaceVesselContact[] = [
        { id: 'trawler', position: vec2(214, 200), speedKnots: 10, hullHp: 1200, draftMeters: 3.0 },
      ];
      let res = stepNavalMine(mine, 0.1, slowVessel);
      expect(res.detonated).toBe(false);

      // Fast vessel at 16m distance with speed 25 kts (>= 15 kts threshold): triggers magnetic detonation!
      const fastVessel: SurfaceVesselContact[] = [
        { id: 'fast_pt', position: vec2(216, 200), speedKnots: 25, hullHp: 450, draftMeters: 1.2 },
      ];
      res = stepNavalMine(mine, 0.1, fastVessel);
      expect(res.detonated).toBe(true);
      expect(res.victimId).toBe('fast_pt');
      expect(mine.isDetonated).toBe(true);
    });

    it('inflicts 2200 blast damage and flooding speed penalty', () => {
      const mine = createNavalMine('mine_flood', 'v1', 'm0', vec2(0, 0));
      expect(mine.damage).toBe(2200);
      expect(mine.floodingSpeedPenalty).toBe(0.60);
      expect(mine.floodingDurationSeconds).toBe(8.0);
    });
  });

  // ==========================================================================
  // Suite 8: Carrier Aircraft Squadrons & Persistent Sonar Buoys
  // ==========================================================================
  describe('8. Carrier Aircraft Squadrons & Persistent Sonar Buoys', () => {
    it('strike fighter cruises at 120 m/s toward waypoint and initiates attack run', () => {
      const fighter = createAircraftSquadron(
        'air_1',
        'carrier_nimitz',
        'STRIKE_FIGHTER',
        vec2(0, 0),
        vec2(240, 0)
      );

      expect(fighter.cruiseSpeed).toBe(120.0);
      expect(fighter.status).toBe('TRANSIT');
      expect(fighter.payloadAmmo).toBe(4);
      expect(fighter.strikeDamage).toBe(650);

      // Advance 1 second: advances 120m
      stepAircraft(fighter, 1.0);
      expect(fighter.position.x).toBeCloseTo(120, 1);
      expect(fighter.status).toBe('TRANSIT');

      // Advance another second: advances to waypoint (240m)
      stepAircraft(fighter, 1.0);
      expect(fighter.position.x).toBeCloseTo(240, 1);

      // Next tick confirms arrival at waypoint and initiates attack run
      const res = stepAircraft(fighter, 0.05);
      expect(res.reachedWaypoint).toBe(true);
      expect(fighter.status).toBe('ATTACK_RUN');
    });

    it('aircraft returns to carrier when fuel supply is exhausted', () => {
      const heli = createAircraftSquadron(
        'heli_1',
        'cruiser_1',
        'ASW_HELICOPTER',
        vec2(0, 0),
        vec2(5000, 0)
      );

      heli.fuelRemaining = 1.0;
      const res = stepAircraft(heli, 1.5);
      expect(res.fuelDepleted).toBe(true);
      expect(heli.status).toBe('RETURNING');
      expect(heli.isReturning).toBe(true);
    });

    it('ASW helicopter deploys persistent 1,200m radius Sonar Buoy', () => {
      const buoy = deploySonarBuoy('buoy_alpha', 'heli_asw_1', vec2(1000, 1000));
      expect(buoy.radius).toBe(1200.0);
      expect(buoy.durationRemaining).toBe(75.0);
      expect(buoy.isExpired).toBe(false);
    });

    it('sonar buoy persistently detects submerged submarines within 1,200m for 75 seconds', () => {
      const buoy = deploySonarBuoy('buoy_tactical', 'heli_1', vec2(0, 0));

      const subs: SubmarineContact[] = [
        { id: 'sub_in_range', position: vec2(800, 0), velocity: vec2(0, 0), depthMeters: -30, hullHp: 800, isSilent: false },
        { id: 'sub_out_range', position: vec2(1400, 0), velocity: vec2(0, 0), depthMeters: -30, hullHp: 800, isSilent: false },
      ];

      const detected = stepSonarBuoy(buoy, 1.0, subs);
      expect(detected).toContain('sub_in_range');
      expect(detected).not.toContain('sub_out_range');
      expect(buoy.durationRemaining).toBe(74.0);

      // Step past 75s expiration
      stepSonarBuoy(buoy, 75.0, subs);
      expect(buoy.isExpired).toBe(true);
      expect(buoy.detectedContactIds.length).toBe(0);
    });
  });

  // ==========================================================================
  // Suite 9: Hydraulic Dredger & Sand Depositor Tool
  // ==========================================================================
  describe('9. Hydraulic Dredger & Sand Depositor Tool', () => {
    let terrainEngine: TerrainEngine;

    beforeEach(() => {
      terrainEngine = new TerrainEngine();
    });

    it('excavates shallow water channel to 15.0m deep navigable water for heavy warships', () => {
      const targetCoords = vec2(3200, 5500); // Default shallow zone depth = 3.0m
      const mod = executeDredgerAction(
        'dredger_barents',
        vec2(3100, 5500),
        targetCoords,
        'EXCAVATE',
        terrainEngine,
        150.0,
        15.0
      );

      expect(mod.type).toBe('EXCAVATE');
      expect(mod.targetDepth).toBe(15.0);
      expect(terrainEngine.getModifications().length).toBe(1);
    });

    it('deposits sand creating 2.0m shallow sandbar capable of grounding draft >= 2.0m hulls', () => {
      const targetCoords = vec2(2000, 2000);
      const mod = executeDredgerAction(
        'dredger_barents',
        vec2(1900, 2000),
        targetCoords,
        'DEPOSIT_SAND',
        terrainEngine,
        100.0,
        2.0
      );

      expect(mod.type).toBe('DEPOSIT');
      expect(mod.targetDepth).toBe(2.0);
      expect(terrainEngine.getModifications().length).toBe(1);
    });

    it('records terrain modification metadata in TerrainEngine', () => {
      executeDredgerAction('dredger_1', vec2(0, 0), vec2(500, 500), 'EXCAVATE', terrainEngine, 200);
      executeDredgerAction('dredger_1', vec2(0, 0), vec2(1000, 1000), 'DEPOSIT_SAND', terrainEngine, 100);

      const mods = terrainEngine.getModifications();
      expect(mods.length).toBe(2);
      expect(mods[0].type).toBe('EXCAVATE');
      expect(mods[1].type).toBe('DEPOSIT');
    });
  });

  // ==========================================================================
  // Suite 10: Weapon Mounts, Traversal Arcs & Ammunition Regeneration
  // ==========================================================================
  describe('10. Weapon Mounts, Traversal Arcs & Ammunition Regeneration', () => {
    it('enforces port and starboard mount firing arc limit stops', () => {
      // Port torpedo mount: baseAngle = -PI/2 (-90 deg), arcCoverage = 30 deg
      const portMount = createWeaponMount('port_torp', 'torpedo_533mm_unguided', { x: 0, y: -3 }, -Math.PI / 2, degToRad(30));

      // Aiming port at -90 deg: inside arc
      expect(isAngleWithinMountArc(portMount, -Math.PI / 2)).toBe(true);

      // Aiming starboard at +90 deg: outside arc!
      expect(isAngleWithinMountArc(portMount, Math.PI / 2)).toBe(false);

      // Aiming bow at 0 deg: outside arc!
      expect(isAngleWithinMountArc(portMount, 0)).toBe(false);
    });

    it('steps turret traversal toward aiming bearing at designated traverse speed', () => {
      const mount = createWeaponMount('bow_turret', 'autocannon_20mm', { x: 10, y: 0 }, 0, degToRad(280));
      mount.currentAngle = 0;
      mount.traverseSpeed = 1.0; // 1 rad/s

      // Target relative angle is +0.5 rad
      stepMountTraverse(mount, 0.5, 0.2); // Steps 0.2 rad
      expect(mount.currentAngle).toBeCloseTo(0.2, 2);

      // Steps another 0.4 rad (exceeds 0.5, snaps to target)
      stepMountTraverse(mount, 0.5, 0.4);
      expect(mount.currentAngle).toBeCloseTo(0.5, 2);
    });

    it('resets reload timer and decrements ammo pool upon discharge', () => {
      const mount = createWeaponMount('main_gun', 'autocannon_20mm', { x: 0, y: 0 }, 0, Math.PI * 2);
      expect(mount.ammoCurrent).toBe(mount.ammoMax);
      expect(mount.reloadTimeRemaining).toBe(0);

      const fired = fireMount(mount);
      expect(fired).toBe(true);
      expect(mount.ammoCurrent).toBe(mount.ammoMax - 1);
      expect(mount.reloadTimeRemaining).toBe(mount.reloadTimeTotal);

      // Cannot fire immediately while reloading
      expect(canMountFire(mount)).toBe(false);
      expect(fireMount(mount)).toBe(false);
    });

    it('regenerates ammunition pool over time up to maximum capacity', () => {
      const mount = createWeaponMount('gun', 'autocannon_20mm', { x: 0, y: 0 }, 0, Math.PI * 2);
      mount.ammoCurrent = 5;
      mount.ammoMax = 10;
      mount.ammoRegenRate = 2.0; // 2 rounds per second
      mount.reloadTimeRemaining = 1.0;

      stepMountReloadAndRegen(mount, 1.0);
      expect(mount.reloadTimeRemaining).toBe(0);
      expect(mount.ammoCurrent).toBe(7);

      stepMountReloadAndRegen(mount, 5.0);
      expect(mount.ammoCurrent).toBe(10); // Capped at ammoMax
    });
  });

  // ==========================================================================
  // Suite 11: Server Game Loop (GameServer) Integration & Combat Damage
  // ==========================================================================
  describe('11. Server Game Loop (GameServer) Integration & Combat Damage', () => {
    let server: AuthoritativeGameServer;

    beforeEach(() => {
      server = new AuthoritativeGameServer();
    });

    it('verifies GameServer instantiates WeaponKinematicsEngine and manages active weapon entities', () => {
      expect(server.weaponEngine).toBeInstanceOf(WeaponKinematicsEngine);
      expect(server.terrainEngine).toBeInstanceOf(TerrainEngine);
      expect(server.getAllProjectiles()).toEqual([]);
    });

    it('dispatches firing requests across all weapon categories through GameServer.fireMount', () => {
      const v = server.spawnVessel({ shipId: 'fletcher_dd', position: vec2(0, 0), heading: 0 });

      // Artillery firing
      const artIdx = v.mounts.findIndex(m => m.category === 'ARTILLERY');
      expect(server.fireMount(v.id, artIdx, vec2(1000, 0))).toBe(true);
      expect(server.weaponEngine.shells.length).toBe(1);

      // Torpedo firing
      const torpIdx = v.mounts.findIndex(m => m.category === 'TORPEDO');
      expect(server.fireMount(v.id, torpIdx, vec2(0, 500))).toBe(true);
      expect(server.weaponEngine.torpedoes.length).toBe(1);

      // Projectiles mapping
      const allProj = server.getAllProjectiles();
      expect(allProj.length).toBe(2);
      expect(allProj.some(p => p.category === 'ARTILLERY')).toBe(true);
      expect(allProj.some(p => p.category === 'TORPEDO')).toBe(true);
    });

    it('advances all weapon kinematics in GameServer.step(dt)', () => {
      const v = server.spawnVessel({ shipId: 'fletcher_dd', position: vec2(0, 0), heading: 0 });
      const artIdx = v.mounts.findIndex(m => m.category === 'ARTILLERY');
      server.fireMount(v.id, artIdx, vec2(800, 0));

      const shell = server.weaponEngine.shells[0];
      const initialPos = shell.currentPos.x;

      server.step(0.1);
      expect(shell.timeElapsed).toBeGreaterThan(0);
      expect(shell.currentPos.x).toBeGreaterThan(initialPos);
      expect(shell.altitude).toBeGreaterThan(0);
    });

    it('enforces submarine DEEP depth immunity against surface artillery shells', () => {
      const attacker = server.spawnVessel({ shipId: 'fletcher_dd', position: vec2(0, 0), heading: 0 });
      const subVictim = server.spawnVessel({ shipId: 'sub_project_941', position: vec2(200, 0), heading: 0 });

      // Set sub to DEEP depth (-30m)
      subVictim.physics.depthState = 'DEEP';
      subVictim.physics.currentDepth = -30.0;
      const initialHp = subVictim.physics.hullHp;

      // Fire artillery directly at submarine coordinates
      const artIdx = attacker.mounts.findIndex(m => m.category === 'ARTILLERY');
      server.fireMount(attacker.id, artIdx, vec2(200, 0));

      const shell = server.weaponEngine.shells[0];
      // Fast-forward shell to right before impact
      shell.timeElapsed = shell.flightTimeTotal - 0.05;

      // Step server to resolve impact
      server.step(0.1);

      // Submarine was immune at DEEP depth!
      expect(subVictim.physics.hullHp).toBe(initialHp);
    });

    it('deflects guided cruise missiles when target vessel has active ECM jamming', () => {
      const target = server.spawnVessel({ shipId: 'arleigh_burke_ddg', position: vec2(1000, 0), heading: 0 });
      target.ecmActive = true;

      const attacker = server.spawnVessel({ shipId: 'fletcher_dd', position: vec2(0, 0), heading: 0 });

      // Create cruise missile right next to target
      server.weaponEngine.fireCruiseMissileMount(
        String(attacker.id),
        attacker.mounts[0],
        vec2(980, 0),
        0,
        vec2(1000, 0)
      );

      const missile = server.weaponEngine.cruiseMissiles[0];
      expect(missile).toBeDefined();

      // Step server loop
      server.step(0.1);

      // Events should register either ECM_PULSE or HIT
      const events = server.drainQueuedEvents();
      expect(events.length).toBeGreaterThan(0);
    });

    it('enforces Non-Aggression Pact (NAP) 100% damage immunity between vessels', () => {
      const v1 = server.spawnVessel({ position: vec2(0, 0) });
      const v2 = server.spawnVessel({ position: vec2(100, 0) });
      const initialHp = v2.physics.hullHp;

      // Establish 15-second Non-Aggression Pact
      server.setFleetNAP(v1.id, v2.id, 15.0);

      expect(server.canDamage(v1.id, v2.id)).toBe(false);
      const damageDealt = server.applyDamage(v1.id, v2.id, 200);

      expect(damageDealt).toBe(0);
      expect(v2.physics.hullHp).toBe(initialHp);
    });

    it('applies Karma penalty when attacking former fleetmate within 30s of NAP expiry', () => {
      const v1 = server.spawnVessel({ position: vec2(0, 0) });
      const v2 = server.spawnVessel({ position: vec2(100, 0) });
      v1.karma = 100;

      // Simulate NAP expired 10 seconds ago
      v1.napExpiredTimers.set(v2.id, 10.0);

      const netDamage = server.applyDamage(v1.id, v2.id, 100);
      expect(netDamage).toBeGreaterThan(0);
      expect(v1.karma).toBe(75); // Penalized -25 karma!

      const events = server.drainQueuedEvents();
      const karmaEvent = events.find(e => e.eventType === GameEventType.KARMA_PENALTY);
      expect(karmaEvent).toBeDefined();
      expect(karmaEvent?.sourceId).toBe(v1.id);
      expect(karmaEvent?.targetId).toBe(v2.id);
    });

    it('awards combat score and XP on projectile hit and target sink', () => {
      const killer = server.spawnVessel({ position: vec2(0, 0) });
      const victim = server.spawnVessel({ position: vec2(50, 0) });
      victim.physics.hullHp = 10;

      // Fatal strike
      server.applyDamage(killer.id, victim.id, 500);

      expect(victim.physics.isDestroyed).toBe(true);
      expect(victim.deaths).toBe(1);
      expect(killer.kills).toBe(1);
      expect(killer.score).toBeGreaterThanOrEqual(500);
      expect(killer.accumulatedXp).toBeGreaterThanOrEqual(250);

      const events = server.drainQueuedEvents();
      const sinkEvent = events.find(e => e.eventType === GameEventType.SINK);
      expect(sinkEvent).toBeDefined();
      expect(sinkEvent?.targetId).toBe(victim.id);
    });
  });

  // ==========================================================================
  // Suite 12: Edge Cases & Boundary Value Analysis (BVA)
  // ==========================================================================
  describe('12. Edge Cases & Boundary Value Analysis (BVA)', () => {
    it('handles zero-distance point-blank weapon discharge without NaN or Infinity', () => {
      const shell = createArtilleryShell(
        's_zero',
        'v1',
        'm0',
        vec2(50, 50),
        vec2(50, 50),
        WEAPON_DEFINITIONS['autocannon_20mm']
      );

      expect(Number.isNaN(shell.targetPos.x)).toBe(false);
      expect(Number.isNaN(shell.flightTimeTotal)).toBe(false);
      expect(Number.isFinite(shell.plungeAngleRad)).toBe(true);

      const stepRes = stepArtilleryShell(shell, 0.1);
      expect(stepRes.detonated).toBe(true);
      expect(Number.isFinite(shell.currentPos.x)).toBe(true);
    });

    it('prevents firing when ammo pool is depleted or reload timer is active', () => {
      const mount = createWeaponMount('empty_mount', 'autocannon_20mm', { x: 0, y: 0 }, 0, Math.PI * 2);
      mount.ammoCurrent = 0;

      expect(canMountFire(mount)).toBe(false);
      expect(fireMount(mount)).toBe(false);

      // Restore ammo but set reload timer
      mount.ammoCurrent = 10;
      mount.reloadTimeRemaining = 2.5;

      expect(canMountFire(mount)).toBe(false);
      expect(fireMount(mount)).toBe(false);
    });

    it('supports full 360-degree coverage mounts without angular clamping glitches', () => {
      const mount = createWeaponMount('full_turret', 'autocannon_20mm', { x: 0, y: 0 }, 0, Math.PI * 2);

      expect(isAngleWithinMountArc(mount, 0)).toBe(true);
      expect(isAngleWithinMountArc(mount, Math.PI)).toBe(true);
      expect(isAngleWithinMountArc(mount, -Math.PI / 2)).toBe(true);
      expect(isAngleWithinMountArc(mount, Math.PI / 2)).toBe(true);
      expect(isAngleWithinMountArc(mount, -Math.PI)).toBe(true);
    });

    it('handles rapid continuous weapon cycling across 100 consecutive ticks without state corruption', () => {
      const server = new AuthoritativeGameServer();
      const v1 = server.spawnVessel({ shipId: 'fletcher_dd', position: vec2(0, 0), heading: 0 });
      const v2 = server.spawnVessel({ shipId: 'fletcher_dd', position: vec2(500, 0), heading: Math.PI });

      // Run 100 consecutive ticks while cycling fire
      for (let tick = 0; tick < 100; tick++) {
        if (tick % 10 === 0) {
          server.fireMount(v1.id, 0, v2.physics.position);
          server.fireMount(v2.id, 0, v1.physics.position);
        }
        server.step(0.05);

        // Assert numerical sanity every tick
        expect(Number.isFinite(v1.physics.position.x)).toBe(true);
        expect(Number.isFinite(v1.physics.position.y)).toBe(true);
        expect(Number.isFinite(v2.physics.position.x)).toBe(true);
        expect(Number.isFinite(v2.physics.position.y)).toBe(true);
      }
    });

    it('gracefully manages simultaneous multi-category weapon entities under 100-tick load', () => {
      const server = new AuthoritativeGameServer();
      const carrier = server.spawnVessel({ shipId: 'carrier_nimitz', position: vec2(0, 0), heading: 0 });
      const sub = server.spawnVessel({ shipId: 'sub_project_941', position: vec2(1000, 1000), heading: 0 });

      // Spawn multi-category projectiles
      server.weaponEngine.fireArtilleryMount(String(carrier.id), carrier.mounts[0], vec2(0, 0), vec2(2000, 0));
      server.weaponEngine.fireTorpedoMount(String(sub.id), sub.mounts[0], vec2(1000, 1000), 0, true);
      server.weaponEngine.fireCruiseMissileMount(String(carrier.id), carrier.mounts[0], vec2(0, 0), 0, vec2(3000, 0));
      server.weaponEngine.dropDepthCharge(String(carrier.id), carrier.mounts[0], vec2(500, 500));
      server.weaponEngine.layNavalMine(String(carrier.id), carrier.mounts[0], vec2(200, 200));
      server.weaponEngine.deployPersistentSonarBuoy(String(carrier.id), vec2(800, 800));

      for (let tick = 0; tick < 100; tick++) {
        server.step(0.05);
      }

      // Simulation continues smoothly without unhandled exceptions or NaN
      expect(server.getAllVessels().length).toBe(2);
      expect(Number.isFinite(carrier.physics.hullHp)).toBe(true);
      expect(Number.isFinite(sub.physics.hullHp)).toBe(true);
    });
  });
});
