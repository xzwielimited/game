/**
 * Hydrodynamic Water Wake Meshes & Propeller Wash
 * Clean-Room procedural vector implementation using PixiJS v8.
 * Simulates Kelvin wake angle (19.47°) bow wave splines and propeller foam wash.
 */

import { Container, Graphics } from 'pixi.js';

interface WakeTrailNode {
  x: number;
  y: number;
  heading: number;
  beam: number;
  speedRatio: number;
  age: number;
  maxAge: number;
  isCavitation: boolean;
}

export class WakeFX {
  public readonly container: Container;
  private readonly graphics: Graphics;
  private wakeNodes: WakeTrailNode[] = [];
  private readonly maxNodes: number = 600;

  constructor() {
    this.container = new Container();
    this.graphics = new Graphics();
    this.container.addChild(this.graphics);
  }

  /**
   * Emit wake nodes behind an active vessel.
   * @param sternX World X coordinate of vessel stern / props
   * @param sternY World Y coordinate of vessel stern / props
   * @param heading Heading angle in radians
   * @param beam Vessel beam in meters
   * @param speedKnots Speed in knots
   * @param depth 0 = Surface, 1 = Periscope, 2 = Deep
   * @param isCavitating Cavitation state
   */
  public emitWake(
    sternX: number,
    sternY: number,
    heading: number,
    beam: number,
    speedKnots: number,
    depth: number = 0,
    isCavitating: boolean = false
  ): void {
    // Deep vessels create 0 surface wake
    if (depth >= 2) return;

    // Minimum speed threshold for visible wake
    if (speedKnots < 2.0) return;

    const speedRatio = Math.min(1.5, speedKnots / 30);
    // Periscope depth reduces wake intensity and width
    const depthScale = depth === 1 ? 0.35 : 1.0;

    const node: WakeTrailNode = {
      x: sternX,
      y: sternY,
      heading,
      beam: beam * depthScale,
      speedRatio: speedRatio * depthScale,
      age: 0,
      maxAge: 3.5 * Math.max(0.5, speedRatio),
      isCavitation: isCavitating && depth === 0,
    };

    if (this.wakeNodes.length >= this.maxNodes) {
      this.wakeNodes.shift();
    }
    this.wakeNodes.push(node);
  }

  /**
   * Update wake lifespans and render procedural vector wash ribbons.
   */
  public update(dt: number): void {
    const g = this.graphics;
    g.clear();

    const alive: WakeTrailNode[] = [];

    // Kelvin wake half-angle ~ 19.47 degrees (0.34 rad)
    const KELVIN_SIN = Math.sin(0.34);
    const KELVIN_COS = Math.cos(0.34);

    for (let i = 0; i < this.wakeNodes.length; i++) {
      const node = this.wakeNodes[i];
      node.age += dt;

      if (node.age < node.maxAge) {
        alive.push(node);

        const progress = node.age / node.maxAge;
        const alpha = (1.0 - progress) * (node.isCavitation ? 0.65 : 0.45) * node.speedRatio;
        if (alpha <= 0.01) continue;

        // Spread out perpendicular to heading as wake ages (Kelvin wake envelope)
        const spreadDistance = node.beam * 0.5 + node.age * 12.0 * KELVIN_SIN;
        const perpAngle = node.heading + Math.PI / 2;

        const leftX = node.x + Math.cos(perpAngle) * spreadDistance;
        const leftY = node.y + Math.sin(perpAngle) * spreadDistance;
        const rightX = node.x - Math.cos(perpAngle) * spreadDistance;
        const rightY = node.y - Math.sin(perpAngle) * spreadDistance;

        // 1. Stern turbulent prop wash center foam
        const foamRadius = (node.beam * 0.35 + node.age * 3.5) * node.speedRatio;
        const foamColor = node.isCavitation ? 0xffffff : 0xccf0f8;

        g.circle(node.x, node.y, Math.max(1, foamRadius));
        g.fill({
          color: foamColor,
          alpha: alpha * 0.7,
        });

        // 2. Kelvin lateral bow/stern wave crests
        const crestRadius = Math.max(1.2, (2.0 + node.age * 2.5) * node.speedRatio);
        g.circle(leftX, leftY, crestRadius);
        g.fill({
          color: 0xe0f7fa,
          alpha: alpha * 0.85,
        });

        g.circle(rightX, rightY, crestRadius);
        g.fill({
          color: 0xe0f7fa,
          alpha: alpha * 0.85,
        });

        // Lateral spray edges
        if (progress < 0.5) {
          g.moveTo(leftX, leftY);
          g.lineTo(node.x, node.y);
          g.lineTo(rightX, rightY);
          g.stroke({
            color: 0xb2ebf2,
            width: 1.5,
            alpha: alpha * 0.4,
          });
        }
      }
    }

    this.wakeNodes = alive;
  }

  public clear(): void {
    this.wakeNodes = [];
    this.graphics.clear();
  }

  public get count(): number {
    return this.wakeNodes.length;
  }
}
