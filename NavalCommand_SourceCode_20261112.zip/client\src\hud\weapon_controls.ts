/**
 * Weapon Controls & Tactical Ability Panel
 * Clean-Room implementation for NavalCommand.io
 * Renders independent reload cooldown bars, ammo counters, and Dive/Stealth/ECM buttons.
 */

export interface WeaponSlotUIState {
  slotIndex: number;
  name: string;
  category: string;
  ammoCurrent: number;
  ammoMax: number;
  reloadTimeRemaining: number;
  reloadTimeTotal: number;
  isReady: boolean;
  isSelected: boolean;
}

export interface TacticalAbilitiesState {
  depthState: number; // 0 = Surface, 1 = Periscope, 2 = Deep
  diveCooldownRemaining: number;
  isStealthActive: boolean;
  ecmActive: boolean;
  ecmActiveRemaining: number;
  ecmCooldownRemaining: number;
}

export type DiveToggleCallback = () => void;
export type StealthToggleCallback = () => void;
export type EcmToggleCallback = () => void;
export type WeaponSelectCallback = (slotIndex: number) => void;

export class WeaponControlsHUD {
  public readonly container: HTMLElement;
  private weaponSlotElements: HTMLElement[] = [];
  private diveBtn!: HTMLButtonElement;
  private stealthBtn!: HTMLButtonElement;
  private ecmBtn!: HTMLButtonElement;

  private onDiveCb: DiveToggleCallback | null = null;
  private onStealthCb: StealthToggleCallback | null = null;
  private onEcmCb: EcmToggleCallback | null = null;
  private onWeaponSelectCb: WeaponSelectCallback | null = null;

  constructor() {
    this.container = document.createElement('div');
    this.container.className = 'tactical-weapons-panel';
    this.container.style.cssText = `
      position: absolute;
      bottom: 20px;
      right: 20px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      align-items: flex-end;
      z-index: 100;
      user-select: none;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    `;

    this.buildAbilitiesBar();
    this.buildWeaponsBar();
  }

  private buildAbilitiesBar(): void {
    const bar = document.createElement('div');
    bar.style.cssText = `
      display: flex;
      gap: 8px;
    `;

    // 1. Dive / Surface Button [Q]
    this.diveBtn = document.createElement('button');
    this.diveBtn.style.cssText = this.getButtonStyle('#0288d1');
    this.diveBtn.innerHTML = `<div>[Q] DIVE</div><div style="font-size: 10px; opacity: 0.85;">SURFACE</div>`;
    this.diveBtn.addEventListener('click', () => this.onDiveCb && this.onDiveCb());

    // 2. Stealth Cruise Button [E]
    this.stealthBtn = document.createElement('button');
    this.stealthBtn.style.cssText = this.getButtonStyle('#455a64');
    this.stealthBtn.innerHTML = `<div>[E] STEALTH</div><div style="font-size: 10px; opacity: 0.85;">OFF</div>`;
    this.stealthBtn.addEventListener('click', () => this.onStealthCb && this.onStealthCb());

    // 3. ECM Jammer Button [F]
    this.ecmBtn = document.createElement('button');
    this.ecmBtn.style.cssText = this.getButtonStyle('#7b1fa2');
    this.ecmBtn.innerHTML = `<div>[F] ECM JAM</div><div style="font-size: 10px; opacity: 0.85;">READY</div>`;
    this.ecmBtn.addEventListener('click', () => this.onEcmCb && this.onEcmCb());

    bar.appendChild(this.diveBtn);
    bar.appendChild(this.stealthBtn);
    bar.appendChild(this.ecmBtn);
    this.container.appendChild(bar);
  }

  private buildWeaponsBar(): void {
    const bar = document.createElement('div');
    bar.className = 'weapon-slots-row';
    bar.style.cssText = `
      display: flex;
      gap: 8px;
    `;

    for (let i = 0; i < 4; i++) {
      const slotEl = document.createElement('div');
      slotEl.style.cssText = `
        width: 100px;
        background: rgba(10, 22, 38, 0.88);
        border: 1px solid rgba(0, 230, 118, 0.3);
        border-radius: 4px;
        padding: 6px 8px;
        color: #fff;
        cursor: pointer;
        display: flex;
        flex-direction: column;
        gap: 4px;
        transition: border-color 0.15s;
      `;

      slotEl.innerHTML = `
        <div style="display: flex; justify-content: space-between; font-size: 11px; font-weight: 700;">
          <span style="color: #00e676;">[${i + 1}]</span>
          <span class="slot-ammo" style="color: #90caf9;">--</span>
        </div>
        <div class="slot-name" style="font-size: 11px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
          Slot ${i + 1}
        </div>
        <div style="width: 100%; height: 5px; background: rgba(255,255,255,0.1); border-radius: 2px; overflow: hidden;">
          <div class="slot-reload-bar" style="width: 100%; height: 100%; background: #00e676; transition: width 0.1s linear;"></div>
        </div>
        <div class="slot-status" style="font-size: 9px; text-align: right; color: #00e676;">RDY</div>
      `;

      const slotIdx = i;
      slotEl.addEventListener('click', () => {
        if (this.onWeaponSelectCb) {
          this.onWeaponSelectCb(slotIdx);
        }
      });

      this.weaponSlotElements.push(slotEl);
      bar.appendChild(slotEl);
    }

    this.container.appendChild(bar);
  }

  private getButtonStyle(themeColor: string): string {
    return `
      background: rgba(12, 25, 42, 0.9);
      border: 1px solid ${themeColor};
      border-radius: 4px;
      color: #fff;
      padding: 6px 12px;
      cursor: pointer;
      font-size: 11px;
      font-weight: 700;
      text-align: center;
      min-width: 85px;
      transition: all 0.2s;
    `;
  }

  public setCallbacks(cbs: {
    onDive?: DiveToggleCallback;
    onStealth?: StealthToggleCallback;
    onEcm?: EcmToggleCallback;
    onWeaponSelect?: WeaponSelectCallback;
  }): void {
    if (cbs.onDive) this.onDiveCb = cbs.onDive;
    if (cbs.onStealth) this.onStealthCb = cbs.onStealth;
    if (cbs.onEcm) this.onEcmCb = cbs.onEcm;
    if (cbs.onWeaponSelect) this.onWeaponSelectCb = cbs.onWeaponSelect;
  }

  /**
   * Update weapon slot cooldown bars and ammunition values.
   */
  public updateWeapons(slots: WeaponSlotUIState[]): void {
    for (let i = 0; i < this.weaponSlotElements.length; i++) {
      const el = this.weaponSlotElements[i];
      const slotData = slots[i];
      if (!slotData) {
        el.style.opacity = '0.35';
        continue;
      }

      el.style.opacity = '1.0';
      el.style.borderColor = slotData.isSelected ? '#00e5ff' : 'rgba(0, 230, 118, 0.3)';

      const nameEl = el.querySelector('.slot-name') as HTMLElement;
      const ammoEl = el.querySelector('.slot-ammo') as HTMLElement;
      const barEl = el.querySelector('.slot-reload-bar') as HTMLElement;
      const statusEl = el.querySelector('.slot-status') as HTMLElement;

      if (nameEl) nameEl.textContent = slotData.name;
      if (ammoEl) ammoEl.textContent = `${slotData.ammoCurrent}/${slotData.ammoMax}`;

      if (slotData.reloadTimeRemaining > 0 && slotData.reloadTimeTotal > 0) {
        const reloadRatio = 1.0 - slotData.reloadTimeRemaining / slotData.reloadTimeTotal;
        if (barEl) {
          barEl.style.width = `${Math.round(reloadRatio * 100)}%`;
          barEl.style.background = '#ffab00';
        }
        if (statusEl) {
          statusEl.textContent = `${slotData.reloadTimeRemaining.toFixed(1)}s`;
          statusEl.style.color = '#ffab00';
        }
      } else {
        if (barEl) {
          barEl.style.width = '100%';
          barEl.style.background = '#00e676';
        }
        if (statusEl) {
          statusEl.textContent = 'RDY';
          statusEl.style.color = '#00e676';
        }
      }
    }
  }

  /**
   * Update Dive, Stealth, and ECM ability state and timers.
   */
  public updateAbilities(state: TacticalAbilitiesState): void {
    // 1. Dive State
    const depthNames = ['SURFACE', 'PERISCOPE (-5m)', 'DEEP (-30m)'];
    const currentDepthName = depthNames[state.depthState] ?? 'SURFACE';
    if (state.diveCooldownRemaining > 0) {
      this.diveBtn.innerHTML = `<div>[Q] DIVE</div><div style="font-size: 10px; color: #ffab00;">${state.diveCooldownRemaining.toFixed(1)}s</div>`;
      this.diveBtn.style.borderColor = '#ffab00';
    } else {
      this.diveBtn.innerHTML = `<div>[Q] DIVE</div><div style="font-size: 10px; color: #00e5ff;">${currentDepthName}</div>`;
      this.diveBtn.style.borderColor = '#0288d1';
    }

    // 2. Stealth State
    if (state.isStealthActive) {
      this.stealthBtn.innerHTML = `<div>[E] STEALTH</div><div style="font-size: 10px; color: #00e676;">ON (&le;20kt)</div>`;
      this.stealthBtn.style.borderColor = '#00e676';
      this.stealthBtn.style.background = 'rgba(0, 230, 118, 0.15)';
    } else {
      this.stealthBtn.innerHTML = `<div>[E] STEALTH</div><div style="font-size: 10px; opacity: 0.85;">OFF</div>`;
      this.stealthBtn.style.borderColor = '#546e7a';
      this.stealthBtn.style.background = 'rgba(12, 25, 42, 0.9)';
    }

    // 3. ECM Jammer State
    if (state.ecmActive) {
      this.ecmBtn.innerHTML = `<div>[F] ECM JAM</div><div style="font-size: 10px; color: #e040fb;">ACTIVE (${state.ecmActiveRemaining.toFixed(1)}s)</div>`;
      this.ecmBtn.style.borderColor = '#e040fb';
      this.ecmBtn.style.background = 'rgba(224, 64, 251, 0.2)';
    } else if (state.ecmCooldownRemaining > 0) {
      this.ecmBtn.innerHTML = `<div>[F] ECM JAM</div><div style="font-size: 10px; color: #ffab00;">${state.ecmCooldownRemaining.toFixed(1)}s</div>`;
      this.ecmBtn.style.borderColor = '#ffab00';
      this.ecmBtn.style.background = 'rgba(12, 25, 42, 0.9)';
    } else {
      this.ecmBtn.innerHTML = `<div>[F] ECM JAM</div><div style="font-size: 10px; color: #00e676;">READY</div>`;
      this.ecmBtn.style.borderColor = '#7b1fa2';
      this.ecmBtn.style.background = 'rgba(12, 25, 42, 0.9)';
    }
  }
}
