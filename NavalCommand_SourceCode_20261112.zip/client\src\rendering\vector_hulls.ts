/**
 * 100% Procedural Vector Warship Rendering Pipeline
 * Clean-Room implementation using PixiJS v8.
 * Zero external bitmap sprites / textures!
 */

import { Container, Graphics, Text, TextStyle } from 'pixi.js';
import { ShipClassId } from '../../../common/models/ships.js';
import { normalizeAngle, shortestAngleDiff } from '../../../common/math/vector2.js';


export type CamoType = 'HAZE_GREY' | 'DAZZLE' | 'ARCTIC_SPLINTER' | 'STEALTH_CARBON';

export interface TurretConfig {
  slotId: string;
  offsetX: number;
  offsetY: number;
  baseAngle: number;
  arcCoverage: number;
  caliberMm?: number;
  barrels?: number;
}

export class ProceduralTurret {
  public readonly container: Container;
  public readonly houseGraphics: Graphics;
  public readonly barrelGraphics: Graphics;
  public currentRelativeAngle: number = 0;
  public recoilOffset: number = 0;

  public readonly offsetX: number;
  public readonly offsetY: number;
  public readonly baseAngle: number;
  public readonly arcCoverage: number;
  public readonly caliberMm: number;
  public readonly barrels: number;

  constructor(cfg: TurretConfig) {
    this.container = new Container();
    this.houseGraphics = new Graphics();
    this.barrelGraphics = new Graphics();

    this.offsetX = cfg.offsetX;
    this.offsetY = cfg.offsetY;
    this.baseAngle = cfg.baseAngle;
    this.arcCoverage = cfg.arcCoverage;
    this.caliberMm = cfg.caliberMm ?? 127;
    this.barrels = cfg.barrels ?? (this.caliberMm > 300 ? 3 : this.caliberMm > 150 ? 2 : 1);

    this.container.position.set(this.offsetX, this.offsetY);
    this.container.addChild(this.barrelGraphics);
    this.container.addChild(this.houseGraphics);

    this.renderTurretHouse();
    this.renderBarrels();
  }

  private renderTurretHouse(): void {
    const g = this.houseGraphics;
    g.clear();

    const scale = Math.min(2.0, Math.max(0.6, this.caliberMm / 150));
    const halfWidth = 7 * scale;
    const halfHeight = 6 * scale;

    // Barbette ring underneath
    g.circle(0, 0, halfWidth + 1);
    g.fill({ color: 0x333b47, alpha: 0.9 });
    g.stroke({ color: 0x22262e, width: 1 });

    // Armored turret housing
    g.moveTo(halfWidth * 0.9, -halfHeight * 0.6);
    g.lineTo(halfWidth * 0.4, -halfHeight);
    g.lineTo(-halfWidth * 0.8, -halfHeight * 0.8);
    g.lineTo(-halfWidth, 0);
    g.lineTo(-halfWidth * 0.8, halfHeight * 0.8);
    g.lineTo(halfWidth * 0.4, halfHeight);
    g.lineTo(halfWidth * 0.9, halfHeight * 0.6);
    g.closePath();

    g.fill({ color: 0x546274 });
    g.stroke({ color: 0x20242b, width: 1.5 });

    // Optical rangefinder ears on sides of heavy turrets
    if (this.caliberMm >= 200) {
      g.rect(-halfWidth * 0.2, -halfHeight - 2, 4 * scale, 2);
      g.fill({ color: 0x3a4452 });
      g.rect(-halfWidth * 0.2, halfHeight, 4 * scale, 2);
      g.fill({ color: 0x3a4452 });
    }
  }

  private renderBarrels(): void {
    const g = this.barrelGraphics;
    g.clear();

    const scale = Math.min(2.0, Math.max(0.6, this.caliberMm / 150));
    const barrelLength = (16 + this.caliberMm * 0.05) * scale;
    const barrelThickness = Math.max(1.5, (this.caliberMm / 100) * 1.5);
    const spacing = 4 * scale;

    const startX = this.recoilOffset;

    if (this.barrels === 1) {
      g.rect(startX, -barrelThickness * 0.5, barrelLength, barrelThickness);
      g.fill({ color: 0x1f2329 });
    } else if (this.barrels === 2) {
      g.rect(startX, -spacing * 0.5 - barrelThickness * 0.5, barrelLength, barrelThickness);
      g.fill({ color: 0x1f2329 });
      g.rect(startX, spacing * 0.5 - barrelThickness * 0.5, barrelLength, barrelThickness);
      g.fill({ color: 0x1f2329 });
    } else {
      // Triple turret
      g.rect(startX, -spacing - barrelThickness * 0.5, barrelLength, barrelThickness);
      g.fill({ color: 0x1f2329 });
      g.rect(startX, -barrelThickness * 0.5, barrelLength, barrelThickness);
      g.fill({ color: 0x1f2329 });
      g.rect(startX, spacing - barrelThickness * 0.5, barrelLength, barrelThickness);
      g.fill({ color: 0x1f2329 });
    }
  }

  public fireRecoil(): void {
    this.recoilOffset = -4;
    this.renderBarrels();
  }

  public update(dt: number, targetWorldAngle: number, shipHeading: number): void {
    // Recover from recoil kick
    if (this.recoilOffset < 0) {
      this.recoilOffset = Math.min(0, this.recoilOffset + dt * 25);
      this.renderBarrels();
    }

    // Aim angle in vessel local coordinate space
    const desiredLocalAngle = normalizeAngle(targetWorldAngle - shipHeading);
    const halfArc = this.arcCoverage * 0.5;

    // Check if within mount firing arc relative to baseAngle
    const angleDiffFromBase = shortestAngleDiff(this.baseAngle, desiredLocalAngle);
    let clampedTarget = desiredLocalAngle;

    if (Math.abs(angleDiffFromBase) > halfArc) {
      // Clamp to nearest limit
      clampedTarget = normalizeAngle(this.baseAngle + (angleDiffFromBase > 0 ? halfArc : -halfArc));
    }

    // Smoothly traverse toward target
    const currentAngleDiff = shortestAngleDiff(this.currentRelativeAngle, clampedTarget);
    const maxStep = 2.5 * dt; // traverse speed
    if (Math.abs(currentAngleDiff) <= maxStep) {
      this.currentRelativeAngle = clampedTarget;
    } else {
      this.currentRelativeAngle = normalizeAngle(
        this.currentRelativeAngle + Math.sign(currentAngleDiff) * maxStep
      );
    }

    this.container.rotation = this.currentRelativeAngle;
  }
}

export class ProceduralVessel {
  public readonly container: Container;
  public readonly hullGraphics: Graphics;
  public readonly camoGraphics: Graphics;
  public readonly superstructureGraphics: Graphics;
  public readonly overheadUI: Container;
  public readonly hpBarGraphics: Graphics;
  public readonly nameLabel: Text;

  public readonly shipClass: ShipClassId;
  public readonly lengthMeters: number;
  public readonly beamMeters: number;
  public readonly camoType: CamoType;
  public readonly turrets: ProceduralTurret[] = [];

  constructor(
    shipClass: ShipClassId,
    lengthMeters: number,
    beamMeters: number,
    camoType: CamoType = 'HAZE_GREY',
    turretConfigs: TurretConfig[] = []
  ) {
    this.shipClass = shipClass;
    this.lengthMeters = lengthMeters;
    this.beamMeters = beamMeters;
    this.camoType = camoType;

    this.container = new Container();
    this.hullGraphics = new Graphics();
    this.camoGraphics = new Graphics();
    this.superstructureGraphics = new Graphics();
    this.overheadUI = new Container();
    this.hpBarGraphics = new Graphics();

    const style = new TextStyle({
      fontFamily: 'monospace',
      fontSize: 10,
      fill: 0xffffff,
      align: 'center',
    });
    this.nameLabel = new Text({ text: '', style });
    this.nameLabel.anchor.set(0.5, 1.0);
    this.nameLabel.position.set(0, -this.beamMeters * 0.8 - 14);

    this.hpBarGraphics.position.set(0, -this.beamMeters * 0.8 - 8);

    this.overheadUI.addChild(this.hpBarGraphics);
    this.overheadUI.addChild(this.nameLabel);

    // Layer stack
    this.container.addChild(this.hullGraphics);
    this.container.addChild(this.camoGraphics);
    this.container.addChild(this.superstructureGraphics);

    // Mount turrets
    for (const cfg of turretConfigs) {
      const turret = new ProceduralTurret(cfg);
      this.turrets.push(turret);
      this.container.addChild(turret.container);
    }

    this.container.addChild(this.overheadUI);

    this.drawHull();
    this.drawCamo();
    this.drawSuperstructure();
    this.updateHpBar(1.0);
  }

  private drawHull(): void {
    const g = this.hullGraphics;
    g.clear();

    const L = this.lengthMeters;
    const halfL = L * 0.5;
    const halfB = this.beamMeters * 0.5;

    // Base colors
    let hullColor = 0x4f5b66; // Haze grey
    let deckColor = 0x3b424c;
    const waterlineTrim = 0x8a2020; // Red anti-fouling trim

    if (this.shipClass === 'TACTICAL_SUPPORT') {
      hullColor = 0xe8e8f0; // White hospital ship
      deckColor = 0xcfd4da;
    } else if (this.camoType === 'STEALTH_CARBON') {
      hullColor = 0x1f2326;
      deckColor = 0x181a1c;
    }

    // 1. Waterline outer contour
    g.moveTo(halfL + 2, 0);
    g.bezierCurveTo(halfL * 0.6, -halfB - 2, -halfL * 0.5, -halfB - 2, -halfL - 2, -halfB * 0.7);
    g.lineTo(-halfL - 2, halfB * 0.7);
    g.bezierCurveTo(-halfL * 0.5, halfB + 2, halfL * 0.6, halfB + 2, halfL + 2, 0);
    g.closePath();
    g.fill({ color: waterlineTrim, alpha: 0.8 });

    // 2. Main Hull deck polygon according to vessel class
    switch (this.shipClass) {
      case 'COASTAL_PATROL': {
        // Fast wedge hull
        g.moveTo(halfL, 0);
        g.lineTo(halfL * 0.3, -halfB);
        g.lineTo(-halfL, -halfB * 0.9);
        g.lineTo(-halfL, halfB * 0.9);
        g.lineTo(halfL * 0.3, halfB);
        g.closePath();
        break;
      }
      case 'SUBMARINE': {
        // Teardrop cylindrical submarine hull
        g.moveTo(halfL, 0);
        g.bezierCurveTo(halfL, -halfB, halfL * 0.3, -halfB, -halfL * 0.5, -halfB * 0.75);
        g.lineTo(-halfL, -halfB * 0.3);
        g.lineTo(-halfL, halfB * 0.3);
        g.lineTo(-halfL * 0.5, halfB * 0.75);
        g.bezierCurveTo(halfL * 0.3, halfB, halfL, halfB, halfL, 0);
        g.closePath();
        break;
      }
      case 'AIRCRAFT_CARRIER': {
        // Broad asymmetric flight deck
        g.moveTo(halfL, -halfB * 0.4);
        g.lineTo(halfL * 0.8, -halfB);
        g.lineTo(-halfL * 0.9, -halfB);
        g.lineTo(-halfL, -halfB * 0.5);
        g.lineTo(-halfL, halfB * 0.9);
        g.lineTo(halfL * 0.7, halfB);
        g.lineTo(halfL, halfB * 0.4);
        g.closePath();
        break;
      }
      case 'BATTLESHIP': {
        // Flared bow, heavy citadel flare
        g.moveTo(halfL, 0);
        g.bezierCurveTo(halfL * 0.7, -halfB * 0.8, halfL * 0.2, -halfB * 1.05, -halfL * 0.4, -halfB);
        g.lineTo(-halfL, -halfB * 0.7);
        g.lineTo(-halfL, halfB * 0.7);
        g.lineTo(-halfL * 0.4, halfB);
        g.bezierCurveTo(halfL * 0.2, halfB * 1.05, halfL * 0.7, halfB * 0.8, halfL, 0);
        g.closePath();
        break;
      }
      case 'DREDGER_ICEBREAKER': {
        // Spoon-shaped reinforced icebreaker bow
        g.moveTo(halfL, -halfB * 0.6);
        g.lineTo(halfL * 0.4, -halfB);
        g.lineTo(-halfL, -halfB);
        g.lineTo(-halfL, halfB);
        g.lineTo(halfL * 0.4, halfB);
        g.lineTo(halfL, halfB * 0.6);
        g.closePath();
        break;
      }
      default: {
        // DESTROYER & CRUISER: sleek forecastle, sharp stem
        g.moveTo(halfL, 0);
        g.bezierCurveTo(halfL * 0.6, -halfB, -halfL * 0.4, -halfB, -halfL, -halfB * 0.8);
        g.lineTo(-halfL, halfB * 0.8);
        g.bezierCurveTo(-halfL * 0.4, halfB, halfL * 0.6, halfB, halfL, 0);
        g.closePath();
        break;
      }
    }

    g.fill({ color: hullColor });
    g.stroke({ color: 0x1f2429, width: 1.5 });

    // Inner deck surface
    const innerL = halfL * 0.85;
    const innerB = halfB * 0.75;
    g.rect(-innerL * 0.7, -innerB, innerL * 1.4, innerB * 2);
    g.fill({ color: deckColor, alpha: 0.6 });
  }

  private drawCamo(): void {
    const g = this.camoGraphics;
    g.clear();

    const halfL = this.lengthMeters * 0.5;
    const halfB = this.beamMeters * 0.5;

    if (this.camoType === 'DAZZLE') {
      // High-contrast alternating geometric polygons
      const colors = [0x11161d, 0xf0f3f6, 0x2e4158];
      const step = this.lengthMeters / 7;
      for (let i = 0; i < 7; i++) {
        const x = -halfL + i * step;
        g.poly([
          x, -halfB,
          x + step * 0.7, -halfB,
          x + step * 0.3, halfB,
          x - step * 0.3, halfB,
        ]);
        g.fill({ color: colors[i % colors.length], alpha: 0.55 });
      }
    } else if (this.camoType === 'ARCTIC_SPLINTER') {
      // Sharp cyan / white / dark blue angular shards
      const colors = [0xffffff, 0x00bcd4, 0x1a365d];
      for (let i = 0; i < 8; i++) {
        const x = -halfL + (i / 8) * this.lengthMeters;
        const offset = (i % 2 === 0 ? 1 : -1) * halfB * 0.6;
        g.poly([
          x, offset,
          x + 14, offset - halfB * 0.4,
          x + 8, offset + halfB * 0.4,
        ]);
        g.fill({ color: colors[i % colors.length], alpha: 0.6 });
      }
    } else if (this.camoType === 'STEALTH_CARBON') {
      // Subtle hexagon / grid panels
      g.rect(-halfL * 0.7, -halfB * 0.8, this.lengthMeters * 0.7, this.beamMeters * 1.6);
      g.stroke({ color: 0x323a42, width: 1, alpha: 0.4 });
    }
  }

  private drawSuperstructure(): void {
    const g = this.superstructureGraphics;
    g.clear();

    const halfL = this.lengthMeters * 0.5;
    const halfB = this.beamMeters * 0.5;

    switch (this.shipClass) {
      case 'SUBMARINE': {
        // Conning tower sail & periscope mast
        g.rect(-halfL * 0.05, -halfB * 0.35, halfL * 0.3, halfB * 0.7);
        g.fill({ color: 0x22262a });
        g.stroke({ color: 0x111417, width: 1 });
        // Dive planes
        g.rect(halfL * 0.05, -halfB * 0.65, 5, halfB * 1.3);
        g.fill({ color: 0x333b42 });
        break;
      }
      case 'AIRCRAFT_CARRIER': {
        // Flight deck runway lines
        g.moveTo(-halfL * 0.8, -halfB * 0.1);
        g.lineTo(halfL * 0.8, -halfB * 0.1);
        g.stroke({ color: 0xffe600, width: 2, alpha: 0.8 });

        // Island superstructure on starboard
        g.rect(0, halfB * 0.5, halfL * 0.35, halfB * 0.4);
        g.fill({ color: 0x546274 });
        g.stroke({ color: 0x1f242a, width: 1.5 });
        break;
      }
      case 'TACTICAL_SUPPORT': {
        // Red cross insignia on forward deck
        const crossSize = halfB * 0.8;
        g.rect(-crossSize * 0.25, -crossSize, crossSize * 0.5, crossSize * 2);
        g.fill({ color: 0xd32f2f });
        g.rect(-crossSize, -crossSize * 0.25, crossSize * 2, crossSize * 0.5);
        g.fill({ color: 0xd32f2f });

        // Midship bridge
        g.rect(-halfL * 0.2, -halfB * 0.5, halfL * 0.4, halfB);
        g.fill({ color: 0xffffff });
        g.stroke({ color: 0x90a4ae, width: 1 });
        break;
      }
      default: {
        // Bridge conning tower and radar mast
        g.rect(-halfL * 0.2, -halfB * 0.5, halfL * 0.35, halfB);
        g.fill({ color: 0x39434e });
        g.stroke({ color: 0x1a1e24, width: 1 });

        // Radar lattice cross
        g.moveTo(-halfL * 0.05, -halfB * 0.6);
        g.lineTo(-halfL * 0.05, halfB * 0.6);
        g.stroke({ color: 0xffcc00, width: 1.5 });
        break;
      }
    }
  }

  public updateHpBar(ratio: number): void {
    const g = this.hpBarGraphics;
    g.clear();

    const barWidth = Math.max(30, this.lengthMeters * 0.6);
    const barHeight = 4;
    const halfW = barWidth * 0.5;

    // Background
    g.rect(-halfW, 0, barWidth, barHeight);
    g.fill({ color: 0x111111, alpha: 0.7 });

    // Health fill
    const fillWidth = Math.max(0, Math.min(1.0, ratio)) * barWidth;
    let hpColor = 0x00e676; // Green
    if (ratio < 0.3) hpColor = 0xff1744; // Red
    else if (ratio < 0.6) hpColor = 0xffea00; // Yellow

    g.rect(-halfW, 0, fillWidth, barHeight);
    g.fill({ color: hpColor });
  }

  public setDepth(depthState: number): void {
    if (depthState === 0) {
      // Surface
      this.container.alpha = 1.0;
      this.container.tint = 0xffffff;
    } else if (depthState === 1) {
      // Periscope
      this.container.alpha = 0.65;
      this.container.tint = 0x64b5f6;
    } else {
      // Deep
      this.container.alpha = 0.25;
      this.container.tint = 0x1565c0;
    }
  }

  public setPlayerName(name: string, isFriendly: boolean = false): void {
    this.nameLabel.text = name;
    this.nameLabel.style.fill = isFriendly ? 0x64ffda : 0xffffff;
  }

  public update(dt: number, aimAngleWorld: number): void {
    for (const turret of this.turrets) {
      turret.update(dt, aimAngleWorld, this.container.rotation);
    }
  }
}
