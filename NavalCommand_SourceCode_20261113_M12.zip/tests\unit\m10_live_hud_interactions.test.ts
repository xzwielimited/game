/**
 * Milestone M10 Unit, Boundary & Adversarial Test Suite:
 * Authentic mk48.io Live HUD Synchronization (XP Progress & Auto-Unlock,
 * Real-Time Leaderboard, Fleet Join/Leave with 15s NAP, Live Chat Sanitization,
 * Lobby Mode Selection, Input Focus Guard & Special Slot [4] Weapons).
 */

import { describe, it, expect, beforeEach } from 'vitest';
import { NavalCommandApp, MK48_FLEET_PRESETS } from '../../client/src/app.js';

function createMockElement(tag: string = 'div'): any {
  const styleObj: any = {};
  Object.defineProperty(styleObj, 'cssText', {
    set(txt: string) {
      txt.split(';').forEach((decl) => {
        const parts = decl.split(':');
        if (parts.length >= 2) {
          const k = parts[0].trim();
          const v = parts.slice(1).join(':').trim();
          if (k) styleObj[k] = v;
        }
      });
    },
    get() {
      return '';
    },
  });
  const listeners: Record<string, Function[]> = {};
  const mockCtx = {
    clearRect: () => {},
    beginPath: () => {},
    arc: () => {},
    fill: () => {},
    stroke: () => {},
    moveTo: () => {},
    lineTo: () => {},
    closePath: () => {},
    save: () => {},
    restore: () => {},
    translate: () => {},
    rotate: () => {},
    scale: () => {},
    setLineDash: () => {},
    fillText: () => {},
    strokeText: () => {},
    measureText: () => ({ width: 0 }),
    fillStyle: '',
    strokeStyle: '',
    lineWidth: 1,
  };
  const mockEl: any = {
    tagName: tag.toUpperCase(),
    className: '',
    style: styleObj,
    children: [],
    value: 'Guestbound',
    appendChild: (child: any) => {
      mockEl.children.push(child);
      mockEl.innerHTML += child.outerHTML || child.innerHTML || '';
      return child;
    },
    removeChild: () => {},
    addEventListener: (ev: string, cb: Function) => {
      listeners[ev] = listeners[ev] || [];
      listeners[ev].push(cb);
    },
    dispatchEvent: (event: any) => {
      const cbs = listeners[event.type] || [];
      for (const cb of cbs) cb(event);
      return true;
    },
    querySelector: (sel: string) => {
      const cls = sel.startsWith('.') ? sel.slice(1) : sel;
      let child = mockEl.children.find((c: any) => c.className === cls);
      if (!child) {
        child = createMockElement('div');
        child.className = cls;
        mockEl.children.push(child);
      }
      return child;
    },
    querySelectorAll: () => [],
    classList: { add: () => {}, remove: () => {} },
    innerHTML: '',
    textContent: '',
    getContext: () => mockCtx,
    getBoundingClientRect: () => ({ left: 0, top: 0, width: 1024, height: 768 }),
    width: 1024,
    height: 768,
    blur: () => {},
  };
  return mockEl;
}

const windowListeners: Record<string, Function[]> = {};
(globalThis as any).document = {
  activeElement: null,
  createElement: (tag: string) => createMockElement(tag),
  getElementById: () => createMockElement(),
  body: createMockElement('body'),
};
(globalThis as any).window = {
  innerWidth: 1024,
  innerHeight: 768,
  addEventListener: (ev: string, cb: Function) => {
    windowListeners[ev] = windowListeners[ev] || [];
    windowListeners[ev].push(cb);
  },
  removeEventListener: () => {},
};
(globalThis as any).requestAnimationFrame = () => 0;

describe('Milestone M10: Authentic mk48.io Live HUD, Fleets, Chat & Progression', () => {
  let root: any;
  let app: NavalCommandApp;

  beforeEach(async () => {
    for (const k of Object.keys(windowListeners)) {
      delete windowListeners[k];
    }
    (globalThis as any).document.activeElement = null;
    root = createMockElement('div');
    app = new NavalCommandApp(root);
    app.renderer.init = async () => {};
    await app.init(root);
  });

  describe('1. Live XP Progression & Automatic Ship Tier Unlocks', () => {
    it('positions tactical top bar at top: 28px so it never overlaps the top-0 mk48 XP bar', () => {
      const topBar = (app.hud as any).topBar;
      expect(topBar.style.top).toBe('28px');
    });

    it('computes accurate XP progress percentage and unlocks vessels as player levels up to Tier 10', () => {
      const player = app.localServer.getVessel(app.playerVesselId)!;

      // Start at 0 XP -> Tier 1 (0/60 XP to Tier 2)
      player.accumulatedXp = 0;
      const p0 = app.computePlayerXpProgress();
      expect(p0.currentTier).toBe(1);
      expect(p0.nextTier).toBe(2);
      expect(p0.progressPct).toBe(0);

      // 30 XP -> 50% toward Tier 2 (threshold 60 XP)
      player.accumulatedXp = 30;
      const pHalf = app.computePlayerXpProgress();
      expect(pHalf.currentTier).toBe(1);
      expect(pHalf.progressPct).toBe(50);

      // 630 XP -> Tier 7 unlocked!
      player.accumulatedXp = 630;
      const p7 = app.computePlayerXpProgress();
      expect(p7.currentTier).toBe(7);
      expect(p7.nextTier).toBe(8);
      expect(app.hud.menus.unlockedHulls.has('bismarck_bb')).toBe(true);

      // Extreme XP boundary (99,999 XP) -> capped cleanly at Tier 10 & 100%
      player.accumulatedXp = 99999;
      const pMax = app.computePlayerXpProgress();
      expect(pMax.currentTier).toBe(10);
      expect(pMax.nextTier).toBe(10);
      expect(pMax.progressPct).toBe(100);
      expect(app.hud.menus.unlockedHulls.has('yamato_bb')).toBe(true);
      expect(app.hud.menus.unlockedHulls.has('akula_ssn')).toBe(true);
    });

    it('handles negative XP boundary safely by clamping to 0', () => {
      const player = app.localServer.getVessel(app.playerVesselId)!;
      player.accumulatedXp = -500;
      const prog = app.computePlayerXpProgress();
      expect(prog.currentXp).toBe(0);
      expect(prog.currentTier).toBe(1);
      expect(prog.progressPct).toBe(0);
    });
  });

  describe('2. Live Sorted Leaderboard & Fleet Tags', () => {
    it('sorts all vessels descending by score and formats fleet tags accurately', () => {
      const player = app.localServer.getVessel(app.playerVesselId)!;
      player.name = 'NavalHero';
      player.fleetId = 2; // Ae VN
      player.score = 9999;

      const board = app.getLiveLeaderboard();
      expect(board.length).toBeGreaterThanOrEqual(13);
      expect(board[0].vesselId).toBe(player.id);
      expect(board[0].rank).toBe(1);
      expect(board[0].isPlayer).toBe(true);
      expect(board[0].fleetTag).toBe('[Ae VN]');
      expect(board[0].score).toBe(9999);

      // Verify descending sort order invariant across all entries
      for (let i = 1; i < board.length; i++) {
        expect(board[i - 1].score).toBeGreaterThanOrEqual(board[i].score);
      }
    });
  });

  describe('3. Fleet Join/Leave & 15-Second Non-Aggression Pact (NAP)', () => {
    it('joins a fleet, blocks friendly fire, and enforces 15s NAP upon leaving', () => {
      const player = app.localServer.getVessel(app.playerVesselId)!;
      player.spawnShieldRemaining = 0;

      // Find Mercy_Support (on fleet 1: USSR)
      const mercy = app.localServer.getAllVessels().find((v) => v.name === 'Mercy_Support')!;
      expect(mercy).toBeDefined();
      mercy.spawnShieldRemaining = 0;
      expect(mercy.fleetId).toBe(1);

      // Player starts on fleet 1 -> cannot damage fleetmate Mercy
      expect(player.fleetId).toBe(1);
      expect(app.localServer.canDamage(player.id, mercy.id)).toBe(false);

      // Player clicks 'Rời đội' on fleet 1 -> leaves fleet (fleetId = 0) and triggers 15s NAP
      const leaveRes = app.joinOrLeaveFleet(1);
      expect(leaveRes.fleetId).toBe(0);
      expect(leaveRes.napAppliedCount).toBeGreaterThanOrEqual(1);

      // During 15s NAP, mutual damage is strictly blocked even though fleetId is now 0!
      expect(app.localServer.canDamage(player.id, mercy.id)).toBe(false);
      expect(app.localServer.canDamage(mercy.id, player.id)).toBe(false);

      // Player joins fleet 2 ('Ae VN')
      const joinAeVn = app.joinOrLeaveFleet(2);
      expect(joinAeVn.fleetId).toBe(2);
      expect(MK48_FLEET_PRESETS.find((f) => f.fleetId === 2)?.name).toBe('Ae VN');
    });
  });

  describe('4. Live Chat Box, Sanitization & Input Focus Guard', () => {
    it('accepts valid chat messages, sanitizes HTML brackets, and caps history at 6 items', () => {
      expect(app.sendChatMessage('   ')).toBe(false);
      expect(app.sendChatMessage('<>')).toBe(false);

      const ok = app.sendChatMessage('<b>Tập hợp tại giàn khoan Alpha!</b>');
      expect(ok).toBe(true);
      const lastMsg = app.chatMessages[app.chatMessages.length - 1];
      expect(lastMsg.text).toBe('bTập hợp tại giàn khoan Alpha!/b');

      // Push 10 messages and verify history stays capped at 6
      for (let i = 1; i <= 10; i++) {
        app.sendChatMessage(`Tin nhắn chiến thuật số ${i}`);
      }
      expect(app.chatMessages.length).toBe(6);
      expect(app.chatMessages[app.chatMessages.length - 1].text).toBe('Tin nhắn chiến thuật số 10');
    });

    it('blocks ship hotkeys when an INPUT element is focused in document.activeElement', () => {
      const initialSlot = (app as any).selectedWeaponSlot;
      (globalThis as any).document.activeElement = { tagName: 'INPUT', blur: () => {} };

      // Simulate pressing '2' and 'w' while typing in chat input
      const keydownHandlers = windowListeners['keydown'] || [];
      for (const cb of keydownHandlers) {
        cb({ key: '2', preventDefault: () => {} });
        cb({ key: 'w', preventDefault: () => {} });
      }

      // Weapon slot and keysPressed must remain unchanged!
      expect((app as any).selectedWeaponSlot).toBe(initialSlot);
      expect((app as any).keysPressed.has('w')).toBe(false);

      // Unfocus input -> hotkeys work normally again
      (globalThis as any).document.activeElement = null;
      for (const cb of keydownHandlers) {
        cb({ key: '2', preventDefault: () => {} });
      }
      expect((app as any).selectedWeaponSlot).toBe(1);
    });
  });

  describe('5. Lobby Mode Selection & Special Weapon Slot [4] Support', () => {
    it('switches game modes via selectLobbyMode', () => {
      app.selectLobbyMode('KOTH_CONVOY');
      expect(app.modeController.currentMode).toBe('KOTH_CONVOY');

      app.selectLobbyMode('DUEL_ARENA');
      expect(app.modeController.currentMode).toBe('DUEL_ARENA');

      app.selectLobbyMode('FFA_SANDBOX');
      expect(app.modeController.currentMode).toBe('FFA_SANDBOX');
    });

    it('fires AIRCRAFT_SQUADRON and DREDGER_TOOL mounts when Slot [4] is selected', () => {
      // Respawn player with Essex Aircraft Carrier
      app.respawnPlayerWithHull('essex_cv');
      const player = app.localServer.getVessel(app.playerVesselId)!;
      expect(player.shipDef.id).toBe('essex_cv');

      const hasAircraft = player.mounts.some((m) => m.category === 'AIRCRAFT_SQUADRON');
      expect(hasAircraft).toBe(true);

      (app as any).selectedWeaponSlot = 3; // Slot [4]
      const beforeProj = app.localServer.getAllProjectiles().length;
      app.fireSelectedWeaponSlot();
      expect(app.localServer.getAllProjectiles().length).toBeGreaterThan(beforeProj);
    });
  });
});
