/**
 * Milestone M12 Unit, Boundary & Adversarial Test Suite:
 * Authentic mk48.io Graphics, Quick Top Upgrade Bar, Custom Fleet Input,
 * Incoming Threat Indicators, Compact Minimal HUD & Ocean Shader Rendering.
 */

import { describe, it, expect, beforeEach } from 'vitest';
import { NavalCommandApp } from '../../client/src/app.js';
import { PixiRenderer } from '../../client/src/rendering/pixi_renderer.js';

function createMockElement(tag: string = 'div'): any {
  const styleObj: any = {};
  Object.defineProperty(styleObj, 'cssText', {
    set(txt: string) {
      txt.split(';').forEach((decl) => {
        const parts = decl.split(':');
        if (parts.length >= 2) {
          const k = parts[0].trim();
          const v = parts.slice(1).join(':').trim();
          if (k) styleObj[k] = v;
        }
      });
    },
    get() {
      return '';
    },
  });
  const listeners: Record<string, Function[]> = {};
  const mockCtx = {
    clearRect: () => {},
    beginPath: () => {},
    arc: () => {},
    fill: () => {},
    stroke: () => {},
    moveTo: () => {},
    lineTo: () => {},
    closePath: () => {},
    save: () => {},
    restore: () => {},
    translate: () => {},
    rotate: () => {},
    scale: () => {},
    setLineDash: () => {},
    fillText: () => {},
    strokeText: () => {},
    measureText: () => ({ width: 0 }),
    fillStyle: '',
    strokeStyle: '',
    lineWidth: 1,
  };
  const mockEl: any = {
    tagName: tag.toUpperCase(),
    className: '',
    style: styleObj,
    children: [],
    value: 'Guestbound',
    appendChild: (child: any) => {
      mockEl.children.push(child);
      mockEl.innerHTML += child.outerHTML || child.innerHTML || '';
      return child;
    },
    removeChild: () => {},
    addEventListener: (ev: string, cb: Function) => {
      listeners[ev] = listeners[ev] || [];
      listeners[ev].push(cb);
    },
    dispatchEvent: (event: any) => {
      const cbs = listeners[event.type] || [];
      for (const cb of cbs) cb(event);
      return true;
    },
    querySelector: (sel: string) => {
      const cls = sel.startsWith('.') ? sel.slice(1) : sel;
      let child = mockEl.children.find((c: any) => c.className === cls);
      if (!child) {
        child = createMockElement('div');
        child.className = cls;
        mockEl.children.push(child);
      }
      return child;
    },
    querySelectorAll: () => [],
    classList: { add: () => {}, remove: () => {} },
    innerHTML: '',
    textContent: '',
    getContext: () => mockCtx,
    getBoundingClientRect: () => ({ left: 0, top: 0, width: 1024, height: 768 }),
    width: 1024,
    height: 768,
    blur: () => {},
  };
  return mockEl;
}

(globalThis as any).document = {
  activeElement: null,
  createElement: (tag: string) => createMockElement(tag),
  getElementById: () => createMockElement(),
  body: createMockElement('body'),
};
(globalThis as any).window = {
  innerWidth: 1024,
  innerHeight: 768,
  addEventListener: () => {},
  removeEventListener: () => {},
};
(globalThis as any).requestAnimationFrame = () => 0;

describe('Milestone M12: Authentic mk48.io Graphics, Upgrade Bar, Fleets & Threat Indicators', () => {
  let root: any;
  let app: NavalCommandApp;

  beforeEach(async () => {
    root = createMockElement('div');
    app = new NavalCommandApp(root);
    app.renderer.init = async () => {};
    await app.init(root);
  });

  describe('1. Quick Top Ship Upgrade Bar & Top-Down SVG Previews', () => {
    it('generates valid SVG top-down warship silhouettes for all 8 ship classes', () => {
      const classes = [
        'COASTAL_PATROL',
        'DESTROYER',
        'CRUISER',
        'BATTLESHIP',
        'AIRCRAFT_CARRIER',
        'SUBMARINE',
        'TACTICAL_SUPPORT',
        'DREDGER_ICEBREAKER',
      ];
      for (const cls of classes) {
        const svg = app.getShipTopDownSvg(cls);
        expect(svg).toContain('<svg');
        expect(svg).toContain('</svg>');
      }
    });

    it('returns sorted unlocked vessels and switches player hull via selectQuickUpgradeHull', () => {
      const available = app.getAvailableUpgradeShips();
      expect(available.length).toBeGreaterThanOrEqual(2);
      for (let i = 1; i < available.length; i++) {
        expect(available[i].tier).toBeGreaterThanOrEqual(available[i - 1].tier);
      }

      // Switch to unlocked Tier 1 PT-109 patrol boat
      const switched = app.selectQuickUpgradeHull('pt_boat_109');
      expect(switched).toBe(true);
      expect(app.localServer.getVessel(app.playerVesselId)?.shipDef.id).toBe('pt_boat_109');

      // Boundary: locked Tier 10 Yamato cannot be quick-selected until unlocked, and invalid IDs fail safely
      expect(app.selectQuickUpgradeHull('yamato_bb')).toBe(false);
      expect(app.selectQuickUpgradeHull('nonexistent_ship')).toBe(false);
    });
  });

  describe('2. Custom Fleet Input, Sanitization & 15s NAP Enforcement', () => {
    it('rejects empty or tag-only fleet names safely', () => {
      expect(app.createOrJoinCustomFleet('   ').fleetId).toBe(0);
      expect(app.createOrJoinCustomFleet('<>').fleetId).toBe(0);
    });

    it('creates a custom sanitized fleet, enforces 15s NAP with prior fleetmates, and reflects on leaderboard', () => {
      const player = app.localServer.getVessel(app.playerVesselId)!;
      player.spawnShieldRemaining = 0;

      const mercy = app.localServer.getAllVessels().find((v) => v.name === 'Mercy_Support')!;
      expect(mercy.fleetId).toBe(1);
      mercy.spawnShieldRemaining = 0;

      const res = app.createOrJoinCustomFleet('<b>AlphaVN</b>');
      expect(res.fleetId).toBeGreaterThan(5);
      expect(res.fleetName).toBe('bAlphaVN/b');
      expect(res.napAppliedCount).toBeGreaterThanOrEqual(1);
      expect(player.fleetId).toBe(res.fleetId);

      // 15s Non-Aggression Pact protects former fleetmate Mercy immediately after switch
      expect(app.localServer.canDamage(player.id, mercy.id)).toBe(false);

      // Leaderboard shows the new custom fleet tag next to the player
      const playerEntry = app.getLiveLeaderboard().find((e) => e.isPlayer);
      expect(playerEntry?.fleetTag).toBe('[bAlphaVN/b]');
    });
  });

  describe('3. Incoming Threat Warning Indicators', () => {
    it('detects hostile torpedoes and nearby enemy ships while ignoring allied and distant targets', () => {
      const player = app.localServer.getVessel(app.playerVesselId)!;
      player.physics.position = { x: 0, y: 0 };

      // Move enemy bot 10 (PT-109, fleet 2) into 400m proximity and fire a hostile torpedo toward player
      const enemyBot = app.localServer.getVessel(10)!;
      enemyBot.physics.position = { x: 400, y: 0 };
      const enemyTorpIdx = enemyBot.mounts.findIndex(
        (m) => m.category === 'TORPEDO' || m.category === 'ROCKET_TORPEDO'
      );
      expect(enemyTorpIdx).toBeGreaterThanOrEqual(0);
      expect(app.localServer.fireMount(enemyBot.id, enemyTorpIdx, { x: 0, y: 0 })).toBe(true);

      // Fire player's own torpedo (should be ignored in threats!)
      const playerTorpIdx = player.mounts.findIndex(
        (m) => m.category === 'TORPEDO' || m.category === 'ROCKET_TORPEDO'
      );
      expect(playerTorpIdx).toBeGreaterThanOrEqual(0);
      app.localServer.fireMount(player.id, playerTorpIdx, { x: 0, y: 150 });

      const threats = app.computeIncomingThreats();
      expect(threats.some((t) => t.kind === 'TORPEDO')).toBe(true);
      expect(threats.some((t) => t.kind === 'VESSEL' && Math.round(t.distance) === 400)).toBe(true);
      // Player's own projectile at ~0..50m should never appear as a threat
      expect(threats.every((t) => t.distance > 150)).toBe(true);

      // Rendering threat indicators with valid + non-finite inputs never throws
      expect(() => {
        app.renderer.renderThreatIndicators(0, 0, [
          ...threats,
          { x: NaN, y: Infinity, kind: 'TORPEDO', distance: 100 },
        ]);
        app.renderer.renderThreatIndicators(0, 0, []);
      }).not.toThrow();
    });
  });

  describe('4. Compact Minimal HUD Toggle & Pixel Renderer Enhancements', () => {
    it('toggles between full tactical HUD and clean mk48.io minimal HUD', () => {
      expect(app.isCompactMinimalHud).toBe(false);
      expect((app.hud as any).topBar.style.display).not.toBe('none');

      const minimized = app.toggleCompactMinimalHud();
      expect(minimized).toBe(true);
      expect((app.hud as any).topBar.style.display).toBe('none');
      expect(app.hud.weaponControls.container.style.display).toBe('none');

      const restored = app.toggleCompactMinimalHud();
      expect(restored).toBe(false);
      expect((app.hud as any).topBar.style.display).toBe('flex');
      expect(app.hud.weaponControls.container.style.display).toBe('flex');
    });

    it('renders oil barrels, crates, two-tone torpedoes, and contact mines safely', () => {
      const renderer = new PixiRenderer();
      expect(() => {
        renderer.renderCrates([
          { x: 50, y: 50, radius: 10, type: 'STEEL' },
          { x: 90, y: 90, radius: 10, type: 'WOODEN' },
          { x: 130, y: 130, radius: 12, type: 'MILITARY_CHEST' },
        ]);
        renderer.renderProjectiles([
          { x: 0, y: 0, heading: 0.25, type: 'TORPEDO' },
          { x: 20, y: 20, heading: 0, type: 'MINE' },
        ]);
      }).not.toThrow();
    });
  });
});
