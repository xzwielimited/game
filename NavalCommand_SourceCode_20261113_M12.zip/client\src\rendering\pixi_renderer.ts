/**
 * PixiJS v8 Application Renderer & Camera Viewport
 * Clean-Room implementation for NavalCommand.io
 * Coordinates vibrant marine ocean background, dynamic multi-harmonic sine swell waves,
 * terrain layers, vector vessels, wakes, torpedo indicators, and sensor overlays.
 */

import { Application, Container, Graphics } from 'pixi.js';
import { WakeFX } from './wake_fx.js';
import { VectorParticleSystem } from './particle_system.js';
import { SensorOverlays } from './sensor_overlays.js';
import { ProceduralVessel } from './vector_hulls.js';

export class PixiRenderer {
  public app: Application | null = null;
  public readonly worldContainer: Container;

  // Scene layer hierarchy (Tactical underlay sits BELOW surfaceLayer to guarantee 100% clean hulls)
  public readonly oceanLayer: Container;
  public readonly terrainLayer: Container;
  public readonly wakeLayer: Container;
  public readonly sensorLayer: Container;       // Layer 3: Tactical underlay (BELOW surfaceLayer)
  public readonly submergedLayer: Container;    // Layer 4: Submarines
  public readonly surfaceLayer: Container;      // Layer 5: Surface Warships (Unobscured!)
  public readonly projectilesLayer: Container;  // Layer 6: Torpedoes, Shells, Missiles
  public readonly particleLayer: Container;     // Layer 7: Explosions & Splashes
  public readonly worldUILayer: Container;      // Layer 8: World UI

  // Subsystems
  public readonly wakeFX: WakeFX;
  public readonly particles: VectorParticleSystem;
  public readonly sensorOverlays: SensorOverlays;

  // Procedural background & waves
  private oceanGridGraphics: Graphics;
  private oceanWaveGraphics: Graphics;
  private crateGraphics: Graphics;
  private projectileGraphics: Graphics;
  private threatGraphics: Graphics;
  private elapsedTimeSec: number = 0;

  // Camera state (Default zoom ~1.85 so warships are crisp, large and prominent)
  public cameraX: number = 0;
  public cameraY: number = 0;
  public zoom: number = 1.85;
  public minZoom: number = 0.4;
  public maxZoom: number = 3.2;

  private isInitialized: boolean = false;

  constructor() {
    this.worldContainer = new Container();

    this.oceanLayer = new Container();
    this.terrainLayer = new Container();
    this.wakeLayer = new Container();
    this.sensorLayer = new Container();
    this.submergedLayer = new Container();
    this.surfaceLayer = new Container();
    this.projectilesLayer = new Container();
    this.particleLayer = new Container();
    this.worldUILayer = new Container();

    this.wakeFX = new WakeFX();
    this.particles = new VectorParticleSystem();
    this.sensorOverlays = new SensorOverlays();

    this.oceanGridGraphics = new Graphics();
    this.oceanWaveGraphics = new Graphics();
    this.crateGraphics = new Graphics();
    this.projectileGraphics = new Graphics();
    this.threatGraphics = new Graphics();

    this.oceanLayer.addChild(this.oceanGridGraphics);
    this.oceanLayer.addChild(this.oceanWaveGraphics);
    this.wakeLayer.addChild(this.crateGraphics);
    this.wakeLayer.addChild(this.wakeFX.container);
    this.sensorLayer.addChild(this.sensorOverlays.container);
    this.projectilesLayer.addChild(this.projectileGraphics);
    this.particleLayer.addChild(this.particles.container);
    this.worldUILayer.addChild(this.threatGraphics);

    // Guaranteed Z-Order: Tactical underlays sit beneath vessel surface layer!
    this.worldContainer.addChild(this.oceanLayer);        // 0
    this.worldContainer.addChild(this.terrainLayer);      // 1
    this.worldContainer.addChild(this.wakeLayer);         // 2
    this.worldContainer.addChild(this.sensorLayer);       // 3: Tactical underlay
    this.worldContainer.addChild(this.submergedLayer);    // 4
    this.worldContainer.addChild(this.surfaceLayer);      // 5: Clean warships!
    this.worldContainer.addChild(this.projectilesLayer);  // 6
    this.worldContainer.addChild(this.particleLayer);     // 7
    this.worldContainer.addChild(this.worldUILayer);      // 8
  }

  /**
   * Initialize PixiJS v8 Application onto parent container / canvas.
   * Uses vibrant deep royal marine blue ocean matching authentic naval combat screenshots (#113a75).
   */
  public async init(parentElement: HTMLElement): Promise<void> {
    if (this.isInitialized) return;

    this.app = new Application();
    await this.app.init({
      resizeTo: parentElement,
      backgroundColor: 0x113a75,
      antialias: true,
      autoDensity: true,
      resolution: window.devicePixelRatio || 1,
    });

    parentElement.appendChild(this.app.canvas);
    this.app.stage.addChild(this.worldContainer);

    this.drawOceanGrid();
    this.isInitialized = true;
  }

  /**
   * Draw static ocean boundary and very subtle coordinate grid.
   */
  public drawOceanGrid(): void {
    const g = this.oceanGridGraphics;
    g.clear();

    const mapSize = 6000;
    const half = mapSize * 0.5;
    const step = 300;

    // Very subtle ocean coordinate grid lines
    for (let x = -half; x <= half; x += step) {
      g.moveTo(x, -half);
      g.lineTo(x, half);
      g.stroke({
        color: 0x1a4b8c,
        width: 1,
        alpha: 0.09,
      });
    }

    for (let y = -half; y <= half; y += step) {
      g.moveTo(-half, y);
      g.lineTo(half, y);
      g.stroke({
        color: 0x1a4b8c,
        width: 1,
        alpha: 0.09,
      });
    }

    // World boundary outline
    g.rect(-half, -half, mapSize, mapSize);
    g.stroke({
      color: 0x00e676,
      width: 2.5,
      alpha: 0.6,
    });
  }

  /**
   * Viewport-culled procedural dynamic multi-harmonic sine swell waves, troughs & foam glints.
   * Runs smoothly at 60+ FPS with zero external bitmap textures!
   */
  public drawOceanWaves(timeSec: number): void {
    const g = this.oceanWaveGraphics;
    g.clear();

    const sw = this.app ? this.app.screen.width : 1920;
    const sh = this.app ? this.app.screen.height : 1080;
    const pad = 120;
    const viewHalfW = (sw * 0.5) / this.zoom + pad;
    const viewHalfH = (sh * 0.5) / this.zoom + pad;

    // Viewport cull bounds in world coordinates
    const minX = Math.max(-3000, this.cameraX - viewHalfW);
    const maxX = Math.min(3000, this.cameraX + viewHalfW);
    const minY = Math.max(-3000, this.cameraY - viewHalfH);
    const maxY = Math.min(3000, this.cameraY + viewHalfH);

    const waveSpacing = 95;
    const startY = Math.floor(minY / waveSpacing) * waveSpacing;
    const endY = Math.ceil(maxY / waveSpacing) * waveSpacing;

    const segmentStep = 60;
    const k1 = (2 * Math.PI) / 360; // Primary swell wavelength: 360m
    const omega1 = 0.85;            // Primary swell angular speed
    const k2 = (2 * Math.PI) / 130; // Secondary wavelet wavelength: 130m
    const omega2 = 1.5;             // Secondary wavelet speed

    for (let baseRowY = startY; baseRowY <= endY; baseRowY += waveSpacing) {
      // Dark wave trough shadow slightly below the swell
      let isFirstTrough = true;
      for (let x = minX; x <= maxX; x += segmentStep) {
        const swell = 12 * Math.sin(k1 * (x + baseRowY * 0.45) + omega1 * timeSec) +
                      5 * Math.sin(k2 * (x - baseRowY * 0.3) + omega2 * timeSec);
        const y = baseRowY + swell + 8;

        if (isFirstTrough) {
          g.moveTo(x, y);
          isFirstTrough = false;
        } else {
          g.lineTo(x, y);
        }
      }
      g.stroke({
        color: 0x0c2c5c,
        width: 3.2,
        alpha: 0.32,
      });

      // Primary lit swell ribbon
      let isFirst = true;
      for (let x = minX; x <= maxX; x += segmentStep) {
        const swell = 12 * Math.sin(k1 * (x + baseRowY * 0.45) + omega1 * timeSec) +
                      5 * Math.sin(k2 * (x - baseRowY * 0.3) + omega2 * timeSec);
        const y = baseRowY + swell;

        if (isFirst) {
          g.moveTo(x, y);
          isFirst = false;
        } else {
          g.lineTo(x, y);
        }
      }
      g.stroke({
        color: 0x1d5296,
        width: 2.2,
        alpha: 0.48,
      });

      // Dappled secondary wavelet crest offset between swells
      let isFirstDapple = true;
      for (let x = minX; x <= maxX; x += segmentStep) {
        const dapple = 7 * Math.sin(k2 * (x + baseRowY * 0.6) - omega2 * 0.8 * timeSec);
        const dy = baseRowY + waveSpacing * 0.5 + dapple;
        if (isFirstDapple) {
          g.moveTo(x, dy);
          isFirstDapple = false;
        } else {
          g.lineTo(x, dy);
        }
      }
      g.stroke({
        color: 0x2b6cb3,
        width: 1.5,
        alpha: 0.35,
      });

      // Shimmering soft white seafoam glints along wave crest peaks
      const crestPhase = (baseRowY * 0.008 + timeSec * 0.7) % 1.0;
      if (crestPhase > 0.35 && crestPhase < 0.85 && maxX > minX) {
        const crestX = minX + ((baseRowY * 73 + timeSec * 45) % (maxX - minX));
        const crestY = baseRowY + 12 * Math.sin(k1 * crestX + omega1 * timeSec);
        if (crestX >= minX && crestX <= maxX) {
          g.moveTo(crestX - 18, crestY - 1);
          g.lineTo(crestX + 18, crestY + 1);
          g.stroke({
            color: 0xe0f7fa,
            width: 1.8,
            alpha: 0.55 * (1.0 - Math.abs(crestPhase - 0.6) / 0.25),
          });
        }
      }
    }
  }

  /**
   * Center camera smoothly on target world coordinates.
   */
  public setCameraPosition(x: number, y: number, smoothLerp: number = 1.0): void {
    if (smoothLerp >= 1.0) {
      this.cameraX = x;
      this.cameraY = y;
    } else {
      this.cameraX += (x - this.cameraX) * smoothLerp;
      this.cameraY += (y - this.cameraY) * smoothLerp;
    }

    this.updateViewportTransform();
  }

  public setZoom(targetZoom: number): void {
    this.zoom = Math.max(this.minZoom, Math.min(this.maxZoom, targetZoom));
    this.updateViewportTransform();
  }

  public zoomBy(deltaFactor: number): void {
    this.setZoom(this.zoom * deltaFactor);
  }

  private updateViewportTransform(): void {
    if (!this.app) return;

    const screenWidth = this.app.screen.width;
    const screenHeight = this.app.screen.height;

    this.worldContainer.scale.set(this.zoom);
    this.worldContainer.position.set(
      screenWidth * 0.5 - this.cameraX * this.zoom,
      screenHeight * 0.5 - this.cameraY * this.zoom
    );
  }

  public screenToWorld(screenX: number, screenY: number): { x: number; y: number } {
    if (!this.app) return { x: screenX, y: screenY };
    const screenWidth = this.app.screen.width;
    const screenHeight = this.app.screen.height;

    const worldX = (screenX - screenWidth * 0.5) / this.zoom + this.cameraX;
    const worldY = (screenY - screenHeight * 0.5) / this.zoom + this.cameraY;
    return { x: worldX, y: worldY };
  }

  public worldToScreen(worldX: number, worldY: number): { x: number; y: number } {
    if (!this.app) return { x: worldX, y: worldY };
    const screenWidth = this.app.screen.width;
    const screenHeight = this.app.screen.height;

    const screenX = (worldX - this.cameraX) * this.zoom + screenWidth * 0.5;
    const screenY = (worldY - this.cameraY) * this.zoom + screenHeight * 0.5;
    return { x: screenX, y: screenY };
  }

  /**
   * Draw floating XP crates & oil barrels (slatted wooden crates, steel oil drums, military chests)
   * with dual concentric water ripple rings.
   */
  public renderCrates(
    crates: Array<{
      x: number;
      y: number;
      radius: number;
      type: 'WOODEN' | 'STEEL' | 'MILITARY_CHEST';
    }>
  ): void {
    const g = this.crateGraphics;
    g.clear();

    const pulse = 0.5 + 0.5 * Math.sin(this.elapsedTimeSec * 3.0);

    for (const c of crates) {
      if (!Number.isFinite(c.x) || !Number.isFinite(c.y)) continue;
      const halfSize = c.type === 'MILITARY_CHEST' ? 8.5 : c.type === 'STEEL' ? 7.0 : 5.8;

      // Dual concentric floating ocean ripple rings
      g.circle(c.x, c.y, halfSize + 4.5 + pulse * 2.0);
      g.stroke({ color: 0xe0f7fa, width: 1.1, alpha: 0.38 + pulse * 0.25 });
      g.circle(c.x, c.y, halfSize + 8.5 + pulse * 2.5);
      g.stroke({ color: 0x80deea, width: 0.8, alpha: 0.22 });

      if (c.type === 'STEEL') {
        // Cylindrical Steel Oil Barrel / Drum (top-down / oblique shaded)
        g.roundRect(c.x - 5 + 2, c.y - 7 + 2.5, 10, 14, 3);
        g.fill({ color: 0x050d18, alpha: 0.42 });

        g.roundRect(c.x - 5, c.y - 7, 10, 14, 3);
        g.fill({ color: 0x475569 });
        g.stroke({ color: 0x1e293b, width: 1.4 });

        // Top specular rim & cylindrical highlight band
        g.rect(c.x - 3.5, c.y - 5.5, 2.5, 11);
        g.fill({ color: 0x94a3b8, alpha: 0.55 });

        // Two transverse drum chime ribs
        g.moveTo(c.x - 5, c.y - 2.3);
        g.lineTo(c.x + 5, c.y - 2.3);
        g.moveTo(c.x - 5, c.y + 2.3);
        g.lineTo(c.x + 5, c.y + 2.3);
        g.stroke({ color: 0x1e293b, width: 1.5 });

        // Red/amber bung cap
        g.circle(c.x + 1.8, c.y - 4.2, 1.3);
        g.fill({ color: 0xf97316 });
      } else if (c.type === 'MILITARY_CHEST') {
        // Olive-drab armored military supply case with gold corner clasps & cross emblem
        g.rect(c.x - halfSize + 2, c.y - halfSize + 2.5, halfSize * 2, halfSize * 2);
        g.fill({ color: 0x050d18, alpha: 0.42 });

        g.rect(c.x - halfSize, c.y - halfSize, halfSize * 2, halfSize * 2);
        g.fill({ color: 0x2f5e34 });
        g.stroke({ color: 0xfacc15, width: 1.6 });

        // Gold corner clasps
        const cSz = 2.6;
        g.rect(c.x - halfSize, c.y - halfSize, cSz, cSz);
        g.rect(c.x + halfSize - cSz, c.y - halfSize, cSz, cSz);
        g.rect(c.x - halfSize, c.y + halfSize - cSz, cSz, cSz);
        g.rect(c.x + halfSize - cSz, c.y + halfSize - cSz, cSz, cSz);
        g.fill({ color: 0xfacc15 });

        // Center emblem cross
        g.moveTo(c.x - 3.5, c.y);
        g.lineTo(c.x + 3.5, c.y);
        g.moveTo(c.x, c.y - 3.5);
        g.lineTo(c.x, c.y + 3.5);
        g.stroke({ color: 0xfef08a, width: 1.8 });
      } else {
        // WOODEN: Slatted wooden crate with perimeter frame & diagonal cross-brace planks
        g.rect(c.x - halfSize + 2, c.y - halfSize + 2.5, halfSize * 2, halfSize * 2);
        g.fill({ color: 0x050d18, alpha: 0.4 });

        g.rect(c.x - halfSize, c.y - halfSize, halfSize * 2, halfSize * 2);
        g.fill({ color: 0xb47b3c });
        g.stroke({ color: 0x5c3a14, width: 1.5 });

        // Inner recessed plank field & slats
        g.rect(c.x - halfSize + 1.8, c.y - halfSize + 1.8, halfSize * 2 - 3.6, halfSize * 2 - 3.6);
        g.stroke({ color: 0x8b5a2b, width: 1.0 });

        g.moveTo(c.x - halfSize + 1.5, c.y - halfSize + 1.5);
        g.lineTo(c.x + halfSize - 1.5, c.y + halfSize - 1.5);
        g.moveTo(c.x + halfSize - 1.5, c.y - halfSize + 1.5);
        g.lineTo(c.x - halfSize + 1.5, c.y + halfSize - 1.5);
        g.stroke({ color: 0x784b1e, width: 1.3, alpha: 0.9 });
      }
    }
  }

  /**
   * Draw projectiles (torpedoes, shells, missiles, depth charges, mines) as vector shapes.
   * Renders two-tone red-warhead torpedoes with 5-node foamy zigzag trails & warning triangles (▼).
   */
  public renderProjectiles(
    projectiles: Array<{
      x: number;
      y: number;
      heading: number;
      type: 'SHELL' | 'TORPEDO' | 'MISSILE' | 'MINE' | 'DEPTH_CHARGE';
    }>
  ): void {
    const g = this.projectileGraphics;
    g.clear();

    const pulse = 0.5 + 0.5 * Math.sin(this.elapsedTimeSec * 6.0);

    for (const p of projectiles) {
      if (p.type === 'TORPEDO') {
        const len = 12;
        const width = 3.0;
        const cos = Math.cos(p.heading);
        const sin = Math.sin(p.heading);
        const perpX = -sin;
        const perpY = cos;

        // 1. Hydrodynamic metallic silver-grey cylinder body + tail fins
        g.moveTo(p.x - cos * len, p.y - sin * len);
        g.lineTo(p.x + cos * len * 0.25, p.y + sin * len * 0.25);
        g.stroke({ color: 0x94a3b8, width: width + 0.8 });

        // Tail stabilizer fins
        g.moveTo(p.x - cos * (len + 1) + perpX * 2.5, p.y - sin * (len + 1) + perpY * 2.5);
        g.lineTo(p.x - cos * (len + 1) - perpX * 2.5, p.y - sin * (len + 1) - perpY * 2.5);
        g.stroke({ color: 0x334155, width: 1.6 });

        // 2. Red/orange warhead nose cone
        g.moveTo(p.x + cos * len * 0.25, p.y + sin * len * 0.25);
        g.lineTo(p.x + cos * (len * 0.55), p.y + sin * (len * 0.55));
        g.stroke({ color: 0xff3d00, width: width + 0.8 });
        g.circle(p.x + cos * (len * 0.55), p.y + sin * (len * 0.55), width * 0.55);
        g.fill({ color: 0xff3d00 });

        // 3. 5-node foamy zigzag cavitation bubble contrail behind torpedo
        for (let b = 1; b <= 5; b++) {
          const zigzag = (b % 2 === 0 ? 1 : -1) * (0.9 + b * 0.3);
          const bx = p.x - cos * (len + b * 4.5) + perpX * zigzag;
          const by = p.y - sin * (len + b * 4.5) + perpY * zigzag;
          g.circle(bx, by, 1.3 + b * 0.45);
          g.fill({ color: b <= 2 ? 0xffffff : 0xb2ebf2, alpha: Math.max(0.2, 0.85 - b * 0.14) });
        }

        // 4. Crisp emerald downward triangle marker (▼) above torpedo
        const markerDist = 16;
        const mx = p.x;
        const my = p.y - markerDist;
        const triSize = 6;

        g.moveTo(mx - triSize, my - triSize);
        g.lineTo(mx + triSize, my - triSize);
        g.lineTo(mx, my);
        g.closePath();
        g.fill({ color: 0x00e676 });
        g.stroke({ color: 0x052e16, width: 1.2 });
      } else if (p.type === 'MISSILE') {
        const len = 13;
        const cos = Math.cos(p.heading);
        const sin = Math.sin(p.heading);

        g.moveTo(p.x - cos * len, p.y - sin * len);
        g.lineTo(p.x + cos * len, p.y + sin * len);
        g.stroke({ color: 0xffffff, width: 2.5 });

        g.circle(p.x - cos * len, p.y - sin * len, 3.5);
        g.fill({ color: 0xff9100 });
      } else if (p.type === 'MINE') {
        // Dark iron contact mine with 6 radial horns and pulsing red detonator light
        const r = 4.8;
        for (let h = 0; h < 6; h++) {
          const ang = (h / 6) * Math.PI * 2;
          g.moveTo(p.x + Math.cos(ang) * (r * 0.7), p.y + Math.sin(ang) * (r * 0.7));
          g.lineTo(p.x + Math.cos(ang) * (r + 3.2), p.y + Math.sin(ang) * (r + 3.2));
        }
        g.stroke({ color: 0x4b5563, width: 1.5 });

        g.circle(p.x, p.y, r);
        g.fill({ color: 0x111827 });
        g.stroke({ color: 0x374151, width: 1.2 });

        g.circle(p.x, p.y, 1.8);
        g.fill({ color: 0xff1744, alpha: 0.45 + pulse * 0.55 });
      } else if (p.type === 'DEPTH_CHARGE') {
        g.circle(p.x, p.y, 8.5);
        g.stroke({ color: 0x80deea, width: 1.4, alpha: 0.65 });
        g.rect(p.x - 3.5, p.y - 2.5, 7, 5);
        g.fill({ color: 0x334155 });
        g.stroke({ color: 0x0f172a, width: 1.0 });
      } else {
        const cos = Math.cos(p.heading);
        const sin = Math.sin(p.heading);
        g.moveTo(p.x - cos * 11, p.y - sin * 11);
        g.lineTo(p.x + cos * 3, p.y + sin * 3);
        g.stroke({ color: 0xff9100, width: 2.2, alpha: 0.7 });

        g.moveTo(p.x - cos * 4, p.y - sin * 4);
        g.lineTo(p.x + cos * 4, p.y + sin * 4);
        g.stroke({ color: 0xfff59d, width: 2.6, alpha: 0.95 });

        g.circle(p.x + cos * 3, p.y + sin * 3, 2.0);
        g.fill({ color: 0xffea00 });
      }
    }
  }

  /**
   * Draw directional threat warning triangles on a 75m ring around player ship
   * pointing toward incoming hostile torpedoes (red) and nearby enemy vessels (amber).
   */
  public renderThreatIndicators(
    playerX: number,
    playerY: number,
    threats: Array<{ x: number; y: number; kind: 'TORPEDO' | 'VESSEL'; distance: number }>
  ): void {
    const g = this.threatGraphics;
    g.clear();

    if (!threats || threats.length === 0) return;

    const ringRadius = 75;
    for (const t of threats) {
      if (!Number.isFinite(t.x) || !Number.isFinite(t.y)) continue;
      const dx = t.x - playerX;
      const dy = t.y - playerY;
      if (dx === 0 && dy === 0) continue;

      const angle = Math.atan2(dy, dx);
      const cx = playerX + Math.cos(angle) * ringRadius;
      const cy = playerY + Math.sin(angle) * ringRadius;
      const cos = Math.cos(angle);
      const sin = Math.sin(angle);
      const perpX = -sin;
      const perpY = cos;

      const tipLen = t.kind === 'TORPEDO' ? 9 : 7.5;
      const baseHalfW = t.kind === 'TORPEDO' ? 5.5 : 4.5;
      const color = t.kind === 'TORPEDO' ? 0xff1744 : 0xffab00;

      const tipX = cx + cos * tipLen;
      const tipY = cy + sin * tipLen;
      const leftX = cx - cos * 4 + perpX * baseHalfW;
      const leftY = cy - sin * 4 + perpY * baseHalfW;
      const rightX = cx - cos * 4 - perpX * baseHalfW;
      const rightY = cy - sin * 4 - perpY * baseHalfW;

      g.poly([tipX, tipY, leftX, leftY, rightX, rightY]);
      g.fill({ color, alpha: 0.9 });
      g.stroke({ color: 0x050d18, width: 1.2 });
    }
  }

  public update(dt: number): void {
    this.elapsedTimeSec += dt;
    this.drawOceanWaves(this.elapsedTimeSec);
    this.wakeFX.update(dt);
    this.particles.update(dt);
  }

  public destroy(): void {
    if (this.app) {
      this.app.destroy(true, { children: true });
      this.app = null;
      this.isInitialized = false;
    }
  }
}
