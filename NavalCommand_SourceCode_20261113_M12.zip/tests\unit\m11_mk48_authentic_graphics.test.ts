/**
 * Milestone M11 Unit & Boundary Test Suite:
 * Authentic mk48.io Graphics Reconstruction:
 * - In-Theater Multi-Layer Archipelago Islands
 * - Ambient Floating XP Crates & Server Replenishment
 * - Enhanced Procedural Vector Warship Decks & Superstructures
 * - Elongated Tracer Shells, Depth Charges & Crate Rendering
 * - Non-Overlapping Kill Feed & Compact Top Bar Layout
 */

import { describe, it, expect, beforeAll, vi } from 'vitest';
import { DEFAULT_ISLAND_PRESETS } from '../../common/models/terrain.js';
import { AuthoritativeGameServer } from '../../server/core/game_server.js';
import { PixiRenderer } from '../../client/src/rendering/pixi_renderer.js';
import { ProceduralVessel } from '../../client/src/rendering/vector_hulls.js';
import { KillFeed } from '../../client/src/hud/kill_feed.js';
import { HUDController } from '../../client/src/hud/hud_controller.js';
import { ShipClassId } from '../../common/models/ships.js';

beforeAll(() => {
  if (typeof globalThis.document === 'undefined') {
    const mockContext2D = {
      clearRect: vi.fn(),
      fillRect: vi.fn(),
      beginPath: vi.fn(),
      moveTo: vi.fn(),
      lineTo: vi.fn(),
      closePath: vi.fn(),
      arc: vi.fn(),
      fill: vi.fn(),
      stroke: vi.fn(),
      save: vi.fn(),
      restore: vi.fn(),
      translate: vi.fn(),
      rotate: vi.fn(),
      strokeRect: vi.fn(),
      measureText: vi.fn(() => ({ width: 50 })),
      fillStyle: '',
      strokeStyle: '',
      lineWidth: 1,
    };

    const createMockElement = (tag: string) => {
      const styleObj: any = {};
      Object.defineProperty(styleObj, 'cssText', {
        set(txt: string) {
          txt.split(';').forEach((decl) => {
            const parts = decl.split(':');
            if (parts.length >= 2) {
              const k = parts[0].trim();
              const v = parts.slice(1).join(':').trim();
              if (k) styleObj[k] = v;
            }
          });
        },
        get() {
          return '';
        },
      });
      const children: any[] = [];
      const el: any = {
        tagName: tag.toUpperCase(),
        className: '',
        style: styleObj,
        width: 200,
        height: 200,
        innerHTML: '',
        children,
        appendChild: (c: any) => {
          children.push(c);
          return c;
        },
        removeChild: () => {},
        addEventListener: () => {},
        querySelector: (sel: string) => {
          const cls = sel.startsWith('.') ? sel.slice(1) : sel;
          let found = children.find((c: any) => c.className === cls);
          if (!found) {
            found = createMockElement('div');
            found.className = cls;
            children.push(found);
          }
          return found;
        },
        getContext: () => mockContext2D,
      };
      return el;
    };

    (globalThis as any).document = {
      createElement: (tag: string) => createMockElement(tag),
      body: createMockElement('body'),
    };
    (globalThis as any).window = globalThis;
    (globalThis as any).requestAnimationFrame = () => 0;
  }
});

describe('Milestone M11: Authentic mk48.io Vector Graphics, Islands & Floating Crates', () => {
  describe('1. In-Theater Multi-Layer Islands & Legacy Compatibility', () => {
    it('preserves first 3 legacy island presets and adds 4 in-theater islands inside [-1500, +1500]', () => {
      expect(DEFAULT_ISLAND_PRESETS[0].id).toBe('island_north_bastion');
      expect(DEFAULT_ISLAND_PRESETS[1].id).toBe('island_central_citadel');
      expect(DEFAULT_ISLAND_PRESETS[2].id).toBe('island_south_archipelago');

      expect(DEFAULT_ISLAND_PRESETS.length).toBeGreaterThanOrEqual(7);

      const inTheaterIslands = DEFAULT_ISLAND_PRESETS.slice(3);
      expect(inTheaterIslands.length).toBe(4);

      for (const isl of inTheaterIslands) {
        expect(isl.polygon.vertices.length).toBeGreaterThanOrEqual(8);
        for (const v of isl.polygon.vertices) {
          expect(Math.abs(v.x)).toBeLessThanOrEqual(1500);
          expect(Math.abs(v.y)).toBeLessThanOrEqual(1500);
          // Safe clearance from player spawn point (0, 200)
          expect(Math.hypot(v.x - 0, v.y - 200)).toBeGreaterThan(600);
        }
      }
    });
  });

  describe('2. Server Ambient Floating XP Crates & Replenishment', () => {
    it('seeds 24 floating XP crates on server creation across WOODEN, STEEL, and MILITARY_CHEST tiers', () => {
      const server = new AuthoritativeGameServer();
      const crates = server.resourceEngine.getAllCrates();
      expect(crates.length).toBe(24);

      const types = new Set(crates.map((c) => c.type));
      expect(types.has('WOODEN')).toBe(true);
      expect(types.has('STEEL')).toBe(true);
      expect(types.has('MILITARY_CHEST')).toBe(true);
    });

    it('replenishes ambient crates during step() when total crates fall below 15', () => {
      const server = new AuthoritativeGameServer();
      // Remove crates down to 10
      const all = server.resourceEngine.getAllCrates();
      for (let i = 0; i < 14; i++) {
        all[i].isCollected = true;
      }
      server.step(0.05);
      // Cleanup deletes 14 collected -> 10 remaining -> replenishment adds 1 -> 11
      expect(server.resourceEngine.getAllCrates().length).toBe(11);
    });
  });

  describe('3. Procedural Floating Crates & Projectile Vector Rendering', () => {
    it('renders floating crates cleanly across all 3 tiers and ignores non-finite coordinates', () => {
      const renderer = new PixiRenderer();
      expect(() => {
        renderer.renderCrates([
          { x: 100, y: -150, radius: 8, type: 'WOODEN' },
          { x: -320, y: 400, radius: 12, type: 'STEEL' },
          { x: 550, y: 200, radius: 16, type: 'MILITARY_CHEST' },
          { x: NaN, y: Infinity, radius: 8, type: 'WOODEN' },
        ]);
      }).not.toThrow();

      // Empty state should clear cleanly
      expect(() => renderer.renderCrates([])).not.toThrow();
    });

    it('renders enhanced tracer shells, torpedoes, missiles, mines, and depth charges', () => {
      const renderer = new PixiRenderer();
      expect(() => {
        renderer.renderProjectiles([
          { x: 10, y: 20, heading: 0.5, type: 'SHELL' },
          { x: 30, y: 40, heading: -1.2, type: 'TORPEDO' },
          { x: 50, y: 60, heading: 2.1, type: 'MISSILE' },
          { x: 70, y: 80, heading: 0, type: 'MINE' },
          { x: 90, y: 100, heading: 0, type: 'DEPTH_CHARGE' },
        ]);
      }).not.toThrow();
    });
  });

  describe('4. Enhanced Vector Warship Hull Details & Scene Order Invariants', () => {
    it('preserves 7-tier child layer hierarchy across all 8 naval ship classes after mk48 detail upgrades', () => {
      const classes: ShipClassId[] = [
        'COASTAL_PATROL',
        'DESTROYER',
        'CRUISER',
        'BATTLESHIP',
        'AIRCRAFT_CARRIER',
        'SUBMARINE',
        'TACTICAL_SUPPORT',
        'DREDGER_ICEBREAKER',
      ];

      for (const cls of classes) {
        const vessel = new ProceduralVessel(cls, 180, 24, 'HAZE_GREY', []);
        expect(vessel.container.children[0]).toBe(vessel.shadowGraphics);
        expect(vessel.container.children[1]).toBe(vessel.hullGraphics);
        expect(vessel.container.children[2]).toBe(vessel.deckGraphics);
        expect(vessel.container.children[3]).toBe(vessel.camoGraphics);
        expect(vessel.container.children[4]).toBe(vessel.superstructureGraphics);
      }
    });
  });

  describe('5. Non-Overlapping HUD Positioning', () => {
    it('positions KillFeed at top: 235px and keeps TopBar at top: 28px', () => {
      const feed = new KillFeed();
      expect(feed.container.style.top).toBe('235px');
      expect(feed.container.style.right).toBe('16px');

      const root = document.createElement('div');
      const hud = new HUDController(root);
      expect((hud as any).topBar.style.top).toBe('28px');
    });
  });
});
